# Quantum Relativity: Relational Complexity under Information-Preserving Transduction

The Thalean Graph AT4val[60,6] | Draft 4
Scott Allen Cave | Center of Recursive Inquiry | 23 September 2026

## Open in Overleaf

Use **New Project > Upload Project**, select the supplied ZIP, and set `main.tex`
as the main document. Select **pdfLaTeX**. Overleaf's normal automatic build runs
BibTeX. No shell escape, Python execution, network access, private repository,
or custom font files are required to compile the manuscript.

The compiled 56-page PDF is in `preview/Quantum_Relativity_Relational_Complexity_Draft_4.pdf`. The entire manuscript is
editable LaTeX; the preview is not used as embedded manuscript content.

## What changed in Draft 4

The thesis is now: **Quantum Relativity is a theory of relational complexity
governed by conservation of information.** Transduction is the mechanism.

The introduction includes the Thales/water/natural-principle naming background and
the serendipitous Tolkien/Thalion/steadfast resonance. The historical shorthand is
not presented as a surviving quotation from Thales, and neither naming source is
used as mathematical evidence.

Section 4A defines the registered object, relational complexity C(R), and the
optional encoding S(R)=G^C(R). Section 11A defines scalar relay and proves
conditional compositional accounting and the local decoder criterion, with an
explicit two-bit example. Section 13C separates scalar from phase and Mode.
Appendix M records the remaining native construction obligations and failure tests.
The revised part headings, abstract, dictionary, guardrails, and conclusion follow
this language without renumbering existing sections.

## Preserved finite basis

The 52 original equations and their source files, all 22 original protected formal
statement blocks, the complete Mode section (M1-M4), and the additional Draft 3
cover proposition remain intact. The census-family/common-cover/kernel/WXYZTI
mathematical sections and Appendices J-L are byte-identical, as are the archived
source inputs and six original finite-check scripts. One hundred baseline files
are hash-protected. The existing proof-status ledger and Section 50 guardrails
are retained and expanded rather than replaced.

## Scope of the new definitions

The general native complexity functional is still a construction target. The
scalar difference/product equations are exact once a functional is supplied;
these identities do not derive a local implementation. Incremental relay needs
an initial scalar or equivalent reference and enough local relational data to
decode each increment. Complete joint-output recovery does not make every
remote marginal sufficient.

Repeated-return linearity is stated conditionally on an additive positive-history
functional. The package does not establish a general identification of complexity
with return exponent, vertex count, signed winding, or entropy. A signed
representation coordinate is not the nonnegative complexity scalar. The locked
c_Th=1 does not imply Delta C=1. These qualifications to the preliminary discussion
are explicit in Appendix H.3 and the revision ledger.

## Reproduce the checks

The optional verification dependencies are pinned in `requirements.txt`. Run:

    python3 scripts/verify_all.py

The current executed suite has **183 passing checks**:
158 inherited finite checks and
25 new bounded scalar-accounting examples and
negative controls. The new tests do not derive a native Thalean complexity law,
null-well crosswalk, or physical transport mechanism.

Compile locally with:

    bash build.sh

After compilation, run:

    python3 scripts/verify_manuscript.py

The current **291 editorial checks** cover original expression
preservation, single inclusion, protected source hashes, retained and new labels,
references, naming qualifiers, and absence of overfull boxes. These are source and
build checks, not physical validation.

## Project contents

- `main.tex`, `preamble.tex`, `sections/`, `appendices/`, `equations/`, and
  `statements/`: editable manuscript.
- `references.bib`: retained bibliography plus three inspected naming references.
- `preview/`: compiled Draft 4 PDF.
- `scripts/`, `data/`: offline checks, exact inputs, maps, and generated reports.
- `notes/revision_ledger.md`: approved changes and explicit qualifications.
- `notes/build_receipt.json`: current compiler, PDF, verification, and layout record.
- `notes/draft3_file_protections.json`: hashes for one hundred preserved files.
- `notes/source_change_report.json`: file-level changes relative to Draft 3.
- `provenance/draft4/source_ledger.json`: source-archive hash and new naming sources.
- `provenance/draft3_editorial/`: historical Draft 3 editorial records; not current
  execution receipts. Earlier source and provenance directories are also retained.
- `SHA256SUMS.txt`: checksums of delivered files, excluding the checksum file itself.

The package was revised directly from the recovered original Draft 3 source
archive. Its preview was byte-identical to the supplied Draft 3 PDF. No Library,
Drive, or original manuscript file was overwritten. Archived upstream producers
that require private source artifacts remain archival; the bounded included
replays are the scripts actually executed.
