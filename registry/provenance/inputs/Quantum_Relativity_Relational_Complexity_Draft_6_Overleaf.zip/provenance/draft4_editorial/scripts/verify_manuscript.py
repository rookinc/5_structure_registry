#!/usr/bin/env python3
"""Check protected TeX expressions, input multiplicities, and compiled labels."""
from __future__ import annotations
import collections
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT / 'notes/preservation_manifest.json').read_text())
checks = {}
inputs = collections.Counter()


def expand(path: Path, stack: tuple[Path, ...] = ()) -> str:
    if path in stack:
        raise ValueError(f'Recursive TeX inclusion: {path}')
    text = path.read_text()
    def one(match):
        file = ROOT / (match[1] if match[1].endswith('.tex') else match[1] + '.tex')
        inputs[str(file.relative_to(ROOT))] += 1
        return expand(file, stack + (path,))
    return re.sub(r'\\input\{([^}]+)\}', one, text)

expanded = expand(ROOT / 'main.tex')
for group in ['equations', 'statements']:
    for item in manifest[group]:
        text = (ROOT / item['output_file']).read_text()
        protected = item['source_expression']
        key = item.get('original_number', str(item.get('first_number')))
        checks[f'{group}_{key}_source_expression_unchanged'] = (
            protected in text and hashlib.sha256(protected.encode()).hexdigest() == item['source_sha256'])
        checks[f'{group}_{key}_included_once'] = inputs[item['output_file']] == 1
# Verify original formal statement numbering in the compiled ordering.
numbered = []
current = 0
for match in re.finditer(r'\\section\{|\\setcounter\{section\}\{(\d+)\}|\\begin\{(definition|example|proposition|hypothesis|theorem)\}', expanded):
    if match[1] is not None:
        current = int(match[1])
    elif match[2] is not None:
        numbered.append((current, match[2]))
    else:
        current += 1
aux = (ROOT / 'main.aux').read_text() if (ROOT / 'main.aux').exists() else ''
expected = {'eq:cth': '29', 'eq:fourcell': '42', 'eq:historyconference': '34',
            'eq:bornmasses': '38', 'eq:singletcontraction': '41', 'eq:thaleantime': '24',
            'sec:guardrails': '50', 'sec:mode': '13A', 'app:status': 'H'}
for label, number in expected.items():
    checks[f'compiled_label_{label}'] = bool(re.search(
        re.escape(r'\newlabel{' + label + '}{{' + number + '}'), aux))
log = (ROOT / 'main.log').read_text(errors='replace') if (ROOT / 'main.log').exists() else ''
checks['no_undefined_citations_or_references'] = not bool(re.search(r'(undefined|multiply defined|multiply-defined)', log, re.I)) and bool(log)
checks['no_overfull_boxes'] = 'Overfull' not in log and bool(log)
checks['all_original_numbers_covered'] = sorted(n for q in manifest['equations']
                                              for n in range(q['first_number'], q['last_number'] + 1)) == list(range(1, 53))
full_protections = json.loads((ROOT / 'notes/draft2_file_protections.json').read_text())
for name, digest in full_protections.items():
    checks['baseline_file_unchanged_' + name] = hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
for name in ['sections/01A_census_family.tex', 'sections/01B_common_cover.tex',
             'sections/01C_relational_kernel.tex', 'sections/02A_coupling.tex',
             'sections/03B_wxyzti.tex', 'statements/S22_3_cover.tex',
             'appendices/J_census_replay.tex', 'appendices/K_kernel_replay.tex',
             'appendices/L_structural_horizon.tex']:
    checks['draft3_single_inclusion_' + name] = inputs[name] == 1
for name, digest in json.loads((ROOT / 'notes/draft3_file_protections.json').read_text()).items():
    checks['draft3_protected_' + name] = hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
for name in ['sections/02B_complexity.tex', 'sections/03C_scalar_relay.tex',
             'sections/03D_scalar_mode.tex', 'appendices/M_complexity_contract.tex']:
    checks['draft4_single_inclusion_' + name] = inputs[name] == 1
for label, number in {'sec:complexity':'4A', 'sec:scalarrelay':'11A', 'sec:scalarmode':'13C',
                      'app:complexitycontract':'M', 'prop:scalarcomposition':'11A.2',
                      'prop:localincrement':'11A.3', 'sec:guardrails':'50',
                      'eq:complexitydomain':'{RC1}', 'eq:complexitymodechart':'{RC8}'}.items():
    checks['draft4_compiled_' + label] = bool(re.search(re.escape(r'\newlabel{' + label + '}{{' + number + '}'), aux))
checks['new_thesis_present'] = 'Quantum Relativity is a theory of relational complexity governed by conservation of information.' in expanded
checks['naming_note_present'] = 'Naming and intellectual background' in expanded
checks['water_not_verbatim_quotation'] = 'not a surviving verbatim quotation' in expanded
checks['Tolkien_secondary_mnemonic'] = 'the coincidence is a mnemonic, not mathematical provenance' in expanded
checks['local_scalar_criterion_present'] = 'constant on every fiber' in expanded
checks['complexity_unit_not_inferred_from_causality'] = 'does not imply this complexity increment' in expanded
checks['no_unrequested_consciousness_language'] = 'consciousness' not in expanded.lower() and 'mcgilchrist' not in expanded.lower()
# This verifies source preservation, not scientific validity of the unchanged claims.
report = {'audit': 'draft4_editorial_integrity', 'all_checks_pass': all(checks.values()),
          'check_count': len(checks), 'checks': checks,
          'protected_equation_count': 52, 'protected_statement_count': len(manifest['statements']),
          'scope': 'TeX source integrity, single inclusion, key label preservation, and compilation checks.'}
(ROOT / 'data/generated/manuscript_integrity_report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: report[k] for k in ['audit', 'all_checks_pass', 'check_count',
                                       'protected_equation_count', 'protected_statement_count']}, indent=2))
if not report['all_checks_pass']:
    raise SystemExit('FAIL: ' + ', '.join(k for k, v in checks.items() if not v))
