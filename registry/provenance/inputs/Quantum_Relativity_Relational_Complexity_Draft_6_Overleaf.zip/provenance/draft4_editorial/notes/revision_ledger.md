# Draft 4 revision ledger

Scott Allen Cave | Center of Recursive Inquiry | 23 September 2026

## Baseline

This is a direct revision of the recovered original Draft 3 source ZIP, not a PDF
reconstruction. The archive preview was confirmed byte-identical to the supplied
48-page PDF. The archive hash and naming sources are in
`provenance/draft4/source_ledger.json`.

## Approved organizing change

QR is now introduced as a theory of relational complexity governed by conservation
of information. Transduction remains the mechanism. The title, abstract,
introduction, part headings, reading guide, Appendix A, Section 50 and conclusion
are revised around that hierarchy. The ten parts retain the original section
numbers so established references do not move silently.

## New material and status

- Section 4A defines registered relational objects, a presentation-invariant
  nonnegative complexity functional, and S(R)=G^{C(R)} with a fixed G>1. This
  fixes vocabulary and requirements, not a universal native formula.
- Section 11A defines scalar relay. Proposition 11A.2 proves telescoping of a
  supplied functional. Proposition 11A.3 proves the available-data fiber criterion
  for a local increment decoder. They are conditional mathematical results, not
  source-native complexity or physical transport theorems.
- Section 13C separates scalar from phase/Mode, retains the existing S3 action,
  and states the conditional scalar-invariant extension. No native common-domain
  map or null-well identification is claimed.
- Appendix M specifies construction requirements, failure witnesses, and the
  exact scope of the bounded scalar-accounting tests.
- The Introduction adds a brief Thales/water/natural-principle note and the
  secondary Tolkien/Thalion/steadfast resonance, with inspected source citations.
  Naming is intellectual background, not mathematical provenance.
- New equation tags RC1-RC8 do not alter original equation numbers.

## Clarifications of preliminary discussion (not changes to retained theorems)

The earlier conversation called return depth the simplest proven instance of
native relational complexity. Draft 3 does not contain that identification. Draft 4
therefore states only the proved implication from an explicitly additive
positive-history functional. An abstract return operator does not acquire a vertex
set or a nonnegative additive complexity merely from its notation.

A signed coordinate in a D8 representation is not the positive scalar S(R) or
nonnegative C(R). Mode reversal does not automatically negate scalar complexity.
A descriptive orthogonality mark supplies neither an inner product nor independent
dynamics. The scalar-phase common-domain action remains conditional.

The scalar relay equations are identities after C has been supplied. They do not
prove locality, initial-value availability, communication without a signal, or a
unit complexity gain at every event. Global complete-output recoverability does
not imply that a downstream marginal can reconstruct the scalar. A baseline or
sufficient local relational state is required.

Conservation constrains joint distinctions. The new text does not add independent
scalar/phase/Mode information quantities without accounting for correlations, and
does not identify C with Shannon/von Neumann entropy. c_Th=1 is unchanged and does
not imply Delta C=1. Native complexity, physical calibration and null-well bridges
remain open at their specified interfaces.

## Preserved material

All 52 original equation numbers and their source files, all 22 original protected
formal statement blocks, the additional Draft 3 cover proposition, the complete
Mode section, the Draft 3 census/common-cover/kernel/WXYZTI mathematical sections,
Appendices J-L, six finite verification scripts, and numerical/upstream source data
are protected against byte changes. Existing proof-status rows retain their status;
the D row defining QR is explicitly reframed and new rows are added. The complete
Section 50 guardrail table remains, with six new rows.

The prior Draft 3 editorial records are retained under
`provenance/draft3_editorial/` as historical records. Current finite and editorial
receipts are generated separately for Draft 4. Inherited source scripts that require
private upstream artifacts remain archival and are not claimed to have been rerun.

## Minor presentation edits

A repeated causal-normalizer sentence outside the protected definition was removed.
The original definition and causal equations are unchanged. The history-domain
symbol C_event is explicitly distinguished from the new complexity functional.
Table placement and bibliography spacing were adjusted for the compiled layout.

## Delivery

Editable LaTeX, bibliography, compiled preview, included offline verification
scripts and data, current build receipt, revision ledger, and file checksums. No
original Library or Drive file is overwritten.
