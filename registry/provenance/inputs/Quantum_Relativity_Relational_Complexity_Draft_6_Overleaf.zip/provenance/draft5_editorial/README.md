# Quantum Relativity: Relational Complexity under Information-Preserving Transduction

The Thalean Graph AT4val[60,6] | Draft 5: conservative informative dynamics  
Scott Allen Cave | Center of Recursive Inquiry (CoRI) | 23 September 2026

## Open in Overleaf

Use **New Project > Upload Project**, select the ZIP, and set `main.tex` as the
main document. Select **pdfLaTeX**. The ordinary bibliography workflow uses
BibTeX. Compilation needs no shell escape, Python execution, network access,
private repository, or custom font files.

The compiled **70-page PDF** is
`preview/Quantum_Relativity_Relational_Complexity_Draft_5.pdf`.
The complete manuscript is editable LaTeX. The preview is not embedded to replace
editable manuscript pages.

## What Draft 5 adds

The organizing thesis remains: **Quantum Relativity is a theory of relational
complexity governed by conservation of information.** The new dynamical question
is which admitted generators can reorganize a state while preserving a declared
invariant. Complete recoverability, invariant preservation, and an informative
registered effect remain distinct requirements.

Section 6B defines conservative informative action. New Sections 37A-37D form
Part X, **Conservative Informative Dynamics**:

- **37A:** the fixed-form skew-generator criterion, finite propagators and Cayley
  steps, nonlinear counterexamples, moving metrics, and source terms.
- **37B:** axis tangency, the axial kernel, the full-frame SO(2) fiber, local phase,
  torque decomposition, and the qualified slow-precession approximation.
- **37C:** Maxwell constraints and continuity, a precisely specified periodic
  skew-adjoint operator, energy and Poynting balance, duality, and propagation.
- **37D:** source-selected native metrics and generators, stabilizer and dihedral
  distinctions, the WXYZTI crosswalk, and explicit failure tests.

Appendix N supplies detailed calculations and a generic tetrahedral incidence
reference model. That model is **not** derived from G60 or WXYZTI. Appendix L
receives additional native-construction targets without changing its protected
original text. The abstract, results page, scalar-relay explanation, dictionary,
common-invariant discussion, ledger, guardrails, outlook, and conclusion are
updated around the new material.

The new equation families CD1-CD6, GY1-GY6, and EM1-EM7 leave the established
equation numbering intact. The old Outlook becomes Part XI; its named section
label remains navigable. Bibliography entry numbers follow their new citation
order. The unnumbered bibliography anchor is checked for presence rather than
its incidental inherited subsection number.

## Preserved mathematical basis

The **52 original numbered equations**, **22 original protected formal statement
blocks**, additional Draft 3 cover proposition, entire Mode section (M1-M4),
census/common-cover/rank-eight-kernel/WXYZTI sources, and original finite inputs
remain intact. One hundred inherited files and two additional Draft 4 files
are hash-protected. Seventeen Draft 4 mathematical expression/proof blocks and
121 existing compiled identifiers receive additional preservation checks,
including RC1-RC8. Native Thalean time and c_Th=1 retain their stated domains and
qualifications. Section 50 and Appendix H retain their existing content and gain
new distinctions and status rows.

## Scope of the new mathematics

The generalized skew condition is proved for a supplied finite-dimensional linear
realization and fixed positive Hermitian form. It is not deduced from information
conservation alone and is not a universal definition of QR conservation.
Gyroscopic mechanics and Maxwell theory provide conventional correspondence
models, not native Thalean derivations.

Tangency does not force uniform precession. An invisible axial direction is not
by itself a measured spin phase: a full frame and local phase convention are
needed. Mechanical momentum magnitude and electromagnetic energy are not
identified with relational complexity. Maxwell skew-adjointness includes its
operator domain; source work, boundary flux, charge continuity, and duality are
kept explicit. WXYZTI's commuting reciprocal flip is not the native Mode
inversion or Maxwell's signed quarter-turn.

A general source-selected complexity functional, native invariant form and
admitted generator, phase/Mode crosswalks, and calibrated physical continuum
limits remain construction targets. No physical validation or experimental
prediction is claimed by the included tests.

## Reproduce the verification and compilation

Optional verification dependencies are pinned in `requirements.txt`. They are
not needed by Overleaf. With those dependencies installed, run:

    python3 scripts/verify_all.py

The executed suite has **264 passing bounded checks**: 158 inherited finite
checks, 25 inherited scalar-accounting examples, and 81 new exact symbolic or
rational correspondence checks and negative controls. Progress messages identify
each stage. Current results are in
`data/generated/draft5_verification_summary.json` and its eight named reports.

Compile locally with:

    bash build.sh

After compilation, run:

    python3 scripts/verify_manuscript.py

The **473 passing editorial checks** test preservation, inclusion, labels,
references, explicit boundaries, and compilation. They are not 473 scientific
claims. The final build has no overfull boxes, undefined citations, or undefined
references. Four nonfatal underfull-box warnings were inspected in the rendered
layout. All 70 pages were rendered with Poppler for review. A fresh ZIP extraction was
compiled and rechecked; all 70 rebuilt page rasters match the preview.

## Package contents and provenance

`main.tex`, `preamble.tex`, `sections/`, `appendices/`, `equations/`, and
`statements/` are the editable manuscript. `references.bib` retains the original
bibliography and adds five primary references for the new comparisons.

`scripts/` and `data/` contain the runnable bounded checks and inputs.
`notes/revision_ledger.md` records the changes and qualifications;
`notes/build_receipt.json` records the current execution and layout;
`notes/source_change_report.json` records changes relative to the supplied Draft 4
ZIP. Protection manifests are in `notes/`.

`provenance/draft5/source_ledger.json` identifies the source archive and new
references. Previous editorial records under `provenance/draft4_editorial/`
and other earlier-version directories are historical, not current receipts.
Similarly, explicitly named Draft 3 and Draft 4 summary JSON files in
`data/generated/` are retained historical outputs; the current summary is the
Draft 5 file. Archival upstream producers requiring private inputs are not
included in the claim of executed replays.

`SHA256SUMS.txt` covers delivered files, excluding itself. No uploaded source,
Library file, Drive document, or external repository has been overwritten.
