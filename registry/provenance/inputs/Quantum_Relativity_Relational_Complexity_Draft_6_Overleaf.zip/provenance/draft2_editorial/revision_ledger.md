# Draft 2 revision ledger

## Basis

The revision starts from the exact first-draft Overleaf ZIP dated
21 September 2026, together with its supplied PDF. It incorporates the approved
Mode integration and streamlined physics-audience presentation. The original
three source JSON artifacts are retained byte-for-byte.

## Editorial changes

- Combined title and abstract on one page; added a one-page Results at a glance.
- Replaced the long subsection-level contents with an overview-level guide.
- Removed repeated qualifications from local prose where the same operational
  restriction is retained in a definition, proof hypothesis, Section 50,
  Appendix H, or the qualification map.
- Retained Parts I-VI as the finite mathematical core and folded the former
  unification part into a compact Part VII.
- Condensed former Sections 38-43 into a short Outlook. Retained their thermal
  ensemble and outgoing-weight formulas in Appendix I, along with the exact
  balanced-release definition 40.1.
- Retained Sections 44-55 in compact form under Tests, Guardrails, and Synthesis.
- Removed off-topic interpretive asides. Outcome registration is stated through
  apparatus interaction and the separately specified outcome-selection law.
- Kept the original equation numbers 1-52 and formal statement numbers. Added
  Mode as Section 13A instead of shifting all subsequent sections. This is the
  sole numbering variation from the initially proposed insertion plan.
- Removed the two repeated first-draft synthesis figures in favor of the retained
  ontology equation and shorter prose. Their mathematical content is retained.
- Renamed dynamical 'modes' to 'collective eigenmodes' where required to distinguish
  the new canonical term Mode. The exact original definition 40.1 is copied and
  its use of 'field modes' is explained immediately afterward.

## Mode integration and explicit mathematical scope refinements

1. The approved definition is retained: Mode is the S3 orientation parity of the
   registered event cycle. C_evt and M_evt avoid collisions with the existing
   six-axis conference matrix C and sector/history matrices M.
2. Native provenance comes from the inspected orientation manuscript, Sections
   8-10 and Theorem 10.1. A pinned source excerpt and original-page mapping are
   supplied. The finite frame replay is a new check, not a claim to rerun its
   entire native G60 construction.
3. The six presentations are realized on the explicit ordered closure-frame
   set (r,rho), r and rho distinct reflections. The proof shows that this action
   is free. An abstract S3 action alone would not guarantee a six-point orbit.
4. Absolute positive and negative Mode names require one reference presentation.
   The two-class structure and relative parity survive changing that reference.
   This replaces the earlier shorthand that could suggest an absolute sign on
   an unframed state.
5. Phase and Mode are coordinates with a semidirect-product action. They are not
   two commuting independent dynamics. M_evt conjugates C_evt to its inverse.
6. Event-presentation identity is the declared invariant orbit, not the numerical
   identity of different completed handoffs. The propagation-event definition
   10.1 is unchanged.
7. b/ab are orientation states, Z is a diagonal grading, and M_evt is an action.
   They are not identified by equality of cardinality or by shared terminology.
8. The new frame conjugacy does not, without a common-domain map, establish
   reversal of the separately defined r1 temporal winding or an intertwiner
   on the twelve-history Born space. Those domain distinctions are retained.
9. No new claim of unequal information content between modes, compulsory modal
   alternation, or a mixed-path closure advantage has been added.

## Verification changes

The original 34 mathematical checks are unchanged. Only the inherited script's
report name and scope metadata have been updated; the original source JSON
files are unchanged.

The new history reconstruction enumerates the complete package-local
simple-five-cycle census (12 cycles), generates B_rec (30 by 12), verifies
boundary*B_rec=0 and K_rec^2=5I, and checks an explicit signed-permutation
crosswalk to the supplied Gram. It strengthens matrix reproducibility while
leaving native receipt-name provenance imported.

The new modal replay has 20 checks, covering all six group elements, all six
relative closure frames, and all 36 action-frame cases. Its source constructor
remains imported. Together with 16 history-reconstruction checks and the
34 inherited checks, the finite verification summary contains 70 passing checks.

## Status ledger changes

All original D/P/C/I/H/F claim classes are retained. The earlier I entry for
native extraction is made more precise as 'Native history and receipt
designations'; its native scope remains I. New C history-incidence checks are
listed separately. Native modal provenance is I; the proved/replayed finite
frame algebra is P/C; the Mode identification is D. No physical source,
instrument, action calibration, or geometric reduction is promoted.

## Protected mathematics

The canonical source expressions for equations 1-52 and the original numbered
formal statements are in `notes/preservation_manifest.json`. Each is copied
into a small input file so prose edits cannot silently rewrite it. The integrity
script checks their hashes, single inclusion, protected equation labels,
formal statement order, and compilation references. Proposition 28.1 and its
proof are retained; its common-receipt consequence is made explicit in prose.

## Navigation map

Original 1-13 -> same numbers, shorter prose.
New Mode -> 13A.
Original 14-29 -> same numbers, shorter prose and explicit modal cross-references.
Original 30-37 -> same numbers, compact Part VII.
Original 38-43 -> Outlook and Appendix I; equations 49-50 retained there.
Original 44-55 -> same numbers, compact tests/guardrails/synthesis.
Original Appendices A-H -> retained, with new Mode entries and exact replay scope.
New Appendix I -> conditional collective formulas and release definition.

No new physical result is inferred from the shorter presentation.
