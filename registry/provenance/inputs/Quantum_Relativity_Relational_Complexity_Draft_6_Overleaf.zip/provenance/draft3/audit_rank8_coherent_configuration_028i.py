#!/usr/bin/env python3
"""
Project 41 Audit 028I
Rank-8 Coherent Configuration and Icosahedral Distance Fusion

Purpose
-------
Promote the green Inspection 028I1 into a permanent bounded theorem.

Permanent Audit 028H proves the normalized three-type V4 grammar on

    X = C3 x V4.

The eight ordered-pair atoms are

    T0, Tu, Tv, Tuv, F0, F1, R0, R1.

Here:
- T0, Tu, Tv, Tuv are the four within-cell translations;
- F0, F1 are the two forward character relations;
- R0, R1 are their reverse transposes.

Result
------
1. The eight atoms partition all 144 ordered pairs of X.
2. Their valencies are constant:
   - translation atoms have valency 1;
   - character atoms have valency 2.
3. Transpose closes on the atom set:
   - the four translations are self-transpose;
   - F0^T=R0 and F1^T=R1.
4. All 64 ordered adjacency-matrix products have constant coefficients
   on the eight atoms.
5. The resulting homogeneous coherent configuration has rank 8.
6. Its adjacency algebra is noncommutative.
7. The fusion

       A0 = T0
       A1 = Tu + F0 + R0
       A2 = Tv + F1 + R1
       A3 = Tuv

   is exactly the rank-4 icosahedral distance scheme from Audit 028F.
8. The fused distance-1 graph has intersection array

       {5,2,1; 1,2,5}.

Terminology boundary
--------------------
The rank-8 object is a homogeneous coherent configuration, not a
commutative association scheme. The rank-4 fused distance object is the
commutative icosahedral association scheme.

This audit does not prove a rank-four polytope incidence packet,
construct eight facets, construct 960 flags, or prove a Schlaefli
{5,3,4} rank-four complex.
"""

from __future__ import annotations

from collections import Counter, deque
from datetime import UTC, datetime
from hashlib import sha256
from pathlib import Path
from typing import Dict, Iterable, Mapping, Sequence, Tuple
import json
import os


Vector = Tuple[int, int]
Point = Tuple[int, Vector]
Pair = Tuple[Point, Point]
Matrix = Tuple[Tuple[int, ...], ...]

DEFAULT_PROJECT = (
    Path.home()
    / "dev/cori/research/mathematics/thalean-graph-theory"
    / "41-order-4-dodecahedral-residue"
)

PROJECT = Path(
    os.environ.get("PROJECT41_ROOT", str(DEFAULT_PROJECT))
).expanduser().resolve()

ARTIFACT_DIR = PROJECT / "artifacts/json"

AUDIT028F = (
    ARTIFACT_DIR
    / "dual_icosahedral_distance_decomposition_audit_028f.json"
)

AUDIT028H = (
    ARTIFACT_DIR
    / "v4_affine_character_cell_grammar_audit_028h.json"
)

JSON_OUT = (
    ARTIFACT_DIR
    / "rank8_coherent_configuration_audit_028i.json"
)

MD_OUT = (
    PROJECT
    / "notes"
    / "rank8_coherent_configuration_audit_028i.md"
)

V4 = (
    (0, 0),
    (1, 0),
    (0, 1),
    (1, 1),
)

ATOM_ORDER = (
    "T0",
    "Tu",
    "Tv",
    "Tuv",
    "F0",
    "F1",
    "R0",
    "R1",
)

TRANSLATION_BY_NAME = {
    "T0": (0, 0),
    "Tu": (1, 0),
    "Tv": (0, 1),
    "Tuv": (1, 1),
}

FUSION_ATOMS = {
    "A0": ("T0",),
    "A1": ("Tu", "F0", "R0"),
    "A2": ("Tv", "F1", "R1"),
    "A3": ("Tuv",),
}

FUSION_ORDER = (
    "A0",
    "A1",
    "A2",
    "A3",
)


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def sha256_file(path: Path) -> str:
    digest = sha256()

    with path.open("rb") as handle:
        while True:
            block = handle.read(1024 * 1024)

            if not block:
                break

            digest.update(block)

    return digest.hexdigest()


def load_json(path: Path) -> Mapping[str, object]:
    with path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)

    if not isinstance(payload, dict):
        raise ValueError(f"JSON root must be an object: {path}")

    return payload


def profile(values: Iterable[object]) -> Dict[str, int]:
    counts = Counter(values)

    return {
        str(key): counts[key]
        for key in sorted(counts, key=str)
    }


def xor(left: Vector, right: Vector) -> Vector:
    return (
        left[0] ^ right[0],
        left[1] ^ right[1],
    )


def dot(character: Vector, value: Vector) -> int:
    return (
        (character[0] & value[0])
        ^ (character[1] & value[1])
    )


def canonical_edge(left: int, right: int) -> Tuple[int, int]:
    if left == right:
        raise ValueError("loop edge is not allowed")

    return (
        (left, right)
        if left < right
        else (right, left)
    )


def relation_matrix(
    points: Sequence[Point],
    relation: frozenset[Pair],
) -> Matrix:
    index = {
        point: position
        for position, point
        in enumerate(points)
    }

    rows = [
        [0] * len(points)
        for _ in points
    ]

    for source, target in relation:
        rows[
            index[source]
        ][
            index[target]
        ] = 1

    return tuple(
        tuple(row)
        for row in rows
    )


def matrix_product(
    left: Matrix,
    right: Matrix,
) -> Matrix:
    size = len(left)

    return tuple(
        tuple(
            sum(
                left[row][middle]
                * right[middle][column]
                for middle in range(size)
            )
            for column in range(size)
        )
        for row in range(size)
    )


def matrix_transpose(
    matrix: Matrix,
) -> Matrix:
    size = len(matrix)

    return tuple(
        tuple(
            matrix[column][row]
            for column in range(size)
        )
        for row in range(size)
    )


def matrix_sum(
    matrices: Sequence[Matrix],
) -> Matrix:
    size = len(matrices[0])

    return tuple(
        tuple(
            sum(
                matrix[row][column]
                for matrix in matrices
            )
            for column in range(size)
        )
        for row in range(size)
    )


def graph_distances(
    adjacency: Mapping[int, set],
    start: int,
) -> Dict[int, int]:
    distances = {start: 0}
    queue = deque([start])

    while queue:
        current = queue.popleft()

        for neighbor in adjacency[current]:
            if neighbor not in distances:
                distances[neighbor] = (
                    distances[current]
                    + 1
                )
                queue.append(neighbor)

    return distances


def format_linear_combination(
    coefficients: Mapping[str, int],
    order: Sequence[str],
) -> str:
    terms = []

    for name in order:
        coefficient = coefficients[name]

        if coefficient == 0:
            continue

        if coefficient == 1:
            terms.append(name)
        else:
            terms.append(
                str(coefficient)
                + "*"
                + name
            )

    return "+".join(terms) or "0"


print("OUT ==")
print("timestamp:", utc_now())
print("project:", PROJECT)
print("mutation_performed: pending")
print()

required_sources = (
    AUDIT028F,
    AUDIT028H,
)

missing_sources = [
    path
    for path in required_sources
    if not path.is_file()
]

if missing_sources:
    print("mutation_performed: false")
    print("error: required permanent artifact is missing")

    for path in missing_sources:
        print("missing:", path)

    print("status: project41_audit028i_blocked")
    raise SystemExit(1)

payload028f = load_json(AUDIT028F)
payload028h = load_json(AUDIT028H)

source_pass = {
    "audit028f":
        payload028f.get("audit_pass") is True,
    "audit028h":
        payload028h.get("audit_pass") is True,
}

if not all(source_pass.values()):
    print("mutation_performed: false")
    print("error: one or more required source audits are not green")

    for name, passed in source_pass.items():
        print(name + "_pass:", str(passed).lower())

    print("status: project41_audit028i_blocked")
    raise SystemExit(1)

m28f = payload028f.get("measurements")
m28h = payload028h.get("measurements")

if not isinstance(m28f, dict):
    raise SystemExit("Audit 028F measurements object is missing")

if not isinstance(m28h, dict):
    raise SystemExit("Audit 028H measurements object is missing")

cell_coordinate_rows = m28h.get("cell_coordinate_rows")
canonical_zero_gauge_raw = m28h.get("canonical_zero_gauge")
block_rows = m28h.get("block_rows")

distance1_edges_raw = m28f.get("distance1_graph_edges")
distance2_edges_raw = m28f.get("distance2_graph_edges")
antipode_edges_raw = m28f.get("antipode_edges")

if not (
    isinstance(cell_coordinate_rows, list)
    and len(cell_coordinate_rows) == 3
):
    raise SystemExit("Audit 028H cell_coordinate_rows is missing")

if not isinstance(canonical_zero_gauge_raw, dict):
    raise SystemExit("Audit 028H canonical_zero_gauge is missing")

if not (
    isinstance(block_rows, list)
    and len(block_rows) == 9
):
    raise SystemExit("Audit 028H block_rows is missing")

for name, value in (
    ("distance1_graph_edges", distance1_edges_raw),
    ("distance2_graph_edges", distance2_edges_raw),
    ("antipode_edges", antipode_edges_raw),
):
    if not isinstance(value, list):
        raise SystemExit("Audit 028F " + name + " is missing")

canonical_zero_gauge = {
    int(cell):
        tuple(
            int(bit)
            for bit in shift
        )
    for cell, shift
    in canonical_zero_gauge_raw.items()
}

if set(canonical_zero_gauge) != {0, 1, 2}:
    raise SystemExit(
        "canonical zero gauge does not cover three cells"
    )

# ------------------------------------------------------------------
# Normalized C3 x V4 point coordinates.
# ------------------------------------------------------------------

old_coordinate_by_vertex: Dict[int, Vector] = {}
cell_by_vertex: Dict[int, int] = {}

for row in cell_coordinate_rows:
    if not isinstance(row, dict):
        raise SystemExit("malformed cell coordinate row")

    cell = int(row["cell_index"])
    coordinate_map = row.get("coordinate_map")

    if not isinstance(coordinate_map, list):
        raise SystemExit("cell coordinate map is missing")

    for item in coordinate_map:
        if not isinstance(item, dict):
            raise SystemExit("malformed coordinate-map item")

        vertex = int(item["vertex"])
        coordinate = tuple(
            int(bit)
            for bit in item["coordinate"]
        )

        old_coordinate_by_vertex[vertex] = coordinate
        cell_by_vertex[vertex] = cell

if set(old_coordinate_by_vertex) != set(range(12)):
    raise SystemExit(
        "cell coordinates do not cover twelve vertices"
    )

normalized_coordinate_by_vertex = {
    vertex:
        xor(
            old_coordinate_by_vertex[vertex],
            canonical_zero_gauge[
                cell_by_vertex[vertex]
            ],
        )
    for vertex in range(12)
}

vertex_by_point = {
    (
        cell_by_vertex[vertex],
        normalized_coordinate_by_vertex[vertex],
    ):
        vertex
    for vertex in range(12)
}

points = tuple(
    (
        cell,
        coordinate,
    )
    for cell in range(3)
    for coordinate in V4
)

point_index = {
    point: index
    for index, point
    in enumerate(points)
}

if set(vertex_by_point) != set(points):
    raise SystemExit(
        "normalized C3 x V4 coordinates do not cover twelve points"
    )

# ------------------------------------------------------------------
# Construct the eight atom relations.
# ------------------------------------------------------------------

atoms: Dict[str, frozenset[Pair]] = {}

for name, translation in TRANSLATION_BY_NAME.items():
    atoms[name] = frozenset(
        (
            (cell, source),
            (
                cell,
                xor(
                    source,
                    translation,
                ),
            ),
        )
        for cell in range(3)
        for source in V4
    )

for constant in (0, 1):
    atoms[
        "F" + str(constant)
    ] = frozenset(
        (
            (cell, source),
            (
                (cell + 1) % 3,
                target,
            ),
        )
        for cell in range(3)
        for source in V4
        for target in V4
        if (
            dot(
                (1, 0),
                source,
            )
            ^ dot(
                (0, 1),
                target,
            )
        ) == constant
    )

    atoms[
        "R" + str(constant)
    ] = frozenset(
        (
            (cell, source),
            (
                (cell - 1) % 3,
                target,
            ),
        )
        for cell in range(3)
        for source in V4
        for target in V4
        if (
            dot(
                (0, 1),
                source,
            )
            ^ dot(
                (1, 0),
                target,
            )
        ) == constant
    )

all_ordered_pairs = frozenset(
    (
        source,
        target,
    )
    for source in points
    for target in points
)

atom_union = frozenset().union(
    *(
        atoms[name]
        for name in ATOM_ORDER
    )
)

atom_overlap_count = sum(
    1
    for source in points
    for target in points
    if sum(
        (
            source,
            target,
        ) in atoms[name]
        for name in ATOM_ORDER
    ) > 1
)

atom_matrices = {
    name:
        relation_matrix(
            points,
            atoms[name],
        )
    for name in ATOM_ORDER
}

atom_size_profile = {
    name:
        len(atoms[name])
    for name in ATOM_ORDER
}

atom_valency_profiles = {}

for name in ATOM_ORDER:
    source_counts = Counter(
        source
        for source, _
        in atoms[name]
    )

    target_counts = Counter(
        target
        for _, target
        in atoms[name]
    )

    atom_valency_profiles[name] = {
        "out":
            profile(
                source_counts[
                    point
                ]
                for point in points
            ),
        "in":
            profile(
                target_counts[
                    point
                ]
                for point in points
            ),
    }

# ------------------------------------------------------------------
# Verify all nine permanent Audit 028H blocks.
# ------------------------------------------------------------------

source_block_match_rows = []

for row in sorted(
    block_rows,
    key=lambda item: (
        int(item["positive_cell"]),
        int(item["negative_cell"]),
    ),
):
    positive_cell = int(row["positive_cell"])
    negative_cell = int(row["negative_cell"])
    direction_class = str(row["direction_class"])

    coordinate_pairs = row.get("coordinate_pairs")

    if not isinstance(coordinate_pairs, list):
        raise SystemExit(
            "Audit 028H coordinate_pairs is missing"
        )

    normalized_pairs = frozenset(
        (
            (
                positive_cell,
                xor(
                    tuple(
                        int(bit)
                        for bit in pair["source"]
                    ),
                    canonical_zero_gauge[
                        positive_cell
                    ],
                ),
            ),
            (
                negative_cell,
                xor(
                    tuple(
                        int(bit)
                        for bit in pair["target"]
                    ),
                    canonical_zero_gauge[
                        negative_cell
                    ],
                ),
            ),
        )
        for pair in coordinate_pairs
    )

    if direction_class == "diagonal":
        atom_name = "Tu"
    elif direction_class == "forward":
        atom_name = "F0"
    elif direction_class == "reverse":
        atom_name = "R0"
    else:
        raise SystemExit(
            "unexpected Audit 028H direction class"
        )

    expected_restriction = frozenset(
        pair
        for pair in atoms[atom_name]
        if (
            pair[0][0] == positive_cell
            and pair[1][0] == negative_cell
        )
    )

    source_block_match_rows.append({
        "block": [
            positive_cell,
            negative_cell,
        ],
        "direction_class":
            direction_class,
        "atom_name":
            atom_name,
        "observed_pair_count":
            len(normalized_pairs),
        "expected_pair_count":
            len(expected_restriction),
        "exact_match":
            normalized_pairs
            == expected_restriction,
    })

# ------------------------------------------------------------------
# Transpose registry and 64 atom products.
# ------------------------------------------------------------------

transpose_rows = []

for name in ATOM_ORDER:
    transpose_matrix = matrix_transpose(
        atom_matrices[name]
    )

    matches = tuple(
        candidate
        for candidate in ATOM_ORDER
        if atom_matrices[candidate]
        == transpose_matrix
    )

    transpose_rows.append({
        "atom":
            name,
        "transpose_matches":
            list(matches),
    })

multiplication_rows = []
multiplication_closure = True

for left_name in ATOM_ORDER:
    for right_name in ATOM_ORDER:
        product_matrix = matrix_product(
            atom_matrices[left_name],
            atom_matrices[right_name],
        )

        coefficients = {}
        product_constant_on_atoms = True

        for atom_name in ATOM_ORDER:
            values = {
                product_matrix[
                    point_index[source]
                ][
                    point_index[target]
                ]
                for source, target
                in atoms[atom_name]
            }

            if len(values) != 1:
                product_constant_on_atoms = False
                coefficient = None
            else:
                coefficient = int(
                    next(iter(values))
                )

            coefficients[atom_name] = coefficient

        multiplication_closure = (
            multiplication_closure
            and product_constant_on_atoms
        )

        multiplication_rows.append({
            "left":
                left_name,
            "right":
                right_name,
            "constant_on_atoms":
                product_constant_on_atoms,
            "coefficients":
                coefficients,
            "expression":
                (
                    format_linear_combination(
                        coefficients,
                        ATOM_ORDER,
                    )
                    if product_constant_on_atoms
                    else "unresolved"
                ),
        })

multiplication_by_pair = {
    (
        row["left"],
        row["right"],
    ):
        row
    for row in multiplication_rows
}

noncommutative_witnesses = []

for left_name in ATOM_ORDER:
    for right_name in ATOM_ORDER:
        forward = multiplication_by_pair[
            (
                left_name,
                right_name,
            )
        ]["coefficients"]

        reverse = multiplication_by_pair[
            (
                right_name,
                left_name,
            )
        ]["coefficients"]

        if forward != reverse:
            noncommutative_witnesses.append({
                "left":
                    left_name,
                "right":
                    right_name,
                "left_right":
                    multiplication_by_pair[
                        (
                            left_name,
                            right_name,
                        )
                    ]["expression"],
                "right_left":
                    multiplication_by_pair[
                        (
                            right_name,
                            left_name,
                        )
                    ]["expression"],
            })

# ------------------------------------------------------------------
# Rank-4 icosahedral distance fusion.
# ------------------------------------------------------------------

fusion_matrices = {
    name:
        matrix_sum(
            tuple(
                atom_matrices[
                    atom_name
                ]
                for atom_name
                in atom_names
            )
        )
    for name, atom_names
    in FUSION_ATOMS.items()
}

fusion_edges_actual = {}

for name in (
    "A1",
    "A2",
    "A3",
):
    matrix = fusion_matrices[name]
    edges = set()

    for source_position, source in enumerate(points):
        for target_position, target in enumerate(points):
            if (
                source_position < target_position
                and matrix[
                    source_position
                ][
                    target_position
                ]
            ):
                edges.add(
                    canonical_edge(
                        vertex_by_point[source],
                        vertex_by_point[target],
                    )
                )

    fusion_edges_actual[name] = frozenset(edges)

audit_distance_edges = {
    "A1":
        frozenset(
            canonical_edge(
                int(edge[0]),
                int(edge[1]),
            )
            for edge in distance1_edges_raw
        ),
    "A2":
        frozenset(
            canonical_edge(
                int(edge[0]),
                int(edge[1]),
            )
            for edge in distance2_edges_raw
        ),
    "A3":
        frozenset(
            canonical_edge(
                int(edge[0]),
                int(edge[1]),
            )
            for edge in antipode_edges_raw
        ),
}

fusion_edge_match = {
    name:
        fusion_edges_actual[name]
        == audit_distance_edges[name]
    for name in (
        "A1",
        "A2",
        "A3",
    )
}

adjacency = {
    vertex: set()
    for vertex in range(12)
}

for left, right in fusion_edges_actual["A1"]:
    adjacency[left].add(right)
    adjacency[right].add(left)

distance_matrix = {
    vertex:
        graph_distances(
            adjacency,
            vertex,
        )
    for vertex in range(12)
}

distance_profile = profile(
    distance
    for distances
    in distance_matrix.values()
    for distance
    in distances.values()
)

intersection_rows = []

for distance in range(4):
    signatures = set()

    for source in range(12):
        for target in range(12):
            if (
                distance_matrix[source][target]
                != distance
            ):
                continue

            neighbor_distance_profile = Counter(
                distance_matrix[source][neighbor]
                for neighbor
                in adjacency[target]
            )

            signatures.add(
                tuple(
                    sorted(
                        neighbor_distance_profile.items()
                    )
                )
            )

    intersection_rows.append({
        "distance":
            distance,
        "signature_count":
            len(signatures),
        "signatures": [
            [
                [
                    int(level),
                    int(count),
                ]
                for level, count
                in signature
            ]
            for signature
            in sorted(signatures)
        ],
    })

fusion_multiplication_rows = []

for left_name in FUSION_ORDER:
    for right_name in FUSION_ORDER:
        product_matrix = matrix_product(
            fusion_matrices[left_name],
            fusion_matrices[right_name],
        )

        coefficients = {}
        constant_on_fusion = True

        for relation_name in FUSION_ORDER:
            relation_matrix_value = (
                fusion_matrices[
                    relation_name
                ]
            )

            values = {
                product_matrix[row][column]
                for row in range(12)
                for column in range(12)
                if relation_matrix_value[
                    row
                ][
                    column
                ]
            }

            if len(values) != 1:
                constant_on_fusion = False
                coefficients[
                    relation_name
                ] = None
            else:
                coefficients[
                    relation_name
                ] = int(
                    next(iter(values))
                )

        fusion_multiplication_rows.append({
            "left":
                left_name,
            "right":
                right_name,
            "constant_on_fusion":
                constant_on_fusion,
            "coefficients":
                coefficients,
            "expression":
                (
                    format_linear_combination(
                        coefficients,
                        FUSION_ORDER,
                    )
                    if constant_on_fusion
                    else "unresolved"
                ),
        })

expected_intersection_rows = [
    {
        "distance": 0,
        "signature_count": 1,
        "signatures": [
            [
                [1, 5],
            ],
        ],
    },
    {
        "distance": 1,
        "signature_count": 1,
        "signatures": [
            [
                [0, 1],
                [1, 2],
                [2, 2],
            ],
        ],
    },
    {
        "distance": 2,
        "signature_count": 1,
        "signatures": [
            [
                [1, 2],
                [2, 2],
                [3, 1],
            ],
        ],
    },
    {
        "distance": 3,
        "signature_count": 1,
        "signatures": [
            [
                [2, 5],
            ],
        ],
    },
]

checks = {
    "all_required_source_audits_pass":
        all(source_pass.values()),
    "normalized_point_count12":
        len(points) == 12,
    "atom_count8":
        len(atoms) == 8,
    "atoms_partition_all144_ordered_pairs":
        atom_union
        == all_ordered_pairs,
    "atom_overlap_count_zero":
        atom_overlap_count == 0,
    "atom_size_profile_12x4_24x4":
        profile(
            atom_size_profile.values()
        ) == {
            "12": 4,
            "24": 4,
        },
    "atom_valencies_constant":
        all(
            row["out"]
            in (
                {"1": 12},
                {"2": 12},
            )
            and row["in"]
            in (
                {"1": 12},
                {"2": 12},
            )
            for row
            in atom_valency_profiles.values()
        ),
    "all_Audit028H_blocks_match_atoms_after_gauge":
        all(
            row["exact_match"]
            for row
            in source_block_match_rows
        ),
    "transpose_closes_on_one_atom":
        all(
            len(
                row["transpose_matches"]
            ) == 1
            for row
            in transpose_rows
        ),
    "all64_atom_products_close":
        multiplication_closure
        and len(
            multiplication_rows
        ) == 64,
    "rank8_adjacency_algebra_is_noncommutative":
        bool(
            noncommutative_witnesses
        ),
    "distance1_fusion_matches_Audit028F":
        fusion_edge_match["A1"],
    "distance2_fusion_matches_Audit028F":
        fusion_edge_match["A2"],
    "distance3_fusion_matches_Audit028F":
        fusion_edge_match["A3"],
    "distance_profile_1_5_5_1":
        distance_profile
        == {
            "0": 12,
            "1": 60,
            "2": 60,
            "3": 12,
        },
    "distance_partition_has_one_intersection_signature_each":
        all(
            row["signature_count"] == 1
            for row
            in intersection_rows
        ),
    "icosahedral_intersection_array_5_2_1__1_2_5":
        intersection_rows
        == expected_intersection_rows,
    "all16_fusion_products_close":
        all(
            row["constant_on_fusion"]
            for row
            in fusion_multiplication_rows
        )
        and len(
            fusion_multiplication_rows
        ) == 16,
}

audit_pass = all(checks.values())

print("== rank-8 atom partition ==")
print("point_count:", len(points))
print("atom_count:", len(atoms))
print("ordered_pair_count:", len(all_ordered_pairs))
print("atom_union_count:", len(atom_union))
print("atom_overlap_count:", atom_overlap_count)
print("atom_size_profile:", atom_size_profile)
print("atom_valency_profiles:", atom_valency_profiles)
print()

print("== permanent source block matches ==")

for row in source_block_match_rows:
    print(
        "block="
        + str(
            tuple(
                row["block"]
            )
        ),
        "class="
        + row["direction_class"],
        "atom="
        + row["atom_name"],
        "observed="
        + str(
            row["observed_pair_count"]
        ),
        "expected="
        + str(
            row["expected_pair_count"]
        ),
        "exact="
        + str(
            row["exact_match"]
        ).lower(),
    )

print()
print("== transpose registry ==")

for row in transpose_rows:
    print(
        "atom="
        + row["atom"],
        "transpose="
        + str(
            tuple(
                row["transpose_matches"]
            )
        ),
    )

print()
print("== atom multiplication table ==")

for left_name in ATOM_ORDER:
    entries = []

    for right_name in ATOM_ORDER:
        row = multiplication_by_pair[
            (
                left_name,
                right_name,
            )
        ]

        entries.append(
            right_name
            + "->"
            + row["expression"]
        )

    print(
        left_name
        + ": "
        + " | ".join(entries)
    )

print()
print(
    "noncommutative_witness_count:",
    len(
        noncommutative_witnesses
    ),
)

for row in noncommutative_witnesses[:12]:
    print(
        "witness "
        + row["left"]
        + "*"
        + row["right"]
        + "="
        + row["left_right"]
        + " but "
        + row["right"]
        + "*"
        + row["left"]
        + "="
        + row["right_left"]
    )

print()
print("== icosahedral distance fusion ==")
print("fusion_atom_names:", FUSION_ATOMS)
print(
    "distance1_edge_count:",
    len(
        fusion_edges_actual["A1"]
    ),
)
print(
    "distance2_edge_count:",
    len(
        fusion_edges_actual["A2"]
    ),
)
print(
    "distance3_edge_count:",
    len(
        fusion_edges_actual["A3"]
    ),
)
print("fusion_edge_match:", fusion_edge_match)
print("distance_profile:", distance_profile)
print("intersection_rows:", intersection_rows)
print()

print("== fused multiplication table ==")

fusion_product_by_pair = {
    (
        row["left"],
        row["right"],
    ):
        row
    for row in fusion_multiplication_rows
}

for left_name in FUSION_ORDER:
    entries = []

    for right_name in FUSION_ORDER:
        row = fusion_product_by_pair[
            (
                left_name,
                right_name,
            )
        ]

        entries.append(
            right_name
            + "->"
            + row["expression"]
        )

    print(
        left_name
        + ": "
        + " | ".join(entries)
    )

print()
print("== checks ==")

for name, passed in checks.items():
    print(
        name + ":",
        str(passed).lower(),
    )

verdict = (
    "the_exact_V4_cell_grammar_extends_to_a_rank8_noncommutative_"
    "homogeneous_coherent_configuration_on_C3_times_V4_with_four_"
    "translation_atoms_and_four_character_atoms_and_the_fusion_"
    "T0__Tu_F0_R0__Tv_F1_R1__Tuv_is_exactly_the_rank4_icosahedral_"
    "distance_association_scheme_with_intersection_array_5_2_1__"
    "1_2_5"
    if audit_pass
    else
    "the_candidate_rank8_coherent_configuration_or_icosahedral_"
    "distance_fusion_theorem_has_unresolved_partition_transpose_"
    "product_source_or_intersection_failures"
)

artifact = {
    "audit_id":
        "rank8_coherent_configuration_audit_028i",
    "timestamp":
        utc_now(),
    "audit_pass":
        audit_pass,
    "verdict":
        verdict,
    "sources": {
        "audit028f": {
            "path":
                str(AUDIT028F),
            "sha256":
                sha256_file(
                    AUDIT028F
                ),
            "audit_pass":
                source_pass["audit028f"],
            "verdict":
                payload028f.get("verdict"),
        },
        "audit028h": {
            "path":
                str(AUDIT028H),
            "sha256":
                sha256_file(
                    AUDIT028H
                ),
            "audit_pass":
                source_pass["audit028h"],
            "verdict":
                payload028h.get("verdict"),
        },
    },
    "measurements": {
        "point_set":
            [
                {
                    "cell":
                        cell,
                    "coordinate":
                        list(coordinate),
                    "face_vertex":
                        vertex_by_point[
                            (
                                cell,
                                coordinate,
                            )
                        ],
                }
                for cell, coordinate
                in points
            ],
        "atom_order":
            list(ATOM_ORDER),
        "atom_sizes":
            atom_size_profile,
        "atom_valency_profiles":
            atom_valency_profiles,
        "source_block_match_rows":
            source_block_match_rows,
        "transpose_rows":
            transpose_rows,
        "multiplication_rows":
            multiplication_rows,
        "noncommutative_witness_count":
            len(
                noncommutative_witnesses
            ),
        "noncommutative_witnesses":
            noncommutative_witnesses,
        "fusion_atoms": {
            name:
                list(atom_names)
            for name, atom_names
            in FUSION_ATOMS.items()
        },
        "fusion_edge_match":
            fusion_edge_match,
        "fusion_edge_counts": {
            "A1":
                len(
                    fusion_edges_actual["A1"]
                ),
            "A2":
                len(
                    fusion_edges_actual["A2"]
                ),
            "A3":
                len(
                    fusion_edges_actual["A3"]
                ),
        },
        "distance_profile":
            distance_profile,
        "intersection_rows":
            intersection_rows,
        "intersection_array":
            "{5,2,1;1,2,5}",
        "fusion_multiplication_rows":
            fusion_multiplication_rows,
    },
    "checks":
        checks,
    "interpretation": (
        "The V4 cell grammar from Audit 028H is the visible part of a "
        "complete ordered-pair partition on C3 times V4. The four "
        "within-cell translation relations and four directed character "
        "relations form a rank-8 homogeneous coherent configuration. "
        "Its adjacency algebra is noncommutative, as expected from the "
        "oriented forward/reverse refinement. Fusing orientation and "
        "character complement recovers exactly the commutative rank-4 "
        "icosahedral distance association scheme."
    ),
    "boundary": {
        "rank8_homogeneous_coherent_configuration_proved":
            audit_pass,
        "rank8_object_is_association_scheme":
            False,
        "rank8_adjacency_algebra_noncommutative":
            audit_pass,
        "rank4_icosahedral_distance_association_scheme_fusion_proved":
            audit_pass,
        "icosahedral_intersection_array_proved":
            audit_pass,
        "rank_four_polytope_incidence_packet_proved":
            False,
        "eight_rank_four_facets_constructed":
            False,
        "actual_960_flag_set_constructed":
            False,
        "schlafli_5_3_4_rank_four_complex_proved":
            False,
    },
    "next_target": (
        "Audit 028J should classify the rank-8 coherent configuration "
        "intrinsically. Compute its automorphism group, orbital "
        "realization candidates, and irreducible adjacency-algebra "
        "decomposition without using downstream rank-four labels. The "
        "next question is whether the oriented rank-8 refinement is a "
        "Schurian orbital configuration and how its automorphisms sit "
        "inside the full icosahedral automorphism group."
    ),
    "keeper": (
        "The oriented grammar is rank eight. Forgetting its orientation "
        "and character split returns the icosahedral distance scheme."
    ),
}

markdown_lines = [
    "# Rank-8 Coherent Configuration Audit 028I",
    "",
    f"Audit pass: {str(audit_pass).lower()}",
    "",
    f"Verdict: `{verdict}`",
    "",
    "## Result",
    "",
    "The eight relations",
    "",
    "    T0, Tu, Tv, Tuv, F0, F1, R0, R1",
    "",
    "partition all 144 ordered pairs of C3 x V4. Transpose closes,",
    "and all 64 ordered adjacency-matrix products have constant",
    "coefficients on the eight atoms.",
    "",
    "The resulting object is a rank-8 homogeneous coherent",
    "configuration. Its adjacency algebra is noncommutative.",
    "",
    "The fusion",
    "",
    "    A0 = T0",
    "    A1 = Tu + F0 + R0",
    "    A2 = Tv + F1 + R1",
    "    A3 = Tuv",
    "",
    "is exactly the rank-4 icosahedral distance association scheme",
    "with intersection array",
    "",
    "    {5,2,1; 1,2,5}.",
    "",
    "## Terminology boundary",
    "",
    "The rank-8 refinement is not an association scheme because its",
    "adjacency algebra is noncommutative. The rank-4 fusion is the",
    "commutative icosahedral association scheme.",
    "",
    "No rank-four polytope incidence packet, eight facets, 960 flags,",
    "or {5,3,4} complex is claimed.",
    "",
    "## Keeper",
    "",
    artifact["keeper"],
    "",
]

if audit_pass:
    JSON_OUT.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    MD_OUT.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    JSON_OUT.write_text(
        json.dumps(
            artifact,
            indent=2,
            sort_keys=True,
        ) + "\n",
        encoding="utf-8",
    )

    MD_OUT.write_text(
        "\n".join(
            markdown_lines
        ),
        encoding="utf-8",
    )

print()
print(
    "audit_pass:",
    str(audit_pass).lower(),
)
print(
    "verdict:",
    verdict,
)
print(
    "rank8_homogeneous_coherent_configuration_proved:",
    str(audit_pass).lower(),
)
print(
    "coherent_configuration_rank:",
    8
    if audit_pass
    else "unresolved",
)
print(
    "rank8_object_is_association_scheme:",
    "false",
)
print(
    "rank8_adjacency_algebra_noncommutative:",
    str(
        checks[
            "rank8_adjacency_algebra_is_noncommutative"
        ]
    ).lower(),
)
print(
    "rank4_icosahedral_distance_association_scheme_fusion_proved:",
    str(
        checks[
            "distance1_fusion_matches_Audit028F"
        ]
        and checks[
            "distance2_fusion_matches_Audit028F"
        ]
        and checks[
            "distance3_fusion_matches_Audit028F"
        ]
        and checks[
            "all16_fusion_products_close"
        ]
    ).lower(),
)
print(
    "intersection_array:",
    "{5,2,1;1,2,5}"
    if checks[
        "icosahedral_intersection_array_5_2_1__1_2_5"
    ]
    else "unresolved",
)
print(
    "rank_four_polytope_incidence_packet_proved:",
    "false",
)
print(
    "eight_rank_four_facets_constructed:",
    "false",
)
print(
    "actual_960_flag_set_constructed:",
    "false",
)
print(
    "schlafli_5_3_4_rank_four_complex_proved:",
    "false",
)
print()

if audit_pass:
    print("mutation_performed: true")
    print("json_artifact:", JSON_OUT)
    print("markdown_artifact:", MD_OUT)
    print("commit_created: false")
    print("push_performed: false")
    print(
        "status:",
        "rank8_coherent_configuration_audit_028i_complete",
    )
else:
    print("mutation_performed: false")
    print(
        "status:",
        "rank8_coherent_configuration_audit_028i_failed",
    )
    raise SystemExit(1)
