#!/usr/bin/env python3
"""
Project 41 Audit 028J
Rank-8 Schurian Automorphism Group

Purpose
-------
Promote the green Inspection 028J1 into a permanent bounded theorem.

Permanent Audit 028I proves a rank-8 noncommutative homogeneous coherent
configuration on

    X = C3 x V4

with atoms

    T0, Tu, Tv, Tuv, F0, F1, R0, R1.

This audit classifies the exact color-preserving automorphism group,
proves Schurity, and places the refinement inside the full icosahedral
graph automorphism group.

Exact color-preserving census
-----------------------------
The four translation atoms force every color-preserving automorphism to
have the bounded form

    (i,x) -> (i+r, x+s_i)

with:
- r in C3;
- one shift s_i in V4 for each cell.

Thus exactly

    3 * 4^3 = 192

candidates must be checked.

Result
------
1. Exactly 24 candidates preserve all eight atoms.
2. The color-preserving automorphism group is

       C2 x A4

   of order 24.
3. The action is transitive on 12 points with point stabilizer order 2.
4. Its eight orbitals are exactly the eight coherent-configuration atoms.
   Therefore the rank-8 coherent configuration is Schurian.
5. The fused distance-1 graph has full automorphism group of order 120.
6. The color group is a self-normalizing subgroup of index 5.
7. Therefore the fused icosahedral graph contains exactly five conjugate
   rank-8 refinements of this type.

Boundary
--------
This proves a finite automorphism and orbital theorem for the rank-8
coherent configuration. It does not prove a rank-four polytope incidence
packet, construct eight facets, construct 960 flags, or prove a
Schlaefli {5,3,4} rank-four complex.
"""

from __future__ import annotations

from collections import Counter, deque
from datetime import UTC, datetime
from hashlib import sha256
from itertools import permutations, product
from pathlib import Path
from typing import Dict, Iterable, Mapping, Sequence, Tuple
import json
import os


Vector = Tuple[int, int]
Point = Tuple[int, Vector]
PairIndex = Tuple[int, int]
Permutation = Tuple[int, ...]

DEFAULT_PROJECT = (
    Path.home()
    / "dev/cori/research/mathematics/thalean-graph-theory"
    / "41-order-4-dodecahedral-residue"
)

PROJECT = Path(
    os.environ.get("PROJECT41_ROOT", str(DEFAULT_PROJECT))
).expanduser().resolve()

ARTIFACT_DIR = PROJECT / "artifacts/json"

AUDIT028I = (
    ARTIFACT_DIR
    / "rank8_coherent_configuration_audit_028i.json"
)

JSON_OUT = (
    ARTIFACT_DIR
    / "rank8_schurian_automorphism_group_audit_028j.json"
)

MD_OUT = (
    PROJECT
    / "notes"
    / "rank8_schurian_automorphism_group_audit_028j.md"
)

V4 = (
    (0, 0),
    (1, 0),
    (0, 1),
    (1, 1),
)

ATOM_ORDER = (
    "T0",
    "Tu",
    "Tv",
    "Tuv",
    "F0",
    "F1",
    "R0",
    "R1",
)

TRANSLATION_BY_NAME = {
    "T0": (0, 0),
    "Tu": (1, 0),
    "Tv": (0, 1),
    "Tuv": (1, 1),
}


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def sha256_file(path: Path) -> str:
    digest = sha256()

    with path.open("rb") as handle:
        while True:
            block = handle.read(1024 * 1024)

            if not block:
                break

            digest.update(block)

    return digest.hexdigest()


def load_json(path: Path) -> Mapping[str, object]:
    with path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)

    if not isinstance(payload, dict):
        raise ValueError(f"JSON root must be an object: {path}")

    return payload


def profile(values: Iterable[object]) -> Dict[str, int]:
    counts = Counter(values)

    return {
        str(key): counts[key]
        for key in sorted(counts, key=str)
    }


def xor(left: Vector, right: Vector) -> Vector:
    return (
        left[0] ^ right[0],
        left[1] ^ right[1],
    )


def dot(character: Vector, value: Vector) -> int:
    return (
        (character[0] & value[0])
        ^ (character[1] & value[1])
    )


def compose(
    left: Sequence[int],
    right: Sequence[int],
) -> Permutation:
    return tuple(
        int(left[right[index]])
        for index in range(len(left))
    )


def inverse(
    permutation: Sequence[int],
) -> Permutation:
    result = [-1] * len(permutation)

    for source, target in enumerate(permutation):
        if result[target] != -1:
            raise ValueError("permutation is not injective")

        result[target] = source

    if any(value == -1 for value in result):
        raise ValueError("permutation is not surjective")

    return tuple(result)


def identity(size: int) -> Permutation:
    return tuple(range(size))


def permutation_order(
    permutation: Sequence[int],
) -> int:
    current = identity(len(permutation))

    for order in range(1, 1000):
        current = compose(
            permutation,
            current,
        )

        if current == identity(len(permutation)):
            return order

    raise ValueError("permutation order exceeded bound")


def preserves_relation(
    permutation: Sequence[int],
    relation: frozenset[PairIndex],
) -> bool:
    return frozenset(
        (
            permutation[source],
            permutation[target],
        )
        for source, target
        in relation
    ) == relation


def graph_distances(
    adjacency: Mapping[int, set],
    start: int,
) -> Dict[int, int]:
    distances = {start: 0}
    queue = deque([start])

    while queue:
        current = queue.popleft()

        for neighbor in adjacency[current]:
            if neighbor not in distances:
                distances[neighbor] = (
                    distances[current]
                    + 1
                )
                queue.append(neighbor)

    return distances


def graph_preserved(
    permutation: Sequence[int],
    adjacency: Mapping[int, set],
) -> bool:
    return all(
        {
            permutation[neighbor]
            for neighbor in adjacency[vertex]
        }
        == adjacency[
            permutation[vertex]
        ]
        for vertex in adjacency
    )


def subgroup_generated(
    generators: Iterable[Permutation],
    size: int,
) -> frozenset[Permutation]:
    group = {
        identity(size)
    }

    frontier = list(generators)

    while frontier:
        candidate = frontier.pop()

        if candidate in group:
            continue

        existing = tuple(group)
        group.add(candidate)

        for element in existing:
            frontier.append(
                compose(
                    candidate,
                    element,
                )
            )
            frontier.append(
                compose(
                    element,
                    candidate,
                )
            )

    return frozenset(group)


def commutator(
    left: Permutation,
    right: Permutation,
) -> Permutation:
    return compose(
        inverse(left),
        compose(
            inverse(right),
            compose(
                left,
                right,
            ),
        ),
    )


def ordered_triangles(
    adjacency: Mapping[int, set],
) -> Tuple[Tuple[int, int, int], ...]:
    triangles = set()

    for left in adjacency:
        for middle in adjacency[left]:
            for right in (
                adjacency[left]
                & adjacency[middle]
            ):
                if len({
                    left,
                    middle,
                    right,
                }) != 3:
                    continue

                triangle = tuple(
                    sorted(
                        (
                            left,
                            middle,
                            right,
                        )
                    )
                )

                for ordering in permutations(
                    triangle
                ):
                    triangles.add(
                        tuple(ordering)
                    )

    return tuple(sorted(triangles))


def extend_ordered_triangle_map(
    adjacency: Mapping[int, set],
    distances: Mapping[int, Mapping[int, int]],
    source_triangle: Tuple[int, int, int],
    target_triangle: Tuple[int, int, int],
) -> Tuple[Permutation, ...]:
    size = len(adjacency)

    mapping = {
        source_triangle[index]:
            target_triangle[index]
        for index in range(3)
    }

    used_targets = set(
        mapping.values()
    )

    source_signatures = {
        source:
            tuple(
                distances[source][
                    source_triangle[index]
                ]
                for index in range(3)
            )
        for source in range(size)
    }

    target_signatures = {
        target:
            tuple(
                distances[target][
                    target_triangle[index]
                ]
                for index in range(3)
            )
        for target in range(size)
    }

    candidate_targets = {
        source:
            tuple(
                target
                for target in range(size)
                if target_signatures[target]
                == source_signatures[source]
            )
        for source in range(size)
    }

    results = []

    def search() -> None:
        if len(mapping) == size:
            permutation = tuple(
                mapping[source]
                for source in range(size)
            )

            if graph_preserved(
                permutation,
                adjacency,
            ):
                results.append(
                    permutation
                )

            return

        unmapped = [
            source
            for source in range(size)
            if source not in mapping
        ]

        feasible_by_source = {}

        for source in unmapped:
            feasible = []

            for target in candidate_targets[source]:
                if target in used_targets:
                    continue

                consistent = all(
                    (
                        mapped_source
                        in adjacency[source]
                    )
                    == (
                        mapping[mapped_source]
                        in adjacency[target]
                    )
                    for mapped_source
                    in mapping
                )

                if consistent:
                    feasible.append(target)

            feasible_by_source[source] = feasible

        source = min(
            unmapped,
            key=lambda candidate: (
                len(
                    feasible_by_source[
                        candidate
                    ]
                ),
                -sum(
                    1
                    for neighbor
                    in adjacency[candidate]
                    if neighbor in mapping
                ),
                candidate,
            ),
        )

        for target in feasible_by_source[source]:
            mapping[source] = target
            used_targets.add(target)

            search()

            used_targets.remove(target)
            del mapping[source]

    search()

    return tuple(
        sorted(
            set(results)
        )
    )


def orbital_partition(
    group: Sequence[Permutation],
    size: int,
) -> Tuple[frozenset[PairIndex], ...]:
    unseen = {
        (
            source,
            target,
        )
        for source in range(size)
        for target in range(size)
    }

    orbitals = []

    while unseen:
        seed = min(unseen)

        orbital = frozenset(
            (
                permutation[seed[0]],
                permutation[seed[1]],
            )
            for permutation in group
        )

        unseen.difference_update(
            orbital
        )

        orbitals.append(
            orbital
        )

    return tuple(
        sorted(
            orbitals,
            key=lambda relation: (
                len(relation),
                min(relation),
            ),
        )
    )


print("OUT ==")
print("timestamp:", utc_now())
print("project:", PROJECT)
print("mutation_performed: pending")
print()

if not AUDIT028I.is_file():
    print("mutation_performed: false")
    print(
        "error: required permanent Audit 028I artifact is missing"
    )
    print("missing:", AUDIT028I)
    print("status: project41_audit028j_blocked")
    raise SystemExit(1)

payload028i = load_json(
    AUDIT028I
)

if payload028i.get(
    "audit_pass"
) is not True:
    print("mutation_performed: false")
    print(
        "error: permanent Audit 028I is not green"
    )
    print("status: project41_audit028j_blocked")
    raise SystemExit(1)

measurements = payload028i.get(
    "measurements"
)

if not isinstance(
    measurements,
    dict,
):
    raise SystemExit(
        "Audit 028I measurements object is missing"
    )

point_set_rows = measurements.get(
    "point_set"
)

if not (
    isinstance(
        point_set_rows,
        list,
    )
    and len(
        point_set_rows
    ) == 12
):
    raise SystemExit(
        "Audit 028I point_set is missing"
    )

points = tuple(
    (
        int(row["cell"]),
        tuple(
            int(bit)
            for bit in row["coordinate"]
        ),
    )
    for row in point_set_rows
)

if len(set(points)) != 12:
    raise SystemExit(
        "Audit 028I point_set contains duplicates"
    )

point_index = {
    point: index
    for index, point
    in enumerate(points)
}

# ------------------------------------------------------------------
# Reconstruct the eight atoms.
# ------------------------------------------------------------------

atom_relations: Dict[
    str,
    frozenset[PairIndex],
] = {}

for name, translation in (
    TRANSLATION_BY_NAME.items()
):
    atom_relations[name] = frozenset(
        (
            point_index[
                (
                    cell,
                    source,
                )
            ],
            point_index[
                (
                    cell,
                    xor(
                        source,
                        translation,
                    ),
                )
            ],
        )
        for cell in range(3)
        for source in V4
    )

for constant in (
    0,
    1,
):
    atom_relations[
        "F" + str(constant)
    ] = frozenset(
        (
            point_index[
                (
                    cell,
                    source,
                )
            ],
            point_index[
                (
                    (
                        cell
                        + 1
                    ) % 3,
                    target,
                )
            ],
        )
        for cell in range(3)
        for source in V4
        for target in V4
        if (
            dot(
                (1, 0),
                source,
            )
            ^ dot(
                (0, 1),
                target,
            )
        ) == constant
    )

    atom_relations[
        "R" + str(constant)
    ] = frozenset(
        (
            point_index[
                (
                    cell,
                    source,
                )
            ],
            point_index[
                (
                    (
                        cell
                        - 1
                    ) % 3,
                    target,
                )
            ],
        )
        for cell in range(3)
        for source in V4
        for target in V4
        if (
            dot(
                (0, 1),
                source,
            )
            ^ dot(
                (1, 0),
                target,
            )
        ) == constant
    )

# ------------------------------------------------------------------
# Exhaustive 192-candidate color automorphism census.
# ------------------------------------------------------------------

candidate_rows = []
accepted_group = []
accepted_metadata = {}

for rotation in range(3):
    for shifts in product(
        V4,
        repeat=3,
    ):
        permutation = tuple(
            point_index[
                (
                    (
                        cell
                        + rotation
                    ) % 3,
                    xor(
                        coordinate,
                        shifts[cell],
                    ),
                )
            ]
            for cell, coordinate
            in points
        )

        preserved_atoms = tuple(
            name
            for name in ATOM_ORDER
            if preserves_relation(
                permutation,
                atom_relations[name],
            )
        )

        accepted = (
            len(preserved_atoms) == 8
        )

        candidate_rows.append({
            "rotation":
                rotation,
            "shifts": [
                list(shift)
                for shift in shifts
            ],
            "accepted":
                accepted,
            "preserved_atom_count":
                len(
                    preserved_atoms
                ),
        })

        if accepted:
            accepted_group.append(
                permutation
            )

            accepted_metadata[
                permutation
            ] = {
                "rotation":
                    rotation,
                "shifts":
                    shifts,
            }

accepted_group = tuple(
    sorted(
        set(
            accepted_group
        )
    )
)

accepted_group_set = frozenset(
    accepted_group
)

identity12 = identity(12)

group_closure = all(
    compose(
        left,
        right,
    ) in accepted_group_set
    for left in accepted_group
    for right in accepted_group
)

inverse_closure = all(
    inverse(
        permutation
    ) in accepted_group_set
    for permutation in accepted_group
)

element_order_profile = profile(
    permutation_order(
        permutation
    )
    for permutation
    in accepted_group
)

cell_rotation_profile = profile(
    accepted_metadata[
        permutation
    ]["rotation"]
    for permutation
    in accepted_group
)

kernel = tuple(
    permutation
    for permutation
    in accepted_group
    if accepted_metadata[
        permutation
    ]["rotation"] == 0
)

kernel_shift_rows = []

for permutation in kernel:
    shifts = accepted_metadata[
        permutation
    ]["shifts"]

    b = (
        shifts[0][1],
        shifts[1][1],
        shifts[2][1],
    )

    expected_shifts = (
        (
            b[1],
            b[0],
        ),
        (
            b[2],
            b[1],
        ),
        (
            b[0],
            b[2],
        ),
    )

    kernel_shift_rows.append({
        "b":
            list(b),
        "shifts": [
            list(shift)
            for shift in shifts
        ],
        "expected_shifts": [
            list(shift)
            for shift in expected_shifts
        ],
        "exact_kernel_law":
            shifts
            == expected_shifts,
        "parity":
            b[0]
            ^ b[1]
            ^ b[2],
        "_b_tuple":
            b,
        "_shifts_tuple":
            shifts,
    })

kernel_shift_rows = sorted(
    kernel_shift_rows,
    key=lambda row: row["_b_tuple"],
)

rotation_generator = next(
    permutation
    for permutation
    in accepted_group
    if accepted_metadata[
        permutation
    ]["rotation"] == 1
    and accepted_metadata[
        permutation
    ]["shifts"] == (
        (0, 0),
        (0, 0),
        (0, 0),
    )
)

rotation_inverse = inverse(
    rotation_generator
)

kernel_conjugation_rows = []

for row in kernel_shift_rows:
    permutation = next(
        permutation
        for permutation
        in kernel
        if accepted_metadata[
            permutation
        ]["shifts"] == row["_shifts_tuple"]
    )

    conjugate = compose(
        rotation_generator,
        compose(
            permutation,
            rotation_inverse,
        ),
    )

    conjugate_shifts = accepted_metadata[
        conjugate
    ]["shifts"]

    conjugate_b = (
        conjugate_shifts[0][1],
        conjugate_shifts[1][1],
        conjugate_shifts[2][1],
    )

    kernel_conjugation_rows.append({
        "b":
            list(
                row["_b_tuple"]
            ),
        "conjugate_b":
            list(
                conjugate_b
            ),
        "_b_tuple":
            row["_b_tuple"],
        "_conjugate_b_tuple":
            conjugate_b,
    })

fixed_kernel_elements = tuple(
    row["_b_tuple"]
    for row
    in kernel_conjugation_rows
    if row["_b_tuple"]
    == row["_conjugate_b_tuple"]
)

even_parity_kernel = tuple(
    row["_b_tuple"]
    for row
    in kernel_shift_rows
    if row["parity"] == 0
)

even_nonzero = tuple(
    b
    for b
    in even_parity_kernel
    if b != (
        0,
        0,
        0,
    )
)

even_nonzero_orbit = set()

if even_nonzero:
    current = even_nonzero[0]

    for _ in range(3):
        even_nonzero_orbit.add(
            current
        )

        current = next(
            row["_conjugate_b_tuple"]
            for row
            in kernel_conjugation_rows
            if row["_b_tuple"] == current
        )

center = tuple(
    permutation
    for permutation
    in accepted_group
    if all(
        compose(
            permutation,
            other,
        )
        == compose(
            other,
            permutation,
        )
        for other in accepted_group
    )
)

commutators = {
    commutator(
        left,
        right,
    )
    for left in accepted_group
    for right in accepted_group
}

derived_subgroup = subgroup_generated(
    commutators,
    12,
)

# ------------------------------------------------------------------
# Orbitals and Schurity.
# ------------------------------------------------------------------

point_orbit = {
    permutation[0]
    for permutation
    in accepted_group
}

point_stabilizer = tuple(
    permutation
    for permutation
    in accepted_group
    if permutation[0] == 0
)

orbitals = orbital_partition(
    accepted_group,
    12,
)

orbital_match_rows = []

for orbital_index, orbital in enumerate(
    orbitals
):
    atom_matches = tuple(
        name
        for name in ATOM_ORDER
        if atom_relations[name] == orbital
    )

    orbital_match_rows.append({
        "orbital_index":
            orbital_index,
        "size":
            len(orbital),
        "atom_matches":
            list(atom_matches),
    })

orbitals_match_atoms = (
    len(orbitals) == 8
    and all(
        len(
            row["atom_matches"]
        ) == 1
        for row in orbital_match_rows
    )
    and {
        row["atom_matches"][0]
        for row in orbital_match_rows
    }
    == set(ATOM_ORDER)
)

# ------------------------------------------------------------------
# Full fused icosahedral graph automorphism group.
# ------------------------------------------------------------------

distance1_relation = frozenset().union(
    atom_relations["Tu"],
    atom_relations["F0"],
    atom_relations["R0"],
)

adjacency = {
    vertex: set()
    for vertex in range(12)
}

for source, target in distance1_relation:
    if source == target:
        continue

    adjacency[source].add(
        target
    )

distance_rows = {
    vertex:
        graph_distances(
            adjacency,
            vertex,
        )
    for vertex in range(12)
}

triangles = ordered_triangles(
    adjacency
)

if len(triangles) != 120:
    raise SystemExit(
        "fused graph does not have 120 ordered triangles"
    )

base_triangle = triangles[0]
full_graph_automorphisms = set()
extension_count_profile = Counter()

for target_triangle in triangles:
    extensions = (
        extend_ordered_triangle_map(
            adjacency,
            distance_rows,
            base_triangle,
            target_triangle,
        )
    )

    extension_count_profile[
        len(extensions)
    ] += 1

    full_graph_automorphisms.update(
        extensions
    )

full_graph_group = tuple(
    sorted(
        full_graph_automorphisms
    )
)

full_graph_group_set = frozenset(
    full_graph_group
)

full_graph_group_closure = all(
    compose(
        left,
        right,
    ) in full_graph_group_set
    for left in full_graph_group
    for right in full_graph_group
)

color_group_is_subgroup = (
    accepted_group_set
    <= full_graph_group_set
)

# ------------------------------------------------------------------
# Normalizer and conjugate refinements.
# ------------------------------------------------------------------

conjugate_subgroups = {}
normalizer = []

for graph_automorphism in full_graph_group:
    graph_inverse = inverse(
        graph_automorphism
    )

    conjugate = frozenset(
        compose(
            graph_automorphism,
            compose(
                color_automorphism,
                graph_inverse,
            ),
        )
        for color_automorphism
        in accepted_group
    )

    conjugate_subgroups.setdefault(
        conjugate,
        graph_automorphism,
    )

    if conjugate == accepted_group_set:
        normalizer.append(
            graph_automorphism
        )

conjugate_subgroup_count = len(
    conjugate_subgroups
)

normalizer = tuple(
    normalizer
)

checks = {
    "source_audit028i_pass":
        payload028i.get(
            "audit_pass"
        ) is True,
    "candidate_count192":
        len(
            candidate_rows
        ) == 192,
    "accepted_color_automorphism_count24":
        len(
            accepted_group
        ) == 24,
    "accepted_group_contains_identity":
        identity12
        in accepted_group_set,
    "accepted_group_closed":
        group_closure,
    "accepted_group_inverse_closed":
        inverse_closure,
    "cell_rotation_profile_8_each":
        cell_rotation_profile
        == {
            "0": 8,
            "1": 8,
            "2": 8,
        },
    "kernel_order8":
        len(kernel) == 8,
    "kernel_exact_C2_cubed_shift_law":
        all(
            row[
                "exact_kernel_law"
            ]
            for row
            in kernel_shift_rows
        )
        and {
            row["_b_tuple"]
            for row
            in kernel_shift_rows
        }
        == set(
            product(
                (
                    0,
                    1,
                ),
                repeat=3,
            )
        ),
    "rotation_action_fixed_kernel_size2":
        len(
            fixed_kernel_elements
        ) == 2,
    "even_parity_plane_size4":
        len(
            even_parity_kernel
        ) == 4,
    "rotation_cycles_three_nonzero_even_vectors":
        len(
            even_nonzero_orbit
        ) == 3
        and even_nonzero_orbit
        == set(even_nonzero),
    "element_order_profile_C2_times_A4":
        element_order_profile
        == {
            "1": 1,
            "2": 7,
            "3": 8,
            "6": 8,
        },
    "center_order2":
        len(center) == 2,
    "derived_subgroup_order4":
        len(
            derived_subgroup
        ) == 4,
    "color_group_transitive_on12_points":
        len(
            point_orbit
        ) == 12,
    "point_stabilizer_order2":
        len(
            point_stabilizer
        ) == 2,
    "orbital_count8":
        len(
            orbitals
        ) == 8,
    "orbitals_equal_eight_atoms":
        orbitals_match_atoms,
    "ordered_triangle_count120":
        len(
            triangles
        ) == 120,
    "one_graph_automorphism_per_ordered_triangle":
        extension_count_profile
        == {
            1: 120,
        },
    "full_icosahedral_graph_automorphism_count120":
        len(
            full_graph_group
        ) == 120,
    "full_graph_automorphism_group_closed":
        full_graph_group_closure,
    "color_group_is_subgroup_of_full_graph_group":
        color_group_is_subgroup,
    "subgroup_index5":
        len(
            full_graph_group
        )
        // len(
            accepted_group
        ) == 5,
    "normalizer_order24":
        len(
            normalizer
        ) == 24,
    "conjugate_rank8_refinement_count5":
        conjugate_subgroup_count
        == 5,
}

audit_pass = all(
    checks.values()
)

print("== exhaustive color-automorphism census ==")
print(
    "candidate_count:",
    len(
        candidate_rows
    ),
)
print(
    "accepted_count:",
    len(
        accepted_group
    ),
)
print(
    "cell_rotation_profile:",
    cell_rotation_profile,
)
print(
    "element_order_profile:",
    element_order_profile,
)
print(
    "group_closed:",
    str(
        group_closure
    ).lower(),
)
print(
    "inverse_closed:",
    str(
        inverse_closure
    ).lower(),
)
print()

print("== kernel and abstract group structure ==")
print(
    "kernel_order:",
    len(kernel),
)
print(
    "kernel_shift_rows:",
    [
        {
            key: value
            for key, value
            in row.items()
            if not key.startswith("_")
        }
        for row in kernel_shift_rows
    ],
)
print(
    "rotation_conjugation_rows:",
    [
        {
            key: value
            for key, value
            in row.items()
            if not key.startswith("_")
        }
        for row
        in kernel_conjugation_rows
    ],
)
print(
    "fixed_kernel_elements:",
    fixed_kernel_elements,
)
print(
    "even_parity_kernel:",
    even_parity_kernel,
)
print(
    "even_nonzero_rotation_orbit:",
    tuple(
        sorted(
            even_nonzero_orbit
        )
    ),
)
print(
    "center_order:",
    len(center),
)
print(
    "derived_subgroup_order:",
    len(
        derived_subgroup
    ),
)
print(
    "abstract_group_identification:",
    "C2 x A4"
    if (
        checks[
            "kernel_exact_C2_cubed_shift_law"
        ]
        and checks[
            "rotation_cycles_three_nonzero_even_vectors"
        ]
        and checks[
            "center_order2"
        ]
        and checks[
            "derived_subgroup_order4"
        ]
    )
    else "unresolved",
)
print()

print("== orbitals and Schurity ==")
print(
    "point_orbit_size:",
    len(
        point_orbit
    ),
)
print(
    "point_stabilizer_order:",
    len(
        point_stabilizer
    ),
)
print(
    "orbital_count:",
    len(
        orbitals
    ),
)

for row in orbital_match_rows:
    print(
        "orbital="
        + str(
            row[
                "orbital_index"
            ]
        ),
        "size="
        + str(
            row["size"]
        ),
        "atom_matches="
        + str(
            tuple(
                row[
                    "atom_matches"
                ]
            )
        ),
    )

print(
    "orbitals_equal_atoms:",
    str(
        orbitals_match_atoms
    ).lower(),
)
print(
    "rank8_configuration_is_Schurian:",
    str(
        orbitals_match_atoms
        and len(
            point_orbit
        ) == 12
    ).lower(),
)
print()

print("== full icosahedral containment ==")
print(
    "base_ordered_triangle:",
    base_triangle,
)
print(
    "ordered_triangle_count:",
    len(
        triangles
    ),
)
print(
    "extension_count_profile:",
    dict(
        sorted(
            extension_count_profile.items()
        )
    ),
)
print(
    "full_graph_automorphism_count:",
    len(
        full_graph_group
    ),
)
print(
    "color_group_order:",
    len(
        accepted_group
    ),
)
print(
    "color_group_is_subgroup:",
    str(
        color_group_is_subgroup
    ).lower(),
)
print(
    "subgroup_index:",
    len(
        full_graph_group
    )
    // len(
        accepted_group
    ),
)
print(
    "normalizer_order:",
    len(
        normalizer
    ),
)
print(
    "conjugate_rank8_refinement_count:",
    conjugate_subgroup_count,
)
print()

print("== checks ==")

for name, passed in checks.items():
    print(
        name + ":",
        str(passed).lower(),
    )

verdict = (
    "the_rank8_coherent_configuration_is_Schurian_with_exact_"
    "color_preserving_automorphism_group_C2_times_A4_of_order24_"
    "acting_transitively_on12_points_with_point_stabilizer_order2_"
    "and_exactly_eight_orbitals_equal_to_the_eight_atoms_this_group_"
    "is_a_self_normalizing_index5_subgroup_of_the_order120_full_"
    "icosahedral_graph_automorphism_group_and_has_exactly_five_"
    "conjugate_rank8_refinements"
    if audit_pass
    else
    "the_candidate_rank8_Schurian_automorphism_theorem_has_"
    "unresolved_exhaustiveness_group_orbital_or_icosahedral_"
    "containment_failures"
)

artifact = {
    "audit_id":
        "rank8_schurian_automorphism_group_audit_028j",
    "timestamp":
        utc_now(),
    "audit_pass":
        audit_pass,
    "verdict":
        verdict,
    "sources": {
        "audit028i": {
            "path":
                str(AUDIT028I),
            "sha256":
                sha256_file(
                    AUDIT028I
                ),
            "audit_pass":
                payload028i.get(
                    "audit_pass"
                ),
            "verdict":
                payload028i.get(
                    "verdict"
                ),
        },
    },
    "measurements": {
        "candidate_count":
            len(
                candidate_rows
            ),
        "accepted_color_automorphism_count":
            len(
                accepted_group
            ),
        "cell_rotation_profile":
            cell_rotation_profile,
        "element_order_profile":
            element_order_profile,
        "kernel_order":
            len(kernel),
        "kernel_shift_rows": [
            {
                key: value
                for key, value
                in row.items()
                if not key.startswith("_")
            }
            for row
            in kernel_shift_rows
        ],
        "rotation_conjugation_rows": [
            {
                key: value
                for key, value
                in row.items()
                if not key.startswith("_")
            }
            for row
            in kernel_conjugation_rows
        ],
        "fixed_kernel_elements": [
            list(value)
            for value
            in fixed_kernel_elements
        ],
        "even_parity_kernel": [
            list(value)
            for value
            in even_parity_kernel
        ],
        "even_nonzero_rotation_orbit": [
            list(value)
            for value
            in sorted(
                even_nonzero_orbit
            )
        ],
        "center_order":
            len(center),
        "derived_subgroup_order":
            len(
                derived_subgroup
            ),
        "abstract_group_identification":
            "C2 x A4",
        "point_orbit_size":
            len(
                point_orbit
            ),
        "point_stabilizer_order":
            len(
                point_stabilizer
            ),
        "orbital_count":
            len(
                orbitals
            ),
        "orbital_match_rows":
            orbital_match_rows,
        "rank8_configuration_is_Schurian":
            (
                orbitals_match_atoms
                and len(
                    point_orbit
                ) == 12
            ),
        "base_ordered_triangle":
            list(
                base_triangle
            ),
        "ordered_triangle_count":
            len(
                triangles
            ),
        "extension_count_profile":
            {
                str(key):
                    value
                for key, value
                in sorted(
                    extension_count_profile.items()
                )
            },
        "full_icosahedral_graph_automorphism_count":
            len(
                full_graph_group
            ),
        "color_group_order":
            len(
                accepted_group
            ),
        "subgroup_index":
            len(
                full_graph_group
            )
            // len(
                accepted_group
            ),
        "normalizer_order":
            len(
                normalizer
            ),
        "self_normalizing":
            len(
                normalizer
            )
            == len(
                accepted_group
            ),
        "conjugate_rank8_refinement_count":
            conjugate_subgroup_count,
    },
    "checks":
        checks,
    "interpretation": (
        "The oriented rank-8 refinement is not an arbitrary coloring of "
        "the icosahedron. Its color-preserving automorphism group acts "
        "transitively, and its orbitals are exactly the eight coherent-"
        "configuration atoms, so the refinement is Schurian. The group "
        "has order 24 and abstract structure C2 times A4. Inside the full "
        "order-120 icosahedral graph automorphism group it is self-"
        "normalizing of index five, producing exactly five conjugate "
        "oriented rank-8 refinements of the same fused distance scheme."
    ),
    "boundary": {
        "rank8_Schurian_property_proved":
            audit_pass,
        "color_automorphism_group_order":
            24
            if audit_pass
            else None,
        "color_automorphism_group_isomorphism":
            "C2 x A4"
            if audit_pass
            else None,
        "full_icosahedral_graph_automorphism_group_order":
            120
            if audit_pass
            else None,
        "self_normalizing_index5_subgroup_proved":
            audit_pass,
        "conjugate_rank8_refinement_count":
            5
            if audit_pass
            else None,
        "rank_four_polytope_incidence_packet_proved":
            False,
        "eight_rank_four_facets_constructed":
            False,
        "actual_960_flag_set_constructed":
            False,
        "schlafli_5_3_4_rank_four_complex_proved":
            False,
    },
    "next_target": (
        "Audit 028K should classify the five conjugate rank-8 refinements "
        "relative to the native A5/Petersen five-object geometry already "
        "proved in Project 41. Test whether the five refinements form the "
        "same intrinsic five-set as the K5 quotient, the five Sylow/V4 "
        "structures, or another native A5 orbit. Do not identify them by "
        "name until an exact equivariant bijection is constructed."
    ),
    "keeper": (
        "The icosahedron contains five conjugate oriented grammars. "
        "Each grammar keeps a C2 x A4 witness group."
    ),
}

markdown_lines = [
    "# Rank-8 Schurian Automorphism Group Audit 028J",
    "",
    f"Audit pass: {str(audit_pass).lower()}",
    "",
    f"Verdict: `{verdict}`",
    "",
    "## Result",
    "",
    "The exact 192-candidate census finds 24 color-preserving",
    "automorphisms. Their group is",
    "",
    "    C2 x A4",
    "",
    "acting transitively on 12 points with point stabilizer order 2.",
    "Its eight orbitals are exactly the eight rank-8 atoms, so the",
    "coherent configuration is Schurian.",
    "",
    "The full fused icosahedral graph automorphism group has order 120.",
    "The color group is self-normalizing of index 5. Consequently the",
    "icosahedral graph contains exactly five conjugate rank-8",
    "refinements.",
    "",
    "## Boundary",
    "",
    "This is a finite automorphism and orbital theorem. No rank-four",
    "polytope incidence packet, eight facets, 960 flags, or {5,3,4}",
    "complex is claimed.",
    "",
    "## Keeper",
    "",
    artifact["keeper"],
    "",
]

if audit_pass:
    JSON_OUT.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    MD_OUT.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    JSON_OUT.write_text(
        json.dumps(
            artifact,
            indent=2,
            sort_keys=True,
        ) + "\n",
        encoding="utf-8",
    )

    MD_OUT.write_text(
        "\n".join(
            markdown_lines
        ),
        encoding="utf-8",
    )

print()
print(
    "audit_pass:",
    str(
        audit_pass
    ).lower(),
)
print(
    "verdict:",
    verdict,
)
print(
    "rank8_Schurian_property_proved:",
    str(
        audit_pass
    ).lower(),
)
print(
    "color_automorphism_group_order:",
    len(
        accepted_group
    ),
)
print(
    "color_automorphism_group_isomorphism:",
    "C2 x A4"
    if audit_pass
    else "unresolved",
)
print(
    "point_stabilizer_order:",
    len(
        point_stabilizer
    ),
)
print(
    "orbital_count:",
    len(
        orbitals
    ),
)
print(
    "orbitals_equal_eight_atoms:",
    str(
        orbitals_match_atoms
    ).lower(),
)
print(
    "full_icosahedral_graph_automorphism_group_order:",
    len(
        full_graph_group
    ),
)
print(
    "subgroup_index:",
    len(
        full_graph_group
    )
    // len(
        accepted_group
    ),
)
print(
    "self_normalizing:",
    str(
        len(
            normalizer
        )
        == len(
            accepted_group
        )
    ).lower(),
)
print(
    "conjugate_rank8_refinement_count:",
    conjugate_subgroup_count,
)
print(
    "rank_four_polytope_incidence_packet_proved:",
    "false",
)
print(
    "eight_rank_four_facets_constructed:",
    "false",
)
print(
    "actual_960_flag_set_constructed:",
    "false",
)
print(
    "schlafli_5_3_4_rank_four_complex_proved:",
    "false",
)
print()

if audit_pass:
    print(
        "mutation_performed: true"
    )
    print(
        "json_artifact:",
        JSON_OUT,
    )
    print(
        "markdown_artifact:",
        MD_OUT,
    )
    print(
        "commit_created: false"
    )
    print(
        "push_performed: false"
    )
    print(
        "status:",
        "rank8_schurian_automorphism_group_audit_028j_complete",
    )
else:
    print(
        "mutation_performed: false"
    )
    print(
        "status:",
        "rank8_schurian_automorphism_group_audit_028j_failed",
    )
    raise SystemExit(1)
