"""Audit the full automorphism group and C4 roots of product G1800.

The 1800-vertex graph is never passed to GraphMatcher.  The only graph
isomorphism enumeration is Aut(G60), on one 60-vertex intrinsic leaf.  The
full order is then proved by matching an explicit normalizer-quotient lower
bound with an intrinsic-foliation restriction upper bound.

Usage:
    python3 product_y_automorphism_c4_audit.py \
        BODY ALIGN DECK ORIGIN AFFINE
"""

import collections as C
import contextlib
import hashlib
import io
import itertools
import json
from pathlib import Path
import runpy
import sys

import networkx as nx


if len(sys.argv) != 6:
    raise SystemExit(
        "usage: product_y_automorphism_c4_audit.py "
        "BODY ALIGN DECK ORIGIN AFFINE"
    )


# Reuse the exact product, graph-only foliation, and graph-only cell-partner
# audits.  The cell audit recursively runs the other two and exports all
# construction witnesses needed below.
cell_script = Path(__file__).with_name(
    "product_y_intrinsic_cell_partner_audit.py"
)
if not cell_script.is_file():
    raise SystemExit("MISSING_PRODUCT_Y_INTRINSIC_CELL_PARTNER_AUDIT")

saved_argv = sys.argv[:]
sys.argv = [str(cell_script), *saved_argv[1:]]
captured = io.StringIO()
try:
    with contextlib.redirect_stdout(captured):
        c = runpy.run_path(str(cell_script))
finally:
    sys.argv = saved_argv

cell_summary = json.loads(captured.getvalue())
if cell_summary.get("audit_pass") is not True:
    raise SystemExit("BASE_PRODUCT_CELL_AUDIT_NOT_GREEN")


f = c["f"]
d = c["d"]
edge = d["edge"]
add = d["add"]
deck = d["deck"]
kernel = d["kernel"]
local = d["local"]
G = d["G"]
Yfib = d["Yfib"]
yid = d["yid"]
Yv = d["Yv"]
Ye = d["Ye"]
Y = d["Y"]
K = d["K"]
Kreverse = d["Kreverse"]
Delta = d["Delta"]
E = c["E"]
FactorSwap = c["FactorSwap"]
quotient = d["quotient"]
local_bijection = d["local_bijection"]
Phi = d["Phi"]
stoc = d["stoc"]
ctos = d["ctos"]
zero = d["zero"]
lcoord = d["lcoord"]
Xv = d["Xv"]
Xedges = d["Xedges"]
X = d["X"]
Bafib = d["Bafib"]
Bae = d["Bae"]
Ba = d["Ba"]
Kfib = d["Kfib"]
tau = d["tau"]
successful_taus = d["successful_taus"]
delta_label = d["product"]
mul_label = d["mul"]

intrinsic_parts = tuple(
    sorted(
        (frozenset(part) for part in f["interaction_parts"]),
        key=lambda part: min(part),
    )
)
first_components = f["first_components"]
second_components = f["second_components"]
intrinsic_components = c["intrinsic_components"]
intrinsic_cells = c["intrinsic_cells"]


def compose(permutation, other):
    """Return permutation after other."""
    return tuple(permutation[other[i]] for i in range(len(permutation)))


def inverse(permutation):
    result = [None] * len(permutation)
    for source, target in enumerate(permutation):
        result[target] = source
    return tuple(result)


def conjugate(permutation, other):
    return compose(compose(permutation, other), inverse(permutation))


def edge_image(edges, permutation):
    return {
        edge(permutation[a], permutation[b])
        for a, b in edges
    }


identity60 = tuple(range(60))
bperm = deck[kernel]


# -------------------------------------------------------------------------
# The only GraphMatcher enumeration in this audit: Aut(G60).
# -------------------------------------------------------------------------
aut60 = sorted({
    tuple(mapping[i] for i in range(60))
    for mapping in nx.algorithms.isomorphism.GraphMatcher(
        G, G
    ).isomorphisms_iter()
})
aut60_set = set(aut60)

centralizer = tuple(
    permutation
    for permutation in aut60
    if compose(permutation, bperm) == compose(bperm, permutation)
)
centralizer_set = set(centralizer)

b_blocks = {
    frozenset((vertex, bperm[vertex]))
    for vertex in range(60)
}


def preserves_b_blocks(permutation):
    return all(
        frozenset(permutation[vertex] for vertex in block) in b_blocks
        for block in b_blocks
    )


def fixes_every_b_block(permutation):
    return all(
        frozenset(permutation[vertex] for vertex in block) == block
        for block in b_blocks
    )


block_preservers = {
    permutation
    for permutation in aut60
    if preserves_b_blocks(permutation)
}
block_kernel = {
    permutation
    for permutation in block_preservers
    if fixes_every_b_block(permutation)
}

centralizer_orbit_profile = dict(sorted(C.Counter(
    len({permutation[vertex] for permutation in centralizer})
    for vertex in range(60)
).items()))
centralizer_stabilizer_profile = dict(sorted(C.Counter(
    sum(permutation[vertex] == vertex for permutation in centralizer)
    for vertex in range(60)
).items()))

centralizer_center = {
    permutation
    for permutation in centralizer
    if all(
        compose(permutation, other) == compose(other, permutation)
        for other in centralizer
    )
}


# Check directly that a constructed leaf and its 30 opposite-family
# intersections are the native G60 graph with its b-pair block system.
def native_leaf_model(component, varying_factor):
    component = set(component)
    sample = min(component)
    x0, y0 = Yfib[sample][0]

    if varying_factor == 0:
        mapping = {
            vertex: yid[(vertex, y0)]
            for vertex in range(60)
        }
    else:
        mapping = {
            vertex: yid[(x0, vertex)]
            for vertex in range(60)
        }

    image_vertices = set(mapping.values())
    image_edges = {
        edge(mapping[a], mapping[b])
        for a, b in local
    }
    induced_edges = {
        e for e in Ye
        if e[0] in component and e[1] in component
    }

    other_components = (
        second_components if varying_factor == 0
        else first_components
    )
    intersection_blocks = {
        frozenset(component & set(other))
        for other in other_components
    }
    mapped_b_blocks = {
        frozenset(mapping[vertex] for vertex in block)
        for block in b_blocks
    }

    return {
        "bijection":
            len(image_vertices) == 60
            and image_vertices == component,
        "graph_isomorphism": image_edges == induced_edges,
        "block_system_exact":
            intersection_blocks == mapped_b_blocks
            and C.Counter(map(len, intersection_blocks)) == {2: 30},
    }


first_leaf_model = native_leaf_model(first_components[0], 0)
second_leaf_model = native_leaf_model(second_components[0], 1)


leaf_checks = {
    "AutG60_order480": len(aut60) == 480,
    "native_deck_permutations_lie_in_AutG60":
        set(deck.values()) <= aut60_set,
    "b_centralizer_order240": len(centralizer) == 240,
    "b_block_preservers_equal_b_centralizer":
        block_preservers == centralizer_set,
    "b_block_action_kernel_exactly_identity_b":
        block_kernel == {identity60, bperm},
    "b_swaps_every_native_block": all(
        bperm[vertex] != vertex
        for vertex in range(60)
    ),
    "centralizer_transitive_on_G60":
        centralizer_orbit_profile == {60: 60},
    "centralizer_point_stabilizer_order4":
        centralizer_stabilizer_profile == {4: 60},
    "centralizer_center_is_native_V4":
        centralizer_center == set(deck.values()),
    "first_reference_leaf_native_model_exact":
        all(first_leaf_model.values()),
    "second_reference_leaf_native_model_exact":
        all(second_leaf_model.values()),
}


# -------------------------------------------------------------------------
# Abstract normalizer quotient
# ((C x C) rtimes <swap>)/<diag b>.
# -------------------------------------------------------------------------
Cperms = tuple(sorted(centralizer))
Cindex = {permutation: index for index, permutation in enumerate(Cperms)}

if identity60 not in Cindex or bperm not in Cindex:
    raise SystemExit("CENTRALIZER_REQUIRED_ELEMENTS_MISSING")

cid = Cindex[identity60]
cb = Cindex[bperm]
if delta_label not in deck:
    raise SystemExit("DELTA_LABEL_NOT_IN_NATIVE_DECK")
ca = Cindex[deck[delta_label]]
other_label = mul_label(delta_label, kernel)
if other_label not in deck:
    raise SystemExit("OTHER_DELTA_REPRESENTATIVE_NOT_IN_NATIVE_DECK")
cab = Cindex[deck[other_label]]

Cmul = [
    [Cindex[compose(left, right)] for right in Cperms]
    for left in Cperms
]
Cinv = [Cindex[inverse(permutation)] for permutation in Cperms]


def cclosure(generators):
    steps = set(generators)
    steps |= {Cinv[index] for index in tuple(steps)}
    seen = {cid}
    queue = C.deque((cid,))
    while queue:
        current = queue.popleft()
        for generator in steps:
            value = Cmul[current][generator]
            if value not in seen:
                seen.add(value)
                queue.append(value)
    return seen


Cgenerators = []
Cgenerated = {cid}
for candidate in range(len(Cperms)):
    if candidate in Cgenerated:
        continue
    Cgenerators.append(candidate)
    Cgenerated = cclosure(Cgenerators)
    if len(Cgenerated) == len(Cperms):
        break


def canonical(element):
    """Canonical representative modulo central diag<b>."""
    left, right, swap = element
    partner = (
        Cmul[left][cb],
        Cmul[right][cb],
        swap,
    )
    return min(element, partner)


def group_multiply(left, right):
    """Composition in the swap wreath product, modulo diag<b>."""
    p, q, exchange = left
    r, s, other_exchange = right
    if exchange:
        raw = (
            Cmul[p][s],
            Cmul[q][r],
            exchange ^ other_exchange,
        )
    else:
        raw = (
            Cmul[p][r],
            Cmul[q][s],
            exchange ^ other_exchange,
        )
    return canonical(raw)


def group_inverse(element):
    left, right, exchange = element
    if exchange:
        return canonical((Cinv[right], Cinv[left], 1))
    return canonical((Cinv[left], Cinv[right], 0))


group_identity = canonical((cid, cid, 0))
abstract_elements = tuple(sorted({
    canonical((left, right, exchange))
    for left in range(len(Cperms))
    for right in range(len(Cperms))
    for exchange in (0, 1)
}))
abstract_element_set = set(abstract_elements)

group_generators = [
    canonical((generator, cid, 0))
    for generator in Cgenerators
] + [
    canonical((cid, generator, 0))
    for generator in Cgenerators
] + [
    canonical((cid, cid, 1))
]


def abstract_closure(generators):
    steps = set(generators)
    steps |= {group_inverse(element) for element in tuple(steps)}
    seen = {group_identity}
    queue = C.deque((group_identity,))
    while queue:
        current = queue.popleft()
        for generator in steps:
            value = group_multiply(current, generator)
            if value not in seen:
                seen.add(value)
                queue.append(value)
    return seen


abstract_generated = abstract_closure(group_generators)


def product_action(element, product_vertex):
    left, right, exchange = element
    x, y = product_vertex
    if exchange:
        return (Cperms[left][y], Cperms[right][x])
    return (Cperms[left][x], Cperms[right][y])


def descend_abstract(element):
    output = []
    for fiber in Yfib:
        images = {
            yid[product_action(element, product_vertex)]
            for product_vertex in fiber
        }
        if len(images) != 1:
            raise SystemExit("ABSTRACT_ACTION_NOT_WELL_DEFINED_ON_Y")
        output.append(next(iter(images)))
    return tuple(output)


# The action kernel is proved from the leaf-block action.  This direct orbit
# calculation also verifies transitivity of the 57,600-element candidate
# without storing 57,600 permutations of degree 1,800.
anchor_product_vertex = Yfib[0][0]
candidate_vertex_orbit = {
    yid[product_action(element, anchor_product_vertex)]
    for element in abstract_elements
}

factor_preserving_elements = sum(
    element[2] == 0
    for element in abstract_elements
)
factor_exchanging_elements = sum(
    element[2] == 1
    for element in abstract_elements
)

# Upper-bound certificate.  The graph-defined unordered foliation forces a
# homomorphism Aut(Y)->C2.  After fixing a vertex and the two colors, the two
# root-leaf restrictions each lie in the order-four point stabilizer in C.
# If both restrictions are identity, complete leaf incidence makes every leaf
# setwise fixed; its pair-block kernel is {1,b}; agreement on all 2-cells makes
# the 60 kernel bits equal; the fixed root leaf forces the common bit to zero.
restriction_injectivity_premises = (
    len(intrinsic_parts) == 2
    and [len(family) for family in intrinsic_components] == [30, 30]
    and len(intrinsic_cells) == 900
    and C.Counter(map(len, intrinsic_cells.values())) == {2: 900}
    and leaf_checks["b_block_action_kernel_exactly_identity_b"]
    and leaf_checks["b_swaps_every_native_block"]
    and leaf_checks["first_reference_leaf_native_model_exact"]
    and leaf_checks["second_reference_leaf_native_model_exact"]
)

centralizer_point_stabilizer_max = max(
    sum(permutation[vertex] == vertex for permutation in centralizer)
    for vertex in range(60)
)
color_preserving_stabilizer_upper_bound = (
    centralizer_point_stabilizer_max ** 2
)
color_preserving_order_upper_bound = (
    len(Yv) * color_preserving_stabilizer_upper_bound
)
full_order_upper_bound = 2 * color_preserving_order_upper_bound

candidate_kernel_is_diag_b = (
    block_kernel == {identity60, bperm}
    and len(intrinsic_parts) == 2
    and intrinsic_parts[0].isdisjoint(intrinsic_parts[1])
    and set(intrinsic_parts[0]) | set(intrinsic_parts[1]) == Ye
    and c["E"] != tuple(range(len(Yv)))
    and all(c["E"][vertex] != vertex for vertex in Yv)
)

full_group_checks = {
    "centralizer_generators_generate_C":
        Cgenerated == set(range(len(Cperms))),
    "abstract_generators_generate_candidate_group":
        abstract_generated == abstract_element_set,
    "candidate_group_order57600":
        len(abstract_elements) == 57600,
    "factor_preserving_candidate_order28800":
        factor_preserving_elements == 28800,
    "factor_exchanging_candidate_order28800":
        factor_exchanging_elements == 28800,
    "candidate_action_kernel_exactly_diag_b":
        candidate_kernel_is_diag_b,
    "candidate_action_transitive_on_Y":
        candidate_vertex_orbit == Yv,
    "intrinsic_foliation_forces_preserve_or_exchange":
        cell_summary["checks"]["graph_only_foliation_source_is_green"]
        and len(intrinsic_parts) == 2,
    "restriction_pair_injectivity_lemma_premises_exact":
        restriction_injectivity_premises,
    "color_preserving_AutY_upper_bound28800":
        color_preserving_order_upper_bound == 28800,
    "full_AutY_upper_bound57600":
        full_order_upper_bound == 57600,
    "candidate_lower_bound_matches_intrinsic_upper_bound":
        len(abstract_elements) == full_order_upper_bound,
}
full_AutY_proved = all(leaf_checks.values()) and all(
    full_group_checks.values()
)


# -------------------------------------------------------------------------
# Center of the now-complete abstract group.
# -------------------------------------------------------------------------
abstract_center = {
    element
    for element in abstract_elements
    if all(
        group_multiply(element, generator)
        == group_multiply(generator, element)
        for generator in group_generators
    )
}

abstract_E = canonical((cb, cid, 0))
abstract_Delta = canonical((ca, ca, 0))
abstract_EDelta = group_multiply(abstract_E, abstract_Delta)
expected_center = {
    group_identity,
    abstract_E,
    abstract_Delta,
    abstract_EDelta,
}

known_center_actions = {
    "identity": tuple(range(len(Yv))),
    "E": E,
    "Delta": Delta,
    "E_Delta": compose(E, Delta),
}
known_center_elements = {
    "identity": group_identity,
    "E": abstract_E,
    "Delta": abstract_Delta,
    "E_Delta": abstract_EDelta,
}

center_action_checks = {}
for name, element in known_center_elements.items():
    center_action_checks[name] = (
        element in abstract_center
        and descend_abstract(element) == known_center_actions[name]
    )


def shell_profile(graph):
    profile = C.Counter()
    for vertex in graph:
        distances = nx.single_source_shortest_path_length(graph, vertex)
        shells = C.Counter(distances.values())
        signature = tuple(
            shells[distance]
            for distance in range(max(shells) + 1)
        )
        profile[signature] += 1
    return dict(sorted(profile.items()))


def profile_digest(profile):
    payload = [
        [list(signature), count]
        for signature, count in sorted(profile.items())
    ]
    return hashlib.sha256(
        json.dumps(payload, separators=(",", ":")).encode()
    ).hexdigest()


def first_profile_difference(left, right):
    for signature in sorted(set(left) | set(right)):
        if left.get(signature, 0) != right.get(signature, 0):
            return {
                "shell_signature": list(signature),
                "left_count": left.get(signature, 0),
                "right_count": right.get(signature, 0),
            }
    return None


central_quotients = {}
central_quotient_graphs = {}
for name in ("E", "Delta", "E_Delta"):
    permutation = known_center_actions[name]
    fibers, qid, groups, qedges, graph = quotient(
        Yv,
        Ye,
        lambda vertex, permutation=permutation: (
            vertex,
            permutation[vertex],
        ),
    )
    profile = shell_profile(graph)
    central_quotient_graphs[name] = (
        fibers, qid, groups, qedges, graph, profile
    )
    central_quotients[name] = {
        "vertex_count": len(fibers),
        "edge_count": len(qedges),
        "degree_profile": dict(sorted(C.Counter(
            dict(graph.degree()).values()
        ).items())),
        "connected": nx.is_connected(graph),
        "loop_count": sum(a == b for a, b in qedges),
        "fiber_size_profile": dict(sorted(C.Counter(
            map(len, fibers)
        ).items())),
        "edge_lift_profile": dict(sorted(C.Counter(
            map(len, groups.values())
        ).items())),
        "cover_local_bijection": local_bijection(Y, qid, graph),
        "distance_shell_distinct_count": len(profile),
        "distance_shell_profile_sha256": profile_digest(profile),
    }

central_quotient_differences = {}
for left, right in itertools.combinations(
    ("E", "Delta", "E_Delta"), 2
):
    difference = first_profile_difference(
        central_quotient_graphs[left][-1],
        central_quotient_graphs[right][-1],
    )
    central_quotient_differences[left + "_vs_" + right] = difference

center_checks = {
    "full_AutY_was_proved_before_center_classification":
        full_AutY_proved,
    "AutY_center_is_exact_V4":
        abstract_center == expected_center
        and len(abstract_center) == 4,
    "center_named_actions_match_graph_permutations":
        all(center_action_checks.values()),
    "three_nontrivial_center_elements_are_free_involutions": all(
        len(set(permutation)) == len(Yv)
        and all(permutation[vertex] != vertex for vertex in Yv)
        and all(permutation[permutation[vertex]] == vertex for vertex in Yv)
        for name, permutation in known_center_actions.items()
        if name != "identity"
    ),
    "all_three_central_quotients_are_regular_900_3600_covers": all(
        row["vertex_count"] == 900
        and row["edge_count"] == 3600
        and row["degree_profile"] == {8: 900}
        and row["connected"]
        and row["loop_count"] == 0
        and row["fiber_size_profile"] == {2: 900}
        and row["edge_lift_profile"] == {2: 3600}
        and row["cover_local_bijection"]
        for row in central_quotients.values()
    ),
    "E_quotient_matches_green_G30_square_receipt":
        cell_summary["Y_mod_E_is_exact_G30_square"] is True,
    "Delta_quotient_matches_green_native_X_receipt":
        d["checks"]["Y_mod_Delta_is_exact_X"] is True,
}


# -------------------------------------------------------------------------
# Factor-exchanging square roots of central elements and C4 classification.
# -------------------------------------------------------------------------
def conjugate_element(group_element, element):
    return group_multiply(
        group_multiply(group_element, element),
        group_inverse(group_element),
    )


exchange_elements = tuple(
    element for element in abstract_elements
    if element[2] == 1
)

exchange_square_roots_by_center = {}
for name, center_element in known_center_elements.items():
    exchange_square_roots_by_center[name] = tuple(
        element
        for element in exchange_elements
        if group_multiply(element, element) == center_element
    )

delta_roots = exchange_square_roots_by_center["Delta"]
delta_root_set = set(delta_roots)


def root_product_index(root):
    left, right, exchange = root
    if exchange != 1:
        raise ValueError("root does not exchange factors")
    return Cmul[left][right]


native_perm_to_label = {
    permutation: label
    for label, permutation in deck.items()
}
root_product_labels = []
root_product_failure_count = 0
for root in delta_roots:
    product_index = root_product_index(root)
    product_permutation = Cperms[product_index]
    if product_permutation not in native_perm_to_label:
        root_product_failure_count += 1
        root_product_labels.append("non_native")
    else:
        root_product_labels.append(
            native_perm_to_label[product_permutation]
        )

root_product_profile = dict(sorted(C.Counter(
    root_product_labels
).items()))

root_orbits = []
unseen_roots = set(delta_roots)
while unseen_roots:
    root = min(unseen_roots)
    orbit = {
        conjugate_element(group_element, root)
        for group_element in abstract_elements
    }
    if not orbit <= delta_root_set:
        raise SystemExit("DELTA_ROOT_CONJUGACY_NOT_CLOSED")
    root_orbits.append(orbit)
    unseen_roots -= orbit


def c4_subgroup(root):
    return frozenset((
        group_identity,
        root,
        abstract_Delta,
        group_multiply(root, abstract_Delta),
    ))


c4_subgroups = {
    c4_subgroup(root)
    for root in delta_roots
}
c4_orbit_rows = []
for orbit in root_orbits:
    subgroup_orbit = {
        c4_subgroup(root)
        for root in orbit
    }
    products = {
        native_perm_to_label.get(
            Cperms[root_product_index(root)],
            "non_native",
        )
        for root in orbit
    }
    c4_orbit_rows.append({
        "root_count": len(orbit),
        "C4_subgroup_count": len(subgroup_orbit),
        "lift_product_labels": sorted(products),
    })
c4_orbit_rows.sort(key=lambda row: row["lift_product_labels"])

selected_root = canonical((
    Cindex[deck[tau[0]]],
    Cindex[deck[tau[1]]],
    1,
))
reverse_root = canonical((
    Cindex[deck[tau[1]]],
    Cindex[deck[tau[0]]],
    1,
))

selected_root_action = descend_abstract(selected_root)
reverse_root_action = descend_abstract(reverse_root)


# Native branch representatives.  The selected tau supplies the delta-label
# branch.  (identity, other_label) supplies the other lift-product branch.
branch_roots = {
    delta_label: selected_root,
    other_label: canonical((cid, cab, 1)),
}


def J_label(vertex, label):
    source_base, state = vertex
    target_base, coordinate = stoc[state]
    return (
        target_base,
        ctos[(source_base, add(coordinate, lcoord[label]))],
    )


def cyclic_orbit(permutation, vertex):
    values = []
    current = vertex
    for _ in range(4):
        values.append(current)
        current = permutation[current]
    return tuple(values)


branch_rows = {}
branch_data = {}
for label, root in branch_roots.items():
    permutation = descend_abstract(root)
    j_permutation = {
        vertex: J_label(vertex, label)
        for vertex in Xv
    }

    h_fib, h_id, h_groups, h_edges, h_graph = quotient(
        Yv,
        Ye,
        lambda vertex, permutation=permutation: cyclic_orbit(
            permutation, vertex
        ),
    )
    b_fib, b_id, b_groups, b_edges, b_graph = quotient(
        Xv,
        Xedges,
        lambda vertex, j_permutation=j_permutation: (
            vertex,
            j_permutation[vertex],
        ),
    )

    induced_J_exact = all(
        Phi(Yfib[permutation[vertex]][0])
        == j_permutation[Phi(Yfib[vertex][0])]
        for vertex in Yv
    )

    h_to_b = {}
    h_to_b_well_defined = True
    for q, fiber in enumerate(h_fib):
        values = {
            b_id[Phi(product_vertex)]
            for y_vertex in fiber
            for product_vertex in Yfib[y_vertex]
        }
        if len(values) != 1:
            h_to_b_well_defined = False
            continue
        h_to_b[q] = next(iter(values))

    mapped_h_edges = {
        edge(h_to_b[a], h_to_b[b])
        for a, b in h_edges
        if a in h_to_b and b in h_to_b
    }

    checks = {
        "root_is_in_complete_Delta_root_census":
            root in delta_root_set,
        "root_action_is_bijective_free_order4":
            len(set(permutation)) == 1800
            and all(permutation[vertex] != vertex for vertex in Yv)
            and all(
                permutation[
                    permutation[
                        permutation[
                            permutation[vertex]
                        ]
                    ]
                ] == vertex
                for vertex in Yv
            ),
        "root_action_square_is_Delta":
            all(
                permutation[permutation[vertex]] == Delta[vertex]
                for vertex in Yv
            ),
        "root_action_is_Y_automorphism":
            edge_image(Ye, permutation) == Ye,
        "root_induces_expected_J_on_X": induced_J_exact,
        "Y_mod_C4_is_450_1800_simple_connected_degree8":
            len(h_fib) == 450
            and len(h_edges) == 1800
            and not any(a == b for a, b in h_edges)
            and set(dict(h_graph.degree()).values()) == {8}
            and nx.is_connected(h_graph),
        "X_mod_J_is_450_1800_simple_connected_degree8":
            len(b_fib) == 450
            and len(b_edges) == 1800
            and not any(a == b for a, b in b_edges)
            and set(dict(b_graph.degree()).values()) == {8}
            and nx.is_connected(b_graph),
        "Y_mod_C4_maps_exactly_to_X_mod_J":
            h_to_b_well_defined
            and len(h_to_b) == 450
            and len(set(h_to_b.values())) == 450
            and mapped_h_edges == b_edges,
    }

    branch_rows[label] = {
        "lift_product_label": label,
        "root_relation": (
            "selected_tau" if label == delta_label
            else "other_Delta_root_orbit_representative"
        ),
        "Y_C4_quotient_counts": [len(h_fib), len(h_edges)],
        "X_J_quotient_counts": [len(b_fib), len(b_edges)],
        "checks": checks,
        "row_pass": all(checks.values()),
    }
    branch_data[label] = {
        "root": root,
        "permutation": permutation,
        "h_fib": h_fib,
        "h_id": h_id,
        "h_edges": h_edges,
        "h_graph": h_graph,
        "b_fib": b_fib,
        "b_id": b_id,
        "b_edges": b_edges,
        "b_graph": b_graph,
    }


# Explicit B_other -> B_kernel isomorphism, using a 60-point automorphism
# that conjugates the two native deck labels.  This is still bounded at G60.
perm_to_native_label = {
    permutation: label
    for label, permutation in deck.items()
}
conjugator = None
conjugator_action = None
for permutation in aut60:
    action = {}
    for label, native_permutation in deck.items():
        image = conjugate(permutation, native_permutation)
        if image not in perm_to_native_label:
            break
        action[label] = perm_to_native_label[image]
    else:
        if action.get(other_label) == kernel:
            conjugator = permutation
            conjugator_action = action
            break


def build_X_conjugator(permutation, deck_action):
    if permutation is None or deck_action is None:
        return None, False

    anchors = {
        base: ctos[(base, zero)]
        for base in range(15)
    }
    base_image = {}
    translation = {}
    for base in range(15):
        base_image[base], translation[base] = stoc[
            permutation[anchors[base]]
        ]

    coordinate_action = {
        coordinate: lcoord[deck_action[d["crosswalk"][coordinate]]]
        for coordinate in d["coords"]
    }
    affine_exact = all(
        stoc[permutation[state]] == (
            base_image[base],
            add(coordinate_action[coordinate], translation[base]),
        )
        for state, (base, coordinate) in stoc.items()
    )

    def apply(vertex):
        source_base, state = vertex
        target_base, coordinate = stoc[permutation[state]]
        return (
            base_image[source_base],
            ctos[(target_base, add(coordinate, translation[source_base]))],
        )

    output = {vertex: apply(vertex) for vertex in Xv}
    return output, affine_exact


Xconjugator, Xconjugator_affine = build_X_conjugator(
    conjugator, conjugator_action
)

other_bdata = branch_data[other_label]
b_kernel_fib, b_kernel_id, b_kernel_groups, b_kernel_edges, b_kernel_graph = (
    quotient(
        Xv,
        Xedges,
        lambda vertex: (vertex, J_label(vertex, kernel)),
    )
)

other_to_kernel = {}
other_to_kernel_well_defined = Xconjugator is not None
if Xconjugator is not None:
    for q, fiber in enumerate(other_bdata["b_fib"]):
        values = {
            b_kernel_id[Xconjugator[vertex]]
            for vertex in fiber
        }
        if len(values) != 1:
            other_to_kernel_well_defined = False
            continue
        other_to_kernel[q] = next(iter(values))

mapped_other_edges = {
    edge(other_to_kernel[a], other_to_kernel[b])
    for a, b in other_bdata["b_edges"]
    if a in other_to_kernel and b in other_to_kernel
}

a_shell = shell_profile(branch_data[delta_label]["b_graph"])
b_shell = shell_profile(b_kernel_graph)
a_b_shell_difference = first_profile_difference(a_shell, b_shell)

branch_classification_checks = {
    "both_native_branch_rows_pass":
        all(row["row_pass"] for row in branch_rows.values()),
    "selected_a_branch_is_exact_green_Ba":
        selected_root_action == K
        and set(map(frozenset, branch_data[delta_label]["h_fib"]))
        == set(map(frozenset, Kfib))
        and set(map(frozenset, branch_data[delta_label]["b_fib"]))
        == set(map(frozenset, Bafib))
        and branch_data[delta_label]["b_edges"] == Bae,
    "other_branch_conjugates_to_kernel_B_type":
        conjugator is not None
        and Xconjugator_affine
        and len(set(Xconjugator.values())) == 900
        and {
            edge(Xconjugator[a], Xconjugator[b])
            for a, b in Xedges
        } == Xedges
        and all(
            Xconjugator[J_label(vertex, other_label)]
            == J_label(Xconjugator[vertex], kernel)
            for vertex in Xv
        )
        and other_to_kernel_well_defined
        and len(other_to_kernel) == 450
        and len(set(other_to_kernel.values())) == 450
        and mapped_other_edges == b_kernel_edges,
    "a_and_kernel_terminal_types_proved_nonisomorphic":
        a_b_shell_difference is not None,
}


root_checks = {
    "Delta_is_unique_nonidentity_center_with_exchange_order4_roots":
        len(exchange_square_roots_by_center["Delta"]) > 0
        and len(exchange_square_roots_by_center["E"]) == 0
        and len(exchange_square_roots_by_center["E_Delta"]) == 0,
    "Delta_exchange_root_count240": len(delta_roots) == 240,
    "all_Delta_roots_have_order4": all(
        group_multiply(root, root) == abstract_Delta
        and group_multiply(
            group_multiply(root, root),
            group_multiply(root, root),
        ) == group_identity
        for root in delta_roots
    ),
    "Delta_root_product_profile_exact":
        root_product_failure_count == 0
        and root_product_profile == {
            delta_label: 120,
            other_label: 120,
        },
    "two_Delta_root_conjugacy_orbits_size120":
        sorted(map(len, root_orbits)) == [120, 120],
    "root_orbits_are_exactly_product_labeled":
        sorted(
            tuple(row["lift_product_labels"])
            for row in c4_orbit_rows
        ) == sorted(((delta_label,), (other_label,))),
    "one_hundred_twenty_C4_subgroups":
        len(c4_subgroups) == 120,
    "two_C4_subgroup_orbits_size60":
        sorted(
            row["C4_subgroup_count"]
            for row in c4_orbit_rows
        ) == [60, 60],
    "selected_and_reverse_tau_are_mutual_inverse_roots":
        selected_root in delta_root_set
        and reverse_root in delta_root_set
        and group_inverse(selected_root) == reverse_root
        and selected_root_action == K
        and reverse_root_action == Kreverse,
    "selected_and_reverse_generate_same_C4":
        c4_subgroup(selected_root) == c4_subgroup(reverse_root),
    "successful_tau_pair_is_exact_selected_inverse_pair":
        successful_taus == {tau, tau[::-1]},
    "selected_tau_lift_product_is_delta_label":
        native_perm_to_label[
            Cperms[root_product_index(selected_root)]
        ] == delta_label,
    **branch_classification_checks,
}


all_checks = {
    **leaf_checks,
    **full_group_checks,
    **center_checks,
    **root_checks,
}


summary = {
    "audit_id": "product_y_automorphism_c4_audit",
    "construction": "Y=(G60 square G60)/diag<b>",
    "source_audits": {
        "product_cell_audit_pass": True,
        "product_foliation_audit_pass": True,
        "product_g1800_audit_pass": True,
    },
    "AutG60_order": len(aut60),
    "b_centralizer_order": len(centralizer),
    "b_centralizer_center_order": len(centralizer_center),
    "b_centralizer_generator_count": len(Cgenerators),
    "b_centralizer_orbit_profile": centralizer_orbit_profile,
    "b_centralizer_point_stabilizer_profile":
        centralizer_stabilizer_profile,
    "AutY": {
        "proved_full_order": len(abstract_elements),
        "factor_preserving_order": factor_preserving_elements,
        "factor_exchanging_order": factor_exchanging_elements,
        "vertex_orbit_size": len(candidate_vertex_orbit),
        "color_preserving_vertex_stabilizer_upper_bound":
            color_preserving_stabilizer_upper_bound,
        "full_group_structure": (
            "((C_AutG60(b) x C_AutG60(b)) rtimes C2_swap) "
            "/ <diag(b)>"
        ),
        "full_group_completeness_proved": full_AutY_proved,
        "degree1800_GraphMatcher_used": False,
    },
    "center": {
        "order": len(abstract_center),
        "known_elements": ["identity", "E", "Delta", "E_Delta"],
        "named_action_checks": center_action_checks,
        "nontrivial_quotients": central_quotients,
        "quotient_distance_shell_first_differences":
            central_quotient_differences,
    },
    "factor_exchanging_square_root_count_by_center": {
        name: len(roots)
        for name, roots in exchange_square_roots_by_center.items()
    },
    "Delta_C4_classification": {
        "oriented_root_count": len(delta_roots),
        "C4_subgroup_count": len(c4_subgroups),
        "root_lift_product_profile": root_product_profile,
        "orbit_rows": c4_orbit_rows,
        "selected_tau": list(tau),
        "selected_lift_product": delta_label,
        "selected_and_reverse_generate_same_C4":
            c4_subgroup(selected_root) == c4_subgroup(reverse_root),
        "branch_rows": branch_rows,
        "other_branch_isomorphic_to": "B_" + kernel,
        "selected_vs_other_first_exact_difference":
            a_b_shell_difference,
    },
    "checks": all_checks,
    "failed_checks": [
        name for name, passed in all_checks.items()
        if not passed
    ],
    "audit_pass": all(all_checks.values()),
    "boundary": {
        "full_AutY_order_and_structure_proved": full_AutY_proved,
        "center_and_factor_exchanging_C4_roots_classified":
            all(center_checks.values()) and all(root_checks.values()),
        "Delta_intrinsically_recognized_as_unique_nontrivial_central_exchange_square":
            root_checks[
                "Delta_is_unique_nonidentity_center_with_exchange_order4_roots"
            ],
        "selected_tau_C4_conjugacy_class_identified":
            all(root_checks.values()),
        "oriented_K_versus_K_inverse_selected_by_bare_graph": False,
        "unique_embedded_C4_selected_by_bare_unlabeled_graph": False,
        "all_G1800_graphs_or_covers_classified": False,
        "bare_unlabeled_G1800_uniqueness_proved": False,
        "physical_or_spacetime_memory_claim": False,
    },
    "verdict": (
        "The intrinsic two-foliation bounds the full automorphism group of "
        "the product Y by its two block-preserving G60 leaf restrictions. "
        "The explicit normalizer quotient attains that bound.  The center "
        "and every foliation-exchanging order-four square root are then "
        "classified abstractly; the successful unordered tau pair selects "
        "one C4 branch while factor reversal changes only its orientation."
    ),
}

print(json.dumps(summary, indent=2, sort_keys=True))
