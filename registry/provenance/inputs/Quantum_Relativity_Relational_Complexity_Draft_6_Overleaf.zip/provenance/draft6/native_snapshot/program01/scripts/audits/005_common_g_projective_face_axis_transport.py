#!/usr/bin/env python3

from pathlib import Path
from collections import defaultdict, Counter
from datetime import datetime, timezone
import json

HERE = Path(__file__).resolve().parents[2]

P41 = (
    Path.home()
    / "dev/cori/research/mathematics"
    / "41-order-4-dodecahedral-residue"
)

JSON41 = P41 / "artifacts/json"
PROV = P41 / "artifacts/provenance"

SOURCES = {
    "AUT":
        JSON41 / "native_g60_automorphism_deck_cache.v1.json",

    "SIGNED":
        JSON41 / "signed_24_face_block_closure_audit_025.json",

    "H35":
        PROV / "project41_order4_square_cartan_orientation_201h35b.v1.json",

    "FP7":
        PROV / "project41_u2_gauge_bridge_connection_frontier_checkpoint_201fp7.v1.json",

    "FS":
        PROV / "project41_signed_event_doublet_vector_lift_201fs.v1.json",

    "FT":
        PROV / "project41_event_vector_u2_u1_stabilizer_201ft.v1.json",

    "FV":
        PROV / "project41_positive_pair_hermitian_geometry_201fv.v1.json",

    "FW":
        PROV / "project41_neutral_generator_anatomy_201fw.v1.json",
}

AUDIT004 = (
    HERE
    / "artifacts/json"
    / "004_face_axis_realization_gauge_descent.json"
)

JSON_OUT = (
    HERE
    / "artifacts/json"
    / "005_common_g_projective_face_axis_transport.json"
)

NOTE_OUT = (
    HERE
    / "notes"
    / "005_common_g_projective_face_axis_transport.md"
)


def load(path):
    if not path.is_file():
        raise RuntimeError(
            "missing source: " + str(path)
        )

    return json.loads(
        path.read_text(
            encoding="utf-8",
        )
    )


D = {
    name: load(path)
    for name, path in SOURCES.items()
}

audit004 = load(AUDIT004)

aut = D["AUT"]
signed = D["SIGNED"]
h35 = D["H35"]
fp7 = D["FP7"]
fs = D["FS"]
ft = D["FT"]
fv = D["FV"]
fw = D["FW"]

checks = {}

checks["audit004_passes"] = (
    audit004.get("audit_pass") is True
)

checks["historical_sources_green"] = all(
    data.get("audit_pass") is True
    for name, data in D.items()
    if name not in ("AUT",)
)

checks["AutG60_cache_passes"] = (
    aut.get("cache_pass") is True
)

g_index = h35["source_action"]["g_automorphism_index"]
r1_index = h35["source_action"]["r1_automorphism_index"]

checks["g_is_AutG60_index3"] = (
    g_index == 3
)

checks["r1_is_AutG60_index2"] = (
    r1_index == 2
)

checks["g_order4_and_square_r1"] = (
    h35["source_action"]["g_order"] == 4
    and h35["source_action"]["g_square_equals_r1"] is True
    and h35["source_action"]["r1_order"] == 2
)

aut_rows = {
    row["automorphism_index"]: row
    for row in aut["measurements"]["automorphism_rows"]
}

g_row = aut_rows[g_index]
r1_row = aut_rows[r1_index]

g = tuple(g_row["permutation"])
r1 = tuple(r1_row["permutation"])

checks["cache_g_order4"] = (
    g_row["permutation_order"] == 4
)

checks["cache_r1_order2"] = (
    r1_row["permutation_order"] == 2
)

checks["cache_g_square_equals_r1"] = all(
    g[g[i]] == r1[i]
    for i in range(len(g))
)

blocks = signed["measurements"]["signed_blocks"]

block_by_states = {}

for index, block in enumerate(blocks):
    key = tuple(
        sorted(
            int(v)
            for v in block["five_state_block"]
        )
    )

    if key in block_by_states:
        raise RuntimeError(
            "duplicate signed block state set"
        )

    block_by_states[key] = index


def block_image(block_index, perm):
    block = blocks[block_index]

    image = tuple(
        sorted(
            perm[int(v)]
            for v in block["five_state_block"]
        )
    )

    if image not in block_by_states:
        raise RuntimeError(
            "native automorphism image is not a signed block"
        )

    return block_by_states[image]


g_block_perm = {
    i: block_image(i, g)
    for i in range(len(blocks))
}

r1_block_perm = {
    i: block_image(i, r1)
    for i in range(len(blocks))
}

checks["all_g_block_images_exist"] = (
    len(g_block_perm) == 24
)

checks["all_r1_block_images_exist"] = (
    len(r1_block_perm) == 24
)

checks["g2_equals_r1_on_all_signed_blocks"] = all(
    g_block_perm[g_block_perm[i]]
    == r1_block_perm[i]
    for i in range(len(blocks))
)

positive_by_carrier = defaultdict(list)
negative_by_carrier = defaultdict(list)

for i, block in enumerate(blocks):
    carrier = int(block["carrier_index"])

    if block["sign"] == "positive":
        positive_by_carrier[carrier].append(i)

    elif block["sign"] == "negative":
        negative_by_carrier[carrier].append(i)

for carrier in range(6):
    positive_by_carrier[carrier].sort()
    negative_by_carrier[carrier].sort()

checks["two_positive_blocks_per_face"] = all(
    len(positive_by_carrier[c]) == 2
    for c in range(6)
)

checks["two_negative_blocks_per_face"] = all(
    len(negative_by_carrier[c]) == 2
    for c in range(6)
)


def carrier_of(block_index):
    return int(
        blocks[block_index]["carrier_index"]
    )


carrier_map = {}

for carrier in range(6):
    images = {
        carrier_of(g_block_perm[i])
        for i in positive_by_carrier[carrier]
    }

    if len(images) != 1:
        raise RuntimeError(
            "positive pair maps to multiple carriers"
        )

    carrier_map[carrier] = next(iter(images))

expected_carrier_map = {
    0: 4,
    1: 5,
    2: 2,
    3: 3,
    4: 1,
    5: 0,
}

checks["g_face_carrier_map_exact"] = (
    carrier_map == expected_carrier_map
)

positive_pair_rows = []

for carrier in range(6):
    target = carrier_map[carrier]

    source_pair = positive_by_carrier[carrier]
    target_pair = positive_by_carrier[target]

    images = [
        g_block_perm[i]
        for i in source_pair
    ]

    exact_pair = (
        sorted(images)
        == sorted(target_pair)
    )

    positive_pair_rows.append({
        "source_carrier": carrier,
        "target_carrier": target,
        "source_positive_blocks": source_pair,
        "g_image_positive_blocks": images,
        "target_positive_blocks": target_pair,
        "exact_unordered_pair_match": exact_pair,
    })

checks["g_maps_every_positive_pair_exactly"] = all(
    row["exact_unordered_pair_match"]
    for row in positive_pair_rows
)

checks["positive_sign_preserved_all"] = all(
    blocks[g_block_perm[i]]["sign"] == "positive"
    for carrier in range(6)
    for i in positive_by_carrier[carrier]
)

checks["FS_identifies_positive_blocks_as_event_basis_objects"] = (
    fs["checks"]["all_outward_blocks_are_positive"] is True
    and fs["face_module"]["interpretation"]
    == (
        "The four signed face blocks are the canonical basis objects "
        "of the four-real-dimensional face permutation module."
    )
)

checks["FT_event_line_stabilizer_is_U1"] = (
    ft["exact_group_theory"]["point_stabilizer_group"]
    == "U(1)"
)

checks["FV_positive_lines_are_complementary"] = (
    fv["u1_geometry"]["anchor_conditioned_U1_count_per_face"] == 2
    and fv["u1_geometry"]["relation"]
    == "distinct complementary coordinate-circle point stabilizers"
    and fv["u1_geometry"]["generated_connected_subgroup"]
    == "U(1) x U(1) maximal torus"
)

checks["FW_T_is_unique_traceless_torus_line"] = (
    fw["neutral_plane"]["neutral_su2_direction"]
    == "T = A1 - A0"
    and fw["neutral_plane"]["central_direction"]
    == "J = A0 + A1"
)

fn = fp7["results"]["201FN"]
flb = fp7["results"]["201FLB"]

checks["local_states_single_native_AutG60_orbit"] = (
    flb["single_AutG60_orbit"] is True
    and flb["local_order_parameter_state_count"] == 12
)

checks["all_U2_profiles_transport_conjugate"] = (
    flb["all_transported_U2_profiles"] == "4_1_3"
)

checks["native_semilinear_U2_cocycle"] = (
    fn["native_semilinear_U2_transition_cocycle"] is True
    and fn["native_group_cocycle_failures"] == 0
    and fn["matrix_cocycle_failures"] == 0
    and fn["C2_semilinearity_cocycle_failures"] == 0
)

checks["all_12x12_pair_transitions_present"] = (
    fn["pair_transition_count"] == 144
)

checks["semilinear_pair_groupoid_flat"] = (
    fn["section_induced_pair_groupoid"] == "flat"
)

checks["section_change_gauge_law_exact"] = (
    fn["section_change_gauge_law"]
    == "T'_yx = G_y T_yx G_x^-1"
)

checks["projective_face_axis_transport_derived"] = (
    checks["g_maps_every_positive_pair_exactly"]
    and checks[
        "FS_identifies_positive_blocks_as_event_basis_objects"
    ]
    and checks["FT_event_line_stabilizer_is_U1"]
    and checks["FV_positive_lines_are_complementary"]
    and checks["FW_T_is_unique_traceless_torus_line"]
    and checks["local_states_single_native_AutG60_orbit"]
    and checks["native_semilinear_U2_cocycle"]
    and checks["all_12x12_pair_transitions_present"]
)

audit_pass = all(checks.values())

verdict = (
    "common_native_order4_exchange_g_transports_the_descended_"
    "face_neutral_Cartan_axis_projectively_under_the_native_"
    "semilinear_U2_bundle_action"
    if audit_pass
    else
    "common_g_projective_face_axis_transport_not_closed"
)

# Diagnostic cycle profile only. No intrinsic ordering is inferred.
seen = set()
cycle_lengths = []

for start in range(len(blocks)):
    if start in seen:
        continue

    cycle = []
    j = start

    while j not in cycle:
        cycle.append(j)
        seen.add(j)
        j = g_block_perm[j]

    cycle_lengths.append(len(cycle))

cycle_profile = dict(
    sorted(
        Counter(cycle_lengths).items()
    )
)

payload = {
    "packet":
        "005_common_g_projective_face_axis_transport",

    "audit_pass":
        audit_pass,

    "verdict":
        verdict,

    "timestamp_utc":
        datetime.now(timezone.utc).isoformat(),

    "sources": {
        name: str(path)
        for name, path in SOURCES.items()
    },

    "source_program1_audit004":
        str(AUDIT004),

    "checks":
        checks,

    "common_native_exchange": {
        "AutG60_index":
            g_index,

        "order":
            4,

        "square_AutG60_index":
            r1_index,

        "square_name":
            "r1",

        "deck_action":
            g_row["deck_action"],

        "face_carrier_map":
            {
                str(k): v
                for k, v in carrier_map.items()
            },
    },

    "positive_event_pair_transport":
        positive_pair_rows,

    "signed_block_cycle_length_profile":
        {
            str(k): v
            for k, v in cycle_profile.items()
        },

    "bundle_structure": {
        "local_state_count":
            flb["local_order_parameter_state_count"],

        "single_native_AutG60_orbit":
            flb["single_AutG60_orbit"],

        "pair_transition_count":
            fn["pair_transition_count"],

        "native_semilinear_U2_transition_cocycle":
            fn["native_semilinear_U2_transition_cocycle"],

        "native_group_cocycle_failures":
            fn["native_group_cocycle_failures"],

        "matrix_cocycle_failures":
            fn["matrix_cocycle_failures"],

        "C2_semilinearity_cocycle_failures":
            fn["C2_semilinearity_cocycle_failures"],

        "pair_groupoid":
            fn["section_induced_pair_groupoid"],

        "section_change_gauge_law":
            fn["section_change_gauge_law"],
    },

    "theorem": (
        "Let g=Aut(G60)[3]. On the native signed-face system g maps "
        "the unordered pair of positive event basis lines on every "
        "face exactly onto the corresponding unordered positive pair "
        "on g(f). The earned native semilinear U(2) bundle action "
        "therefore transports the maximal torus generated by their "
        "two U(1) point stabilizers to the target maximal torus. "
        "Because the U(2) center is intrinsic, the unique traceless "
        "line in this torus transports to the unique target traceless "
        "line. Hence U_g [T_f] U_g^-1 = [T_g(f)]."
    ),

    "earned_statement": (
        "The common native order-four exchange g=Aut(G60)[3], whose "
        "square is r1, transports the descended face neutral Cartan "
        "axis projectively across the native semilinear U(2) face "
        "bundle. No ordered A0/A1 convention, transverse Pauli frame, "
        "or unique raw transport matrix is required."
    ),

    "boundary": {
        "projective_face_axis_transport_closed":
            audit_pass,

        "T_sign_under_g_derived":
            False,

        "ordered_A0_A1_transport_derived":
            False,

        "raw_Hilbert_g_matrix_unique":
            False,

        "raw_face_transport_matrix_unique":
            False,

        "face_to_spin_axis_map_constructed":
            False,

        "H58_common_g_extension_proved":
            False,

        "H71_unconditional":
            False,

        "g_equals_S1":
            False,

        "r1_equals_S1":
            False,

        "physical_claim":
            False,
    },

    "next_target": (
        "Compare the common-g action on the descended face projective "
        "axis with H35's common-g orientation of the r1-selected Weyl "
        "Cartan axis. Test whether the H58 one-dimensional SU(2) Schur "
        "intertwiner space contains a g-equivariant extension. Do not "
        "choose an arbitrary SO(3) generator alignment or infer the "
        "result from representation equivalence alone."
    ),
}

JSON_OUT.parent.mkdir(
    parents=True,
    exist_ok=True,
)

NOTE_OUT.parent.mkdir(
    parents=True,
    exist_ok=True,
)

JSON_OUT.write_text(
    json.dumps(
        payload,
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

note = f"""# 005 Common-g Projective Face-Axis Transport

Audit pass: {str(audit_pass).lower()}

Verdict:

    {verdict}

## Native source

The common exchange is

    g = Aut(G60)[3],

with

    order(g) = 4,
    g^2 = Aut(G60)[2] = r1.

Its face-carrier action is

    (0 4 1 5)(2)(3).

## Exact positive-pair transport

On all six native face carriers, g maps the unordered pair of positive
signed face blocks exactly onto the unordered positive pair of the target
face.

201FS identifies these positive signed blocks with the native positive
event basis objects in the four-real-dimensional face module.

201FT assigns each positive event line a U(1) point stabilizer.

201FV proves the two stabilizers are complementary coordinate circles
generating a maximal U(1) x U(1) torus.

201FW identifies

    J = A0 + A1

as the central line and

    T = A1 - A0

as the traceless neutral SU(2)-type Cartan line.

## Native Hilbert transport

201FLB and 201FN establish that the twelve local face/order-parameter
states form one native Aut(G60) orbit with transport-conjugate U(2)
envelopes and an exact native semilinear U(2) transition cocycle.

There are exactly 144 pair transitions on the twelve fibers, with zero
native-group, matrix-cocycle, or C2-semilinearity failures.

Therefore the native action of g transports the unordered positive event
line pair and its maximal torus to the target fiber.

The U(2) center is intrinsic. Hence the unique traceless line in that
torus must transport to the target traceless line.

Thus

    U_g [T_f] U_g^-1 = [T_g(f)].

This is a projective statement. No A0/A1 ordering or sign convention is
required.

## Boundary

The sign of T under g is not derived.

No unique raw Hilbert-space matrix for g is selected.

No arbitrary transverse Pauli frame is introduced.

The face-to-spin axis identification remains open.

The H58 Schur intertwiner has not yet been extended equivariantly across
the common g action.

H71 is not yet unconditional.

No physical claim is made.

## Next theorem front

Test whether the H58 one-dimensional SU(2) intertwiner space admits a
g-equivariant extension between

    [T_face]

and the H35/H41 r1-selected Weyl Cartan axis.

Representation equivalence alone is not sufficient.
"""

NOTE_OUT.write_text(
    note,
    encoding="utf-8",
)

print("PACKET: 005_common_g_projective_face_axis_transport")
print("AUDIT_PASS:", str(audit_pass).lower())
print("VERDICT:", verdict)
print("CHECK_COUNT:", len(checks))
print(
    "FAILED_CHECK_COUNT:",
    sum(not value for value in checks.values()),
)

for key, value in checks.items():
    print(
        "CHECK",
        key,
        "=",
        str(value).lower(),
    )

print()
print("G_FACE_CARRIER_MAP:", carrier_map)
print(
    "SIGNED_BLOCK_CYCLE_LENGTH_PROFILE:",
    cycle_profile,
)

print()
print("EARNED:")
print(
    "g=Aut(G60)[3] maps every positive event pair "
    "exactly to the target positive event pair."
)
print(
    "The native semilinear U(2) bundle therefore transports "
    "[T_f] to [T_g(f)]."
)
print(
    "Projective law: U_g [T_f] U_g^-1 = [T_g(f)]."
)

print()
print("BOUNDARY:")
print("T_sign_under_g_derived = false")
print("raw_Hilbert_g_matrix_unique = false")
print("face_to_spin_axis_map_constructed = false")
print("H58_common_g_extension_proved = false")
print("H71_unconditional = false")
print("physical_claim = false")

print()
print("NEXT:")
print(payload["next_target"])

print()
print("JSON_OUT:", JSON_OUT)
print("NOTE_OUT:", NOTE_OUT)
print("SOURCE_MUTATION: none")
