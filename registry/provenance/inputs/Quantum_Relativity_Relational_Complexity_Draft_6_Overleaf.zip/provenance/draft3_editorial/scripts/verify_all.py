#!/usr/bin/env python3
"""Run all bounded finite checks offline. TeX compilation does not use Python."""
from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
STEPS = [
    ('verify_constructions.py', 'verification_report.json'),
    ('verify_history_reconstruction.py', 'history_reconstruction_report.json'),
    ('verify_mode.py', 'mode_verification_report.json'),
    ('verify_census_family.py', 'census_family_report.json'),
    ('verify_rank8_kernel.py', 'rank8_kernel_report.json'),
    ('verify_wxyzti_scope.py', 'wxyzti_scope_report.json'),
]

def main() -> None:
    reports = []
    for i, (script, report) in enumerate(STEPS, 1):
        print(f'PROGRESS {i}/{len(STEPS)}: {script}', flush=True)
        subprocess.run([sys.executable, str(ROOT / 'scripts' / script)], check=True)
        reports.append(json.loads((ROOT / 'data/generated' / report).read_text()))
    summary = {
        'audit': 'draft3_finite_verification',
        'all_checks_pass': all(r['all_checks_pass'] for r in reports),
        'check_count': sum(r['check_count'] for r in reports),
        'reports': {name: {'check_count': r['check_count'], 'all_checks_pass': r['all_checks_pass']}
                    for (_, name), r in zip(STEPS, reports)},
        'scope': 'Finite identities and explicitly bounded constructions only; no automatic native cross-register or physical closure.',
    }
    (ROOT / 'data/generated/draft3_verification_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2), flush=True)
    if not summary['all_checks_pass']:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
