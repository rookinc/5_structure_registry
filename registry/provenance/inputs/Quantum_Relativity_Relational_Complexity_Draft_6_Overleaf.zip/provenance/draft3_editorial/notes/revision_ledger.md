# Draft 3 revision ledger

**Baseline:** the authentic Draft 2 Overleaf ZIP recovered from the user's Library,
checked against the attached 32-page PDF. **Revision date:** 22 September 2026.
**Scope:** structural additions; original formulas, formal statements and Mode
section preserved. Original equations 1–52 retain their numbers. New equation
families are F1–F8, K1–K4, IC1 and W1–W2. The draft is 48 pages including
five front-matter pages, appendices and references.

## New sections and evidence

2A records the external Minchenko–Wanless F1 anchor and the three census entries.
It includes the author-reported discovery route: Scott noticed the anomalous
[60,4] near-match in the displayed research stream and asked for investigation.
This is discovery provenance, not a claim of new graph classification.

2B independently reconstructs the published common cover, its central V4,
three exact quotient isomorphisms, common Q30, canonical parity chart, free
C2^3 composite deck group and rooted-stabilizer descent. Full automorphism
completeness uses the external census's order-960 bound; the subgroup and
all maps are computed.

2C defines the bounded relational kernel from the explicit normalized 028I
formulas. It proves elementary identities and replays all 64 intersection
products, icosahedral fusion, the 24-element color group and its orbitals.
The original producer files are archived, not falsely reported as fully rerun.

6A defines informative coupling through future admission or response and
information current through admitted payload handoffs. A relation-level example
is not promoted to a unique reversible update.

13B replays four six-step overlay circuits, the 48-to-12 reciprocal selector,
and commuting channel/partner actions. It distinguishes the original ten-step
WXYZTITZYXW contract and states a common-domain crosswalk certificate.

22.3 preserves local carrier step counts under a graph cover, conditional on
separate event, recovery, field-distance and saturation hypotheses for c_Th.

Appendices J–L supply source sites, verification domains and the bounded horizon
for the 16=15+1 register, G900 and electromagnetic/geometric reductions.
Appendix H, the glossary, guardrails and conclusion are updated accordingly.

## Mathematical corrections relative to the exploratory conversation

1. Q30 = L(CDC(Petersen)) is not G30 = L(dodecahedron). The census family
   shares Q30; Draft 2's original quotient route and r1 visibility remain intact.
   The MW bipartite quotient I30,3 is neither of these nonbipartite graphs.
2. The selected eight-fold cover has free deck group C2^3, not D8. Its
   fifteen fibers ARE invariant under the published full group. The earlier
   claim of no size-eight block system was not reproduced and is rejected.
   Root stabilizer order eight, block stabilizer order 64 and deck group
   order eight are different objects; the rooted D8 projection is faithful.
3. The three family involutions are central. No automorphism of K120
   conjugates tau5 to tau6. Their quotients are not automatically a QR modal pair.
4. K120 records carrier-walk parity in a fixed canonical-double chart. Deck
   operation words are not necessarily edge walks. Canonical lifts of a,b
   commute, but that is not a theorem about every conceivable history lift.
5. Local graph bijectivity alone does not prove event-preserving propagation
   or c_Th saturation. The original causal definition and conditions remain.
6. The twelve points X12 are not the twelve direction/character bins: those
   bins contain 96 ordered pairs. The twelve WXYZTI pairs are three channels
   times four circuits; forming a pair removes its member-role bit. No map to
   the twelve Born pentagons follows from the count.
7. The rank-eight adjacency algebra and its automorphism group have different
   mathematical types. Matrix noncommutativity is not automatically execution
   noncommutativity. F/R transpose is not already the QR modal point action.
8. A uniform extra role toggle by a candidate M still commutes with the
   independent role flip. It does not by itself produce a semidirect extension.
9. WXYZTI-to-kernel, Mode-to-relation-color and Born-basis bindings remain H.
   The earlier exploratory phrase 'closed functional architecture' is not used
   to certify these missing native maps.
10. The current I/H signing and K parity require a common-domain and gauge
    comparison. A 15/15 edge-sign count alone does not establish a universal
    invariant mismatch or native current derivation.
11. The historical D8 x C2 source explicitly reports representation-level
    compatibility, not a native common-domain certificate. No causal assignment
    of the WXYZTI role bit to that action is promoted here.
12. The number 960 is an automorphism-group order for K120, not its vertex
    count. The proposed 16 x 60 object is a separate register construction.
    A binary line selects a 3D quotient, not a unique complement, a time
    orientation or a Lorentzian metric. The certified integer time remains.

## Preservation and tests

The original protected expressions and formal statement blocks remain unchanged.
The complete original Mode section and three upstream JSON artifacts are also
protected by hashes. Added material is not permitted to renumber the old content.

158 finite checks pass across six reports; editorial integrity is checked
separately. The package includes all new matrices, numerical graph inputs,
quotient maps and test scripts. Original producer provenance and physical
correspondence obligations are explicitly excluded from the new pass count.

## Physical scope

No new Maxwell, Born-instrument, spacetime, CMB, G900-wiring or superposition
claim is promoted from a count, graph cover or symmetry analogy. The electromagnetic
comparison is an operational reduction target with incidence, dynamics, sources,
constraints and calibration still required. Existing physical boundaries are retained.
