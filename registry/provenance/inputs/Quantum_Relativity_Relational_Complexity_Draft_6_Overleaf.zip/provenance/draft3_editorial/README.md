# Quantum Relativity as Transducer Theory — Draft 3

Scott Allen Cave · Center of Recursive Inquiry · 22 September 2026

## Open in Overleaf

Create a new project with **Upload Project**, choose the supplied ZIP, and set
`main.tex` as the main document. Use **pdfLaTeX**. The bibliography is built with
BibTeX; Overleaf's normal automatic build handles it. No shell escape, network
access, Python execution, custom fonts or private repository access is needed to
compile the manuscript. Standard TeX Live packages supply the typography.

The compiled 48-page review PDF is in `preview/`. All text and equations are
editable LaTeX. The preview is not used as manuscript content.

## What changed

Sections 2A–2C add the Minchenko–Wanless literature anchor, the AT4Val[60,4–6]
census family, the common 120-vertex cover and the normalized twelve-point
rank-eight relation algebra. Section 6A defines informative coupling and information
current. Section 13B records the bounded WXYZTI replay and its still-open native
crosswalk. Proposition 22.3 states the conditional covering/locality result.
Appendices J–L supply source sites, reproduction scope and structural hypotheses.

The original equations (1)–(52), all 22 protected formal statement blocks, and
the entire Draft 2 Mode section with M1–M4 are preserved. The original upstream
JSON reports remain byte-identical. Appendix H and `notes/revision_ledger.md`
separate new checks, imported results and open physical or provenance interfaces.

## Important corrections to preliminary interpretations

The shared family intermediate is Q30 = L(CDC(Petersen)), not the inherited
G30 = L(dodecahedron). The specified K120-to-G15 deck group is C2^3; the D8
root stabilizer is a different action. Kernel points, WXYZTI pairs, Born histories
and direction/character relation bins are not identified by their common count.
The WXYZTI-to-kernel-to-Mode bridge remains an explicit hypothesis.

## Reproduce the finite checks

Install the packages in `requirements.txt` in a Python environment, then run:

    python3 scripts/verify_all.py

The six scripts run offline using the included numerical inputs. The current
receipt records 158 passing finite checks: 34 inherited carrier/matrix checks,
16 history reconstruction checks, 20 modal checks, 46 census-family checks,
27 rank-eight kernel checks and 15 bounded WXYZTI checks. These counts do not
include historical upstream passes that were merely cited.

Compile locally with:

    bash build.sh

After compilation, run:

    python3 scripts/verify_manuscript.py

This separately checks preserved sources, inclusion counts, protected labels,
citations and TeX layout diagnostics. `notes/build_receipt.json` records the
compiled output and environment. It does not certify a physical interpretation.

## Project organization

`sections/`, `appendices/`, `equations/`, `statements/` contain the manuscript.
`references.bib` contains the bibliography, including the Minchenko–Wanless paper
and all census sources. Appendix J contains the publisher, Monash and
ResearchGate addresses used for the anchor.

`data/census/` contains transcribed published numerical inputs with source URLs.
`data/generated/` contains exact maps and verification reports.
`provenance/draft3/` contains unchanged source scripts/notes and a source ledger.
`provenance/draft2_editorial/` retains older editorial receipts as historical
records rather than presenting them as new checks.
`notes/` contains the current revision ledger, protections and build receipt.

The original Audit 028I/028J files are archival producer sources and require
upstream project data. Run the new independent normalized replay through
`verify_all.py`; the archive is not silently treated as a fully rerun producer
chain. The WXYZTI script likewise replays the archived four-circuit table, not
an admission-blind generator or the separate ten-step contract.

`SHA256SUMS.txt` hashes the delivered files (excluding itself). No external
library, Drive file or original manuscript was overwritten by this build.
