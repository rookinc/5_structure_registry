#!/usr/bin/env bash
# Call as ./build.sh or bash build.sh. No top-level exit/set -e changes the caller's shell.
qr_build_main() {
  cd -- "$(dirname -- "${BASH_SOURCE[0]}")" || return 1
  if ! command -v latexmk >/dev/null 2>&1; then
    printf '%s\n' 'latexmk is required; alternatively import this ZIP into Overleaf.' >&2
    return 1
  fi
  if command -v bibtex >/dev/null 2>&1; then
    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
  elif command -v bibtex.original >/dev/null 2>&1; then
    latexmk -pdf -e '$bibtex="bibtex.original %O %B";' -interaction=nonstopmode -halt-on-error main.tex
  else
    printf '%s\n' 'BibTeX is required for the reference list.' >&2
    return 1
  fi
}
qr_build_main "$@"
