#!/usr/bin/env python3
"""Reconstruct the census family from published numerical inputs.

No network access. Source graph is C4[120,38]; compare each central
involution quotient against an independently described graph. The inherited
G60 coordinates are retained. Full-group completeness is imported from the
census; the generated subgroup and every reported identity are computed here.
"""
from __future__ import annotations
from collections import Counter, deque
from itertools import product
from pathlib import Path
import json, re, math
import networkx as nx

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'data/generated'; OUT.mkdir(parents=True,exist_ok=True)
def comp(p,q): return tuple(p[q[i]] for i in range(len(p)))
def order(p):
 seen=set(); n=1
 for i in range(len(p)):
  if i in seen: continue
  j=i; k=0
  while j not in seen: seen.add(j); k+=1; j=p[j]
  n=math.lcm(n,k)
 return n

def closure(gs,n):
 e=tuple(range(n)); seen={e}; todo=deque([e])
 while todo:
  p=todo.popleft()
  for g in gs:
   q=comp(g,p)
   if q not in seen: seen.add(q); todo.append(q)
 return sorted(seen)

def quotient(G,gs):
 left=set(G); blocks=[]
 while left:
  root=min(left); orbit={root}; todo=[root]
  while todo:
   v=todo.pop()
   for g in gs:
    w=g[v]
    if w not in orbit: orbit.add(w);todo.append(w)
  blocks.append(sorted(orbit));left-=orbit
 blocks.sort(); q={v:i for i,b in enumerate(blocks) for v in b}
 H=nx.Graph();H.add_nodes_from(range(len(blocks)))
 H.add_edges_from((q[u],q[v]) for u,v in G.edges())
 return H,q,blocks

def cover_check(G,H,q):
 return all(len({q[u] for u in G[v]})==len(G[v]) and {q[u] for u in G[v]}==set(H[q[v]]) for v in G)

def cdc(G):
 H=nx.Graph();H.add_nodes_from((v,s) for v in G for s in (0,1))
 for u,v in G.edges():
  for s in (0,1):H.add_edge((u,s),(v,1-s))
 return H

def iso(G,H):
 gm=nx.algorithms.isomorphism.GraphMatcher(G,H)
 if not gm.is_isomorphic():return None
 return gm.mapping

def girth(G):
 best=len(G)+1
 for s in G:
  ds={s:0}; par={s:None}; todo=deque([s])
  while todo:
   v=todo.popleft()
   for w in G[v]:
    if w not in ds:ds[w]=ds[v]+1;par[w]=v;todo.append(w)
    elif par[v]!=w:best=min(best,ds[v]+ds[w]+1)
 return best if best<=len(G) else None

def inv(G):return {'vertices':len(G),'edges':G.number_of_edges(),'degrees':dict(Counter(dict(G.degree()).values())), 'connected':nx.is_connected(G),'bipartite':nx.is_bipartite(G),'girth':girth(G),'diameter':nx.diameter(G),'triangles':sum(nx.triangles(G).values())//3}

def main():
 src=json.loads((ROOT/'data/census/c4_120_38_published.json').read_text())
 K=nx.Graph();K.add_nodes_from(range(120));K.add_edges_from(src['edges'])
 gens=[]
 for name,s in src['generator_cycles_one_based'].items():
  p=list(range(120))
  for cyc in re.findall(r'\(([^)]+)\)',s):
   vals=[int(v.strip())-1 for v in cyc.split(',')]
   for v,w in zip(vals,vals[1:]+vals[:1]):p[v]=w
  assert sorted(p)==list(range(120));gens.append(tuple(p))
 print('Generating published group...',flush=True)
 group=closure(gens,120); identity=tuple(range(120)); center=[p for p in group if all(comp(p,g)==comp(g,p) for g in gens)]
 es={tuple(sorted(e)) for e in K.edges()}; color=nx.bipartite.color(K)
 print('group',len(group),'center',len(center),flush=True)
 checks={'K_connected_quartic_120_240':len(K)==120 and K.number_of_edges()==240 and nx.is_connected(K) and set(dict(K.degree()).values())=={4},
 'published_generators_preserve_edges':all({tuple(sorted((g[u],g[v]))) for u,v in es}==es for g in gens),
 'generated_group_order_960':len(group)==960,
 'published_edge_orbit_exact':{tuple(sorted((g[src['edge_orbit_seed'][0]],g[src['edge_orbit_seed'][1]]))) for g in group}==es,
 'center_order4':len(center)==4,
 'central_nonidentity_involutions':all(order(t)==2 for t in center if t!=identity)}
 data=json.loads((OUT/'carrier_and_quotients.json').read_text())
 G6=nx.Graph();G6.add_nodes_from(range(60));G6.add_edges_from(data['edges'])
 P=nx.petersen_graph(); Qref=nx.convert_node_labels_to_integers(nx.line_graph(cdc(P)),ordering='sorted')
 G4ref=nx.convert_node_labels_to_integers(cdc(Qref),ordering='sorted')
 vs=json.loads((ROOT/'data/census/c4_60_17_voltage.json').read_text());N=vs['modulus']; V=vs['voltages']
 G5ref=nx.Graph();G5ref.add_nodes_from(range(5*N))
 for i in range(5):
  for j in range(5):
   for a in V[i][j]:
    for t in range(N):G5ref.add_edge(i*N+t,j*N+(t+a)%N)
 refs={4:G4ref,5:G5ref,6:G6}; children={}; witnesses={}; taus={}; maps={}; childgraphs={}
 for t in center:
  if t==identity:continue
  child,q,blocks=quotient(K,[t]); sig=inv(child)
  idx=4 if sig['bipartite'] else (6 if sig['triangles'] else 5)
  print('Checking child',idx,sig,flush=True)
  mapping=iso(child,refs[idx]); assert mapping is not None, ('child mismatch',idx)
  checks[f'child_{idx}_exact_isomorphism']=True
  checks[f'child_{idx}_local_bijection']=cover_check(K,child,q)
  checks[f'child_{idx}_fiber_size2']=all(len(b)==2 for b in blocks)
  checks[f'child_{idx}_color_action']=all((color[v]!=color[t[v]])==(idx in (5,6)) for v in K)
  children[str(idx)]=sig; taus[idx]=t; maps[idx]=q;childgraphs[idx]=child
  witnesses[str(idx)]={'involution':list(t),'blocks':blocks,'quotient_map':[q[v] for v in range(120)],'quotient_edges':sorted([sorted(e) for e in child.edges()]),'quotient_to_reference':[mapping[v] for v in range(60)]}
 checks['three_different_children']=set(taus)=={4,5,6}
 checks['tau5_tau6_equals_tau4']=comp(taus[5],taus[6])==taus[4]
 checks['three_taus_commute']=all(comp(taus[i],taus[j])==comp(taus[j],taus[i]) for i in taus for j in taus)
 Q,qc,bs=quotient(K,center)
 print('Checking common 30-base',inv(Q),flush=True)
 qiso=iso(Q,Qref);checks['common_30_is_L_CDC_Petersen']=qiso is not None
 checks['K_to_common30_cover']=cover_check(K,Q,qc)
 for idx in taus:
  child=childgraphs[idx]; qb={maps[idx][v]:qc[v] for v in K}
  checks[f'child_{idx}_to_common30_cover']=cover_check(child,Q,qb)
 G30=nx.Graph(data['G30_edges'])
 checks['common30_distinct_from_draft2_G30']=iso(Q,G30) is None
 # Explicit canonical double coordinates over the manuscript G60.
 w6=witnesses['6']; m6=w6['quotient_to_reference']
 chart={v:(m6[maps[6][v]],color[v]) for v in K}
 checks['K_exact_canonical_double_chart']=len(set(chart.values()))==120 and {frozenset((chart[u],chart[v])) for u,v in K.edges()}=={frozenset(e) for e in cdc(G6).edges()}
 invchart={p:v for v,p in chart.items()}
 a=tuple(data['deck_a_sheet_flip']); b=tuple(data['deck_b_antipodal_lift'])
 lift_a=tuple(invchart[(a[chart[v][0]],chart[v][1])] for v in K)
 lift_b=tuple(invchart[(b[chart[v][0]],chart[v][1])] for v in K)
 deck8=closure([lift_a,lift_b,taus[6]],120)
 Q15,q15,b15=quotient(K,deck8)
 checks['composite_deck8_order8']=len(deck8)==8
 checks['composite_deck8_elementary_abelian']=all(order(p) in (1,2) for p in deck8)
 checks['composite_deck8_free']=all(all(g[v]!=v for v in K) for g in deck8 if g!=identity)
 checks['composite_fibers8']=len(b15)==15 and all(len(b)==8 for b in b15)
 checks['composite_cover15']=cover_check(K,Q15,q15)
 checks['composite_quotient_L_Petersen']=iso(Q15,nx.convert_node_labels_to_integers(nx.line_graph(P))) is not None
 # Stabilizer versus fiber: enumerate exact root group and D8 generators.
 rootstab=[g for g in group if g[0]==0]; prof=Counter(order(g) for g in rootstab)
 checks['root_stabilizer_D8_profile']=prof=={1:1,2:5,4:2}
 r=next(g for g in rootstab if order(g)==4)
 ss=next(s for s in rootstab if order(s)==2 and len(closure([r,s],120))==8 and comp(s,comp(r,s))==comp(r,comp(r,r)))
 checks['root_stabilizer_D8_relations']=len(closure([r,ss],120))==8
 checks['root_stabilizer_color_preserving']=all(color[v]==color[g[v]] for g in rootstab for v in K)
 # Do not infer equivariance of the 15-fiber from counting. Compute it.
 blockset={frozenset(bl) for bl in b15}
 full_preserves=all(frozenset(g[v] for v in bl) in blockset for g in gens for bl in b15)
 checks['full_group_preserves_composite15_fibers']=full_preserves
 induced15=[]
 for g in group:
  t=tuple(q15[g[bl[0]]] for bl in b15)
  assert all(q15[g[v]]==t[q15[v]] for v in K)
  induced15.append(t)
 image15=set(induced15)
 kernel15=[g for g,t in zip(group,induced15) if t==tuple(range(15))]
 root_image15={induced15[group.index(g)] for g in rootstab}
 blockstab=[g for g in group if q15[g[0]]==q15[0]]
 checks['induced15_group_order120']=len(image15)==120
 checks['projection_kernel_equals_deck8']=set(kernel15)==set(deck8)
 checks['root_stabilizer_projects_faithfully']=len(root_image15)==8
 checks['block_stabilizer_order64']=len(blockstab)==64
 checks['frame_descended_stabilizer_order8']=len([g for g in image15 if g[q15[0]]==q15[0]])==8
 induced60={tuple(maps[6][g[bl[0]]] for bl in witnesses['6']['blocks']) for g in group}
 checks['induced60_group_order480']=len(induced60)==480
 q30to15={qc[bl[0]]:q15[bl[0]] for bl in bs}
 checks['common30_map_to_same_G15_well_defined']=all(q30to15[qc[v]]==q15[v] for v in K)
 checks['common30_to_same_G15_cover']=cover_check(Q,Q15,q30to15)
 profile=inv(K)
 report={'audit':'draft3_census_family','all_checks_pass':all(checks.values()),'check_count':len(checks),'checks':checks,'K':profile,'generated_group_order':len(group),'full_automorphism_order_status':'960 imported from C4 census; equality with computed subgroup uses that bound','center':list(map(list,center)),'children':children,'quotient_witnesses':witnesses,'common30':{'invariants':inv(Q),'edges':sorted([sorted(e) for e in Q.edges()]),'K_map':[qc[v] for v in K],'blocks':bs,'to_L_CDC_Petersen':[qiso[v] for v in range(30)],'Q30_to_G15':[q30to15[v] for v in range(30)]},'draft2_G30':{'invariants':inv(G30),'isomorphic_to_common30':False},'canonical_double_chart':[[*chart[v]] for v in K],'composite_cover':{'deck_group':'C2 x C2 x C2','generators':[list(lift_a),list(lift_b),list(taus[6])],'blocks':b15,'K_to_G15':[q15[v] for v in K],'edges':sorted([sorted(e) for e in Q15.edges()]),'full_published_group_preserves_fibers':full_preserves},'descent':{'induced15_group_order':len(image15),'kernel15_order':len(kernel15),'block_stabilizer_order':len(blockstab),'root_stabilizer_image_order':len(root_image15),'induced60_group_order':len(induced60)},'root_stabilizer':{'order':len(rootstab),'order_profile':dict(prof),'r':list(r),'s':list(ss)},'boundary':{'physical_correspondence':False,'WXYZTI_intertwiner':False,'minimal_possible_carrier':False,'c_saturation_proved_by_cover_alone':False},'source_files':['data/census/c4_120_38_published.json','data/census/c4_60_17_voltage.json','data/generated/carrier_and_quotients.json']}
 (OUT/'census_family_report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'all_checks_pass':report['all_checks_pass'],'checks':len(checks),'failed':[k for k,v in checks.items() if not v],'full_group_preserves_15fibers':full_preserves,'stabilizer_profile':dict(prof)},indent=2),flush=True)
 if not report['all_checks_pass']:raise SystemExit(1)
if __name__=='__main__':main()
