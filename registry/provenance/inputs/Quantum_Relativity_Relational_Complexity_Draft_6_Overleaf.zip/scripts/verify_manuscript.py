#!/usr/bin/env python3
"""Check protected TeX expressions, input multiplicities, and compiled labels."""
from __future__ import annotations
import collections
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT / 'notes/preservation_manifest.json').read_text())
checks = {}
inputs = collections.Counter()


def expand(path: Path, stack: tuple[Path, ...] = ()) -> str:
    if path in stack:
        raise ValueError(f'Recursive TeX inclusion: {path}')
    text = path.read_text()
    def one(match):
        file = ROOT / (match[1] if match[1].endswith('.tex') else match[1] + '.tex')
        inputs[str(file.relative_to(ROOT))] += 1
        return expand(file, stack + (path,))
    return re.sub(r'\\input\{([^}]+)\}', one, text)

expanded = expand(ROOT / 'main.tex')
for group in ['equations', 'statements']:
    for item in manifest[group]:
        text = (ROOT / item['output_file']).read_text()
        protected = item['source_expression']
        key = item.get('original_number', str(item.get('first_number')))
        checks[f'{group}_{key}_source_expression_unchanged'] = (
            protected in text and hashlib.sha256(protected.encode()).hexdigest() == item['source_sha256'])
        checks[f'{group}_{key}_included_once'] = inputs[item['output_file']] == 1
# Verify original formal statement numbering in the compiled ordering.
numbered = []
current = 0
for match in re.finditer(r'\\section\{|\\setcounter\{section\}\{(\d+)\}|\\begin\{(definition|example|proposition|hypothesis|theorem)\}', expanded):
    if match[1] is not None:
        current = int(match[1])
    elif match[2] is not None:
        numbered.append((current, match[2]))
    else:
        current += 1
aux = (ROOT / 'main.aux').read_text() if (ROOT / 'main.aux').exists() else ''
expected = {'eq:cth': '29', 'eq:fourcell': '42', 'eq:historyconference': '34',
            'eq:bornmasses': '38', 'eq:singletcontraction': '41', 'eq:thaleantime': '24',
            'sec:guardrails': '50', 'sec:mode': '13A', 'app:status': 'H'}
for label, number in expected.items():
    checks[f'compiled_label_{label}'] = bool(re.search(
        re.escape(r'\newlabel{' + label + '}{{' + number + '}'), aux))
log = (ROOT / 'main.log').read_text(errors='replace') if (ROOT / 'main.log').exists() else ''
checks['no_undefined_citations_or_references'] = not bool(re.search(r'(undefined|multiply defined|multiply-defined)', log, re.I)) and bool(log)
checks['no_overfull_boxes'] = 'Overfull' not in log and bool(log)
checks['all_original_numbers_covered'] = sorted(n for q in manifest['equations']
                                              for n in range(q['first_number'], q['last_number'] + 1)) == list(range(1, 53))
full_protections = json.loads((ROOT / 'notes/draft2_file_protections.json').read_text())
for name, digest in full_protections.items():
    checks['baseline_file_unchanged_' + name] = hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
for name in ['sections/01A_census_family.tex', 'sections/01B_common_cover.tex',
             'sections/01C_relational_kernel.tex', 'sections/02A_coupling.tex',
             'sections/03B_wxyzti.tex', 'statements/S22_3_cover.tex',
             'appendices/J_census_replay.tex', 'appendices/K_kernel_replay.tex',
             'appendices/L_structural_horizon.tex']:
    checks['draft3_single_inclusion_' + name] = inputs[name] == 1
for name, digest in json.loads((ROOT / 'notes/draft3_file_protections.json').read_text()).items():
    checks['draft3_protected_' + name] = hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
for name in ['sections/02B_complexity.tex', 'sections/03C_scalar_relay.tex',
             'sections/03D_scalar_mode.tex', 'appendices/M_complexity_contract.tex']:
    checks['draft4_single_inclusion_' + name] = inputs[name] == 1
for label, number in {'sec:complexity':'4A', 'sec:scalarrelay':'11A', 'sec:scalarmode':'13C',
                      'app:complexitycontract':'M', 'prop:scalarcomposition':'11A.2',
                      'prop:localincrement':'11A.3', 'sec:guardrails':'50',
                      'eq:complexitydomain':'{RC1}', 'eq:complexitymodechart':'{RC8}'}.items():
    checks['draft4_compiled_' + label] = bool(re.search(re.escape(r'\newlabel{' + label + '}{{' + number + '}'), aux))
checks['new_thesis_present'] = 'Quantum Relativity is a theory of relational complexity governed by conservation of information.' in expanded
checks['naming_note_present'] = 'Naming and intellectual background' in expanded
checks['water_not_verbatim_quotation'] = 'not a surviving verbatim quotation' in expanded
checks['Tolkien_secondary_mnemonic'] = 'the coincidence is a mnemonic, not mathematical provenance' in expanded
checks['local_scalar_criterion_present'] = 'constant on every fiber' in expanded
checks['complexity_unit_not_inferred_from_causality'] = 'does not imply this complexity increment' in expanded
checks['no_unrequested_consciousness_language'] = 'consciousness' not in expanded.lower() and 'mcgilchrist' not in expanded.lower()

for name, digest in json.loads((ROOT / 'notes/draft4_file_protections.json').read_text()).items():
    checks['draft4_protected_' + name] = hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == digest
for item in json.loads((ROOT/'notes/draft4_expression_protections.json').read_text()):
    expression = item['expression']
    checks['draft4_expression_'+item['file']+'_'+item['id']] = (
        expression in (ROOT/item['file']).read_text()
        and hashlib.sha256(expression.encode()).hexdigest() == item['sha256'])
for label, number in json.loads((ROOT/'notes/draft4_label_protections.json').read_text()).items():
    checks['draft4_preserved_label_'+label] = bool(re.search(
        re.escape(r'\newlabel{'+label+'}{{'+number+'}'), aux))
for name in ['sections/02C_conservative_action.tex',
             'sections/09A_conservative_dynamics.tex', 'sections/09B_gyroscopic.tex',
             'sections/09C_maxwell.tex', 'sections/09D_native_targets.tex',
             'appendices/A2_conservative_terms.tex', 'appendices/L2_dynamical_targets.tex',
             'appendices/N_conservative_calculations.tex']:
    checks['draft5_single_inclusion_'+name] = inputs[name] == 1
for label, number in {'sec:conservativeaction':'6B', 'def:conservativeaction':'6B.1',
                       'sec:conservativedynamics':'37A', 'prop:skewcriterion':'37A.1',
                       'sec:gyroscopic':'37B', 'prop:axistangency':'37B.1',
                       'sec:maxwelltranslation':'37C', 'sec:nativedynamics':'37D',
                       'app:conservativecalculations':'N', 'eq:skewcriterion':'{CD2}',
                       'eq:rotorbundle':'{GY3}', 'eq:regulartop':'{GY6}',
                       'eq:maxwellgenerator':'{EM3}', 'eq:maxwellsymbol':'{EM7}'}.items():
    checks['draft5_compiled_'+label] = bool(re.search(re.escape(r'\newlabel{'+label+'}{{'+number+'}'), aux))
for key, phrase in {
    'recoverability_not_norm':'recovery, invariant preservation, and informativeness are distinct',
    'nonlinear_covariance_not_rotation':'Rotational covariance alone',
    'phase_local_chart':'The shorthand $(\\phi,\\mathbf n)$ is a local chart',
    'stabilizer_not_normal_kernel':'not a normal subgroup of $SO(3)$',
    'moving_metric_term':'\\dot{\\mathsf G}',
    'torque_direction_corrected':'along} $\\boldsymbol\\tau_\\perp$',
    'regular_top_not_general_motion':'Initial conditions with nutation',
    'explicit_periodic_domain':'periodic fields on a flat three-torus',
    'operator_domain_required':'Boundary-domain conditions',
    'duality_boundary_required':'duality-invariant boundary domain',
    'metric_averaging_not_native':'Group averaging produces invariant metrics',
    'finite_step_not_native':'finite-step update on a supplied vector space',
    'source_account_not_automatic':'Prescribed sources alone do not supply',
    'native_targets_retained':'no new native gyro or Maxwell generator admitted',
}.items():
    checks['draft5_boundary_'+key] = phrase in expanded
checks['draft5_no_active_old_organizing_page'] = inputs['sections/results_draft4.tex'] == 0
checks['draft5_bibliography_label_exists'] = bool(re.search(re.escape(r'\newlabel{sec:references}'), aux))
checks['draft5_new_reference_keys_present'] = all(k in (ROOT/'references.bib').read_text() for k in
    ['feynmanrotation','feynmanenergy','crainicbundles','ellerkarabash2021','fernandezcorbaton2013'])
report_path = ROOT/'data/generated/conservative_correspondence_report.json'
comparison = json.loads(report_path.read_text()) if report_path.exists() else {}
checks['draft5_comparison_checks_pass'] = comparison.get('all_checks_pass',False)
checks['draft5_comparison_keeps_native_boundaries_false'] = (
    bool(comparison.get('boundaries')) and not any(comparison['boundaries'].values()))


for name, digest in json.loads((ROOT/'notes/draft5_file_protections.json').read_text()).items():
    checks['draft5_full_file_preserved_'+name] = hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == digest
for label, number in json.loads((ROOT/'notes/draft5_label_protections.json').read_text()).items():
    checks['draft5_inherited_label_'+label] = bool(re.search(re.escape(r'\newlabel{'+label+'}{{'+number+'}'),aux))
for name in ['sections/results_draft6_foundations.tex','sections/results_draft6_constructions.tex',
             'sections/02D_executing_reference.tex','sections/03E_incidence_reconciliation.tex',
             'sections/03F_history_phase_groupoid.tex','sections/05A_signed_axis_reference.tex',
             'appendices/A3_reference_terms.tex','appendices/O_reference_audit.tex']:
    checks['draft6_single_inclusion_'+name]=inputs[name]==1
for label,number in {'sec:executingreference':'4B','def:executingreference':'4B.1',
    'sec:incidencereconciliation':'13D','prop:referencechange':'13D.2',
    'prop:incidencecovariance':'13D.3','prop:reconciliationcriterion':'13D.4',
    'sec:historyphasegroupoid':'16A','sec:signedaxisreference':'27A','app:referenceaudit':'O',
    'eq:faceincidence':'{RF2}','eq:isotropycriterion':'{IR7}',
    'eq:decoratedhistorytarget':'{HG4}','eq:passiveoutcomereference':'{SA6}'}.items():
    checks['draft6_compiled_'+label]=bool(re.search(re.escape(r'\newlabel{'+label+'}{{'+number+'}'),aux))
for key,phrase in {
 'select_not_pick':'Select one. Then we can start.',
 'reference_is_not_native_coupling':'Selecting a reference cannot repair unequal isotropy characters.',
 'state_intertwiner_not_inferred':'it does not construct this projection and check (HG4)',
 'incidence_not_same_as_object':'The sign is therefore not a function of $u$ alone',
 'phase_decoration_not_forced':'Every bare incidence remains compatible with both partitions.',
 'multiple_orbits_not_one_bit':'there are $2^N$ comparisons',
 'raw_section_projective':'the original $d(g,0)=+1$ section is projective',
 'two_120_groups_distinct':'its sector-flip character is not the central reversal',
 'central_spinor_sign_not_axis_flip':'the latter acts trivially on every observable',
 'receipts_are_transcribed':'not the original repository JSON',
 'native_completeness_imported':'does not perform a fresh exhaustive native-graph automorphism search',
 'p3_stays_open':'Its VN03/VN04 interface remains open',
}.items():
    checks['draft6_boundary_'+key]=phrase in expanded
checks['draft6_no_active_obsolete_results_pages']=all(inputs[n]==0 for n in
 ['sections/results_draft3.tex','sections/results_draft4.tex','sections/results_draft5.tex','sections/results_at_a_glance.tex'])
checks['draft6_no_broken_Maxwell_reference']='efsec:maxwelltranslation' not in expanded
checks['draft6_title_metadata_current']='Draft 6:' in (ROOT/'main.tex').read_text() and 'Draft 6' in (ROOT/'preamble.tex').read_text()
for name in ['draft6_native_incidence_groupoid_report','draft6_signed_axis_report','draft6_reference_reconciliation_report']:
    rep=json.loads((ROOT/'data/generated'/f'{name}.json').read_text())
    checks['draft6_pass_'+name]=rep['all_checks_pass'] is True
    checks['draft6_boundaries_false_'+name]=bool(rep['boundaries']) and not any(rep['boundaries'].values())
checks['draft6_source_ledger_present']=(ROOT/'provenance/draft6/source_ledger.json').is_file()

# Recheck supplied snapshot integrity on each editorial run.
source_ledger=json.loads((ROOT/'provenance/draft6/source_ledger.json').read_text())
for item in source_ledger['native_packet']['files']:
    checks['draft6_native_snapshot_integrity_'+item['path']]=(hashlib.sha256((ROOT/item['path']).read_bytes()).hexdigest()==item['sha256'])

# This verifies source preservation, not scientific validity of the unchanged claims.
report = {'audit': 'draft6_editorial_integrity', 'all_checks_pass': all(checks.values()),
          'check_count': len(checks), 'checks': checks,
          'protected_equation_count': 52, 'protected_statement_count': len(manifest['statements']),
          'scope': 'TeX source integrity, single inclusion, key label preservation, and compilation checks.'}
(ROOT / 'data/generated/manuscript_integrity_report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: report[k] for k in ['audit', 'all_checks_pass', 'check_count',
                                       'protected_equation_count', 'protected_statement_count']}, indent=2))
if not report['all_checks_pass']:
    raise SystemExit('FAIL: ' + ', '.join(k for k, v in checks.items() if not v))
