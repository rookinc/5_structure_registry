#!/usr/bin/env python3
"""Run all bounded finite checks offline. TeX compilation does not use Python."""
from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
STEPS = [
    ('verify_constructions.py', 'verification_report.json'),
    ('verify_history_reconstruction.py', 'history_reconstruction_report.json'),
    ('verify_mode.py', 'mode_verification_report.json'),
    ('verify_census_family.py', 'census_family_report.json'),
    ('verify_rank8_kernel.py', 'rank8_kernel_report.json'),
    ('verify_wxyzti_scope.py', 'wxyzti_scope_report.json'),
    ('verify_scalar_accounting.py', 'scalar_accounting_report.json'),
    ('verify_conservative_correspondences.py', 'conservative_correspondence_report.json'),
    ('verify_native_incidence_reference.py', 'draft6_native_incidence_groupoid_report.json'),
    ('verify_signed_axis_reference.py', 'draft6_signed_axis_report.json'),
    ('verify_reference_reconciliation.py', 'draft6_reference_reconciliation_report.json'),
]

def main() -> None:
    reports = []
    for i, (script, report) in enumerate(STEPS, 1):
        print(f'PROGRESS {i}/{len(STEPS)}: {script}', flush=True)
        subprocess.run([sys.executable, str(ROOT / 'scripts' / script)], check=True)
        reports.append(json.loads((ROOT / 'data/generated' / report).read_text()))
    summary = {
        'audit': 'draft6_bounded_verification',
        'all_checks_pass': all(r['all_checks_pass'] for r in reports),
        'check_count': sum(r['check_count'] for r in reports),
        'reports': {name: {'check_count': r['check_count'], 'all_checks_pass': r['all_checks_pass']}
                    for (_, name), r in zip(STEPS, reports)},
        'inherited_check_count': sum(r['check_count'] for r in reports[:8]),
        'inherited_finite_check_count': sum(r['check_count'] for r in reports[:6]),
        'inherited_scalar_check_count': reports[6]['check_count'],
        'inherited_conservative_check_count': reports[7]['check_count'],
        'new_reference_incidence_check_count': sum(r['check_count'] for r in reports[8:]),
        'scope': 'Finite identities and explicitly bounded constructions only; no automatic native cross-register or physical closure.',
    }
    (ROOT / 'data/generated/draft6_verification_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2), flush=True)
    if not summary['all_checks_pass']:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
