#!/usr/bin/env python3
"""Independent replay of the normalized formulas in Project41 Audit028I/J.

This does not execute the historical producer chain or bind the twelve
points to WXYZTI rows, modal frames, or the Born-history coefficient basis.
"""
from __future__ import annotations
from pathlib import Path
from itertools import product
from collections import Counter
import json, math
import networkx as nx
from verify_census_family import comp, closure, order
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'data/generated'
POINTS=list(product(range(3),range(2),range(2)))
INDEX={p:i for i,p in enumerate(POINTS)}
NAMES=['T0','Tu','Tv','Tuv','F0','F1','R0','R1']

def main():
 A={k:[[0]*12 for _ in range(12)] for k in NAMES}; colors={}
 for a,(i,x1,x2) in enumerate(POINTS):
  for b,(j,y1,y2) in enumerate(POINTS):
   if i==j:name={(0,0):'T0',(1,0):'Tu',(0,1):'Tv',(1,1):'Tuv'}[(x1^y1,x2^y2)]
   elif j==(i+1)%3:name='F'+str(x1^y2)
   else:name='R'+str(x2^y1)
   A[name][a][b]=1; colors[a,b]=name
 def mm(a,b):return [[sum(a[i][k]*b[k][j] for k in range(12)) for j in range(12)] for i in range(12)]
 checks={'point_count12':len(POINTS)==12,'partition144':len(colors)==144}
 vals={k:sorted(set(map(sum,m))) for k,m in A.items()}
 checks['valencies_1_1_1_1_2_2_2_2']=vals=={k:([1] if k.startswith('T') else [2]) for k in NAMES}
 trans={k:next((l for l in NAMES if A[l]==list(map(list,zip(*A[k])))),None) for k in NAMES}
 checks['transpose_closed']=all(v is not None for v in trans.values())
 mult={}; bad=[]; nc=[]
 for a,b in product(NAMES,repeat=2):
  m=mm(A[a],A[b]); co={}
  for k in NAMES:
   values={m[i][j] for i,j in colors if colors[i,j]==k}
   if len(values)!=1:bad.append([a,b,k])
   else:co[k]=values.pop()
  mult[a+':'+b]=co
  if m!=mm(A[b],A[a]):nc.append([a,b])
 checks['all64_products_close']=not bad
 checks['algebra_noncommutative']=len(nc)>0
 fusion={'A0':['T0'],'A1':['Tu','F0','R0'],'A2':['Tv','F1','R1'],'A3':['Tuv']}
 fmat={key:[[sum(A[k][i][j] for k in ks) for j in range(12)] for i in range(12)] for key,ks in fusion.items()}
 G=nx.Graph();G.add_nodes_from(range(12));G.add_edges_from((i,j) for i in range(12) for j in range(i+1,12) if fmat['A1'][i][j])
 ds=dict(nx.all_pairs_shortest_path_length(G))
 checks['fusion_icosahedron']=nx.is_isomorphic(G,nx.icosahedral_graph())
 checks['fusion_exact_distance_relations']=all(fmat['A'+str(d)][i][j]==int(ds[i][j]==d) for d in range(4) for i in range(12) for j in range(12))
 intersection={}
 for d in range(4):
  triples={tuple(sum(ds[i][k]==h for k in G[j]) for h in range(4)) for i in G for j in G if ds[i][j]==d}
  intersection[str(d)]=[list(t) for t in sorted(triples)]
 checks['intersection_array_5_2_1__1_2_5']=intersection=={'0':[[0,5,0,0]],'1':[[1,2,2,0]],'2':[[0,2,2,1]],'3':[[0,0,5,0]]}
 # Every color-preserving permutation must rotate cells and translate each V4 cell.
 accepted=[]
 for r in range(3):
  for shifts in product(list(product(range(2),repeat=2)),repeat=3):
   perm=tuple(INDEX[((i+r)%3,x1^shifts[i][0],x2^shifts[i][1])] for i,x1,x2 in POINTS)
   if all(colors[perm[i],perm[j]]==colors[i,j] for i,j in colors):accepted.append(perm)
 checks['candidate_count192']=3*4**3==192
 checks['color_group24']=len(accepted)==24
 aset=set(accepted);checks['color_group_closed']=all(comp(a,b) in aset for a,b in product(accepted,repeat=2))
 checks['color_group_transitive']=len({a[0] for a in accepted})==12
 checks['color_point_stabilizer2']=sum(a[0]==0 for a in accepted)==2
 center=[a for a in accepted if all(comp(a,b)==comp(b,a) for b in accepted)]
 checks['center2']=len(center)==2
 checks['order_profile_C2_A4']=Counter(order(a) for a in accepted)=={1:1,2:7,3:8,6:8}
 # Kernel parametrization s_i=(b_{i+1},b_i); C3 permutes b bits.
 def shift(b):return tuple(INDEX[(i,x1^b[(i+1)%3],x2^b[i])] for i,x1,x2 in POINTS)
 kernels={shift(b) for b in product(range(2),repeat=3)}
 checks['kernel_C2cubed']=kernels=={a for a in accepted if POINTS[a[0]][0]==0}
 rot=tuple(INDEX[((i+1)%3,x1,x2)] for i,x1,x2 in POINTS)
 even={shift(b) for b in product(range(2),repeat=3) if sum(b)%2==0}
 checks['even_plane_V4_C3_orbit']=len(even)==4 and len({comp(rot,comp(a,comp(rot,rot))) for a in even})==4
 a4=closure([rot,*even],12)
 checks['A4_factor12']=len(a4)==12 and Counter(order(a) for a in a4)=={1:1,2:3,3:8}
 checks['direct_product_C2_A4']=len({comp(a,z) for a in a4 for z in center})==24 and len(set(a4)&set(center))==1
 orbitals={frozenset((a[i],a[j]) for a in accepted) for i in range(12) for j in range(12)}
 checks['eight_orbitals_equal_atoms']=orbitals=={frozenset((i,j) for i,j in colors if colors[i,j]==k) for k in NAMES}
 full=[tuple(g[i] for i in range(12)) for g in nx.algorithms.isomorphism.GraphMatcher(G,G).isomorphisms_iter()]
 checks['icosahedral_group120']=len(full)==120
 def inv(p):return tuple(p.index(i) for i in range(len(p)))
 normalizer=[g for g in full if {comp(g,comp(a,inv(g))) for a in accepted}==aset]
 checks['color_group_self_normalizing']=set(normalizer)==aset
 checks['five_conjugate_refinements']=len(full)//len(normalizer)==5
 # Direction and character are attributes of ordered pairs, not two extra point coordinates.
 coarse=Counter((POINTS[i][0],colors[i,j][0],colors[i,j][1]) for i,j in colors if not colors[i,j].startswith('T'))
 checks['12_crosscell_bins_of8_arcs']=len(coarse)==12 and set(coarse.values())=={8}
 # Pure binary toggling does not by itself make a noncommuting modal reflection.
 triples=list(product(range(3),range(2),range(2)))
 for k in (0,1):
  M=lambda x:((-x[0])%3,1-x[1],x[2]^k)
  R=lambda x:(x[0],x[1],1-x[2])
  checks[f'constant_modal_toggle_{k}_commutes_with_role_flip']=all(M(R(x))==R(M(x)) for x in triples)
 report={'audit':'draft3_rank8_kernel','all_checks_pass':all(checks.values()),'check_count':len(checks),'checks':checks,'point_set':POINTS,'atoms':A,'atom_valencies':vals,'transpose':trans,'multiplication':mult,'noncommuting_pairs':nc,'fusion':fusion,'intersection_counts':intersection,'fusion_edges':sorted([sorted(e) for e in G.edges()]),'color_group':list(map(list,accepted)),'color_group_order':len(accepted),'color_group_structure':'C2 x A4','color_group_center':list(map(list,center)),'fused_graph_group_order':len(full),'conjugate_refinements':5,'point_vs_relation_boundary':{'points':12,'ordered_pairs':144,'within_cell_pairs':48,'cross_cell_pairs':96,'source_direction_character_bins':12,'arcs_per_crosscell_bin':8},'provenance':{'normalized_formulas':'provenance/draft3/audit_rank8_coherent_configuration_028i.py','color_group_proof':'provenance/draft3/audit_rank8_schurian_automorphism_group_028j.py','upstream_label_crosswalk_rerun':False,'WXYZTI_binding':False,'Mode_binding':False,'Born_history_basis_binding':False}}
 (OUT/'rank8_kernel_report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'all_checks_pass':report['all_checks_pass'],'check_count':len(checks),'failed':[k for k,v in checks.items() if not v],'noncommutative_witness':nc[0],'product_forward':mult[nc[0][0]+':'+nc[0][1]],'product_reverse':mult[nc[0][1]+':'+nc[0][0]]},indent=2))
 if not report['all_checks_pass']:raise SystemExit(1)
if __name__=='__main__':main()
