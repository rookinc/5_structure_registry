#!/usr/bin/env python3
"""Reconstruct package-local pentagon incidence and check its signed Gram crosswalk.

The native receipt names and history-source provenance are not inferred from
matrix equivalence. Requires the carrier output of verify_constructions.py.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import networkx as nx
import sympy as sp

ROOT = Path(__file__).resolve().parents[1]


def signed_cover(A: sp.Matrix) -> nx.Graph:
    graph = nx.Graph()
    for i in range(A.rows):
        graph.add_edge((i, 0), (i, 1), kind='fiber')
    for i in range(A.rows):
        for j in range(i + 1, A.rows):
            if A[i, j]:
                flip = int(bool(A[i, j] < 0))
                for bit in (0, 1):
                    graph.add_edge((i, bit), (j, bit ^ flip), kind='signed')
    return graph


def integer_rows(A: sp.Matrix) -> list[list[int]]:
    return [[int(x) for x in A.row(i)] for i in range(A.rows)]


def main() -> None:
    carrier_path = ROOT / 'data/generated/carrier_and_quotients.json'
    upstream_path = ROOT / 'data/upstream/thalean_registered_history_conference_operator_audit.json'
    carrier = json.loads(carrier_path.read_text())
    graph = nx.Graph(carrier['G15_edges'])
    cycles = set()
    for start in sorted(graph):
        def visit(path: list[int]) -> None:
            if len(path) == 5:
                if graph.has_edge(path[-1], start):
                    reverse = (start,) + tuple(reversed(path[1:]))
                    cycles.add(min(tuple(path), reverse))
                return
            for v in sorted(graph[path[-1]]):
                if v > start and v not in path:
                    visit(path + [v])
        visit([start])
    cycles = sorted(cycles)
    edges = sorted(tuple(sorted(e)) for e in graph.edges())
    index = {e: i for i, e in enumerate(edges)}
    B = sp.zeros(len(edges), len(cycles))
    boundary = sp.zeros(15, len(edges))
    for i, (u, v) in enumerate(edges):
        boundary[u, i], boundary[v, i] = -1, 1
    for j, cycle in enumerate(cycles):
        for u, v in zip(cycle, cycle[1:] + cycle[:1]):
            B[index[tuple(sorted((u, v)))], j] = 1 if u < v else -1
    gram = B.T * B
    K = gram - 5 * sp.eye(len(cycles))
    original = json.loads(upstream_path.read_text())['objects']
    original_K = sp.Matrix(original['K_hist'])
    original_gram = sp.Matrix(original['history_Gram'])
    matcher = nx.algorithms.isomorphism.GraphMatcher(
        signed_cover(K), signed_cover(original_K),
        edge_match=lambda a, b: a['kind'] == b['kind'])
    witness = next(matcher.isomorphisms_iter(), None)
    if witness is None:
        raise SystemExit('FAIL: no signed matrix-equivalence witness found')
    permutation = [witness[(i, 0)][0] for i in range(K.rows)]
    signs = [(-1) ** witness[(i, 0)][1] for i in range(K.rows)]
    P = sp.zeros(12)
    for i, j in enumerate(permutation):
        P[j, i] = signs[i]
    checks = {
        'G15_order_and_size': graph.number_of_nodes() == 15 and graph.number_of_edges() == 30,
        'twelve_simple_pentagons': len(cycles) == 12 and all(len(set(c)) == 5 for c in cycles),
        'pentagon_edges_admitted': all(graph.has_edge(u, v) for c in cycles
                                     for u, v in zip(c, c[1:] + c[:1])),
        'B_shape_30_by_12': B.shape == (30, 12),
        'B_entries_zero_or_unit': set(B).issubset({-1, 0, 1}),
        'five_edges_per_column': all(sum(x != 0 for x in B.col(j)) == 5 for j in range(12)),
        'incidence_columns_are_closed': boundary * B == sp.zeros(15, 12),
        'Gram_diagonal_five': all(gram[i, i] == 5 for i in range(12)),
        'K_symmetric': K == K.T,
        'K_squared_five_I': K * K == 5 * sp.eye(12),
        'K_spectrum': K.eigenvals() == {-sp.sqrt(5): 6, sp.sqrt(5): 6},
        'witness_is_signed_permutation': P.T * P == sp.eye(12),
        'K_signed_crosswalk': P.T * original_K * P == K,
        'Gram_signed_crosswalk': P.T * original_gram * P == gram,
        'squared_column_norm_sum_sixty': sp.trace(gram) == 60,
        'normalized_Gram_trace_one': sp.trace(gram / 60) == 1,
    }
    report = {
        'audit': 'qr_draft2_package_local_history_reconstruction',
        'all_checks_pass': all(checks.values()), 'check_count': len(checks),
        'checks': {k: bool(v) for k, v in checks.items()},
        'edge_order': edges, 'canonical_cycles': cycles, 'B_reconstructed': integer_rows(B),
        'Gram_reconstructed': integer_rows(gram), 'K_reconstructed': integer_rows(K),
        'to_upstream_permutation': permutation, 'column_signs': signs,
        'crosswalk_equation': 'B_rec.T * B_rec = P.T * M_hist * P; P[to_upstream[i], i] = sign[i]',
        'source_hashes': {carrier_path.name: hashlib.sha256(carrier_path.read_bytes()).hexdigest(),
                          upstream_path.name: hashlib.sha256(upstream_path.read_bytes()).hexdigest()},
        'scope': ['Complete package-local simple-five-cycle census and integer incidence.',
                  'An explicit signed matrix-equivalence witness, not native b/ab designation provenance.',
                  'Original native history naming, temporal register, and chronological law remain separate.'],
    }
    (ROOT / 'data/generated/history_reconstruction_report.json').write_text(
        json.dumps(report, indent=2, sort_keys=True) + '\n')
    if not report['all_checks_pass']:
        raise SystemExit('FAIL: ' + ', '.join(k for k, v in checks.items() if not v))
    print(json.dumps({'audit': report['audit'], 'all_checks_pass': True,
                      'check_count': len(checks), 'cycles': len(cycles), 'B_shape': B.shape}, indent=2))


if __name__ == '__main__':
    main()
