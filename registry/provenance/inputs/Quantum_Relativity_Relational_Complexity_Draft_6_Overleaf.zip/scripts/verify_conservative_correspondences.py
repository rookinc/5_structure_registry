#!/usr/bin/env python3
"""Exact comparison algebra, not a native Thalean gyro/Maxwell derivation.

Dependencies: SymPy, already listed in requirements.txt. Every matrix in the new
comparison tests is constructed here from declared coordinates or simplex data.
No private producer, physical measurement, or continuum limit is invoked.
"""
from __future__ import annotations
from itertools import combinations
from pathlib import Path
import json
import sympy as s

ROOT = Path(__file__).resolve().parents[1]
CHECKS: dict[str, bool] = {}
EVIDENCE: dict[str, object] = {}


def zero(x) -> bool:
    if isinstance(x, s.MatrixBase):
        return all(s.simplify(v) == 0 for v in x)
    return s.simplify(x) == 0


def check(name: str, value) -> None:
    if name in CHECKS:
        raise ValueError('Duplicate check: ' + name)
    CHECKS[name] = bool(value)


def cross(v):
    x, y, z = v
    return s.Matrix([[0, -z, y], [z, 0, -x], [-y, x, 0]])


def rz(t):
    return s.Matrix([[s.cos(t), -s.sin(t), 0], [s.sin(t), s.cos(t), 0], [0, 0, 1]])


def ry(t):
    return s.Matrix([[s.cos(t), 0, s.sin(t)], [0, 1, 0], [-s.sin(t), 0, s.cos(t)]])


def cayley(a, h):
    ident = s.eye(a.rows)
    return (ident - h*a/2).inv() * (ident + h*a/2)


def coboundary(p: int):
    """Oriented p-cochains to (p+1)-cochains on the full 3-simplex."""
    lower = list(combinations(range(4), p+1))
    upper = list(combinations(range(4), p+2))
    idx = {cell: i for i, cell in enumerate(lower)}
    d = s.zeros(len(upper), len(lower))
    for i, simplex in enumerate(upper):
        for j in range(len(simplex)):
            face = simplex[:j] + simplex[j+1:]
            d[i, idx[face]] = (-1)**j
    return d


def main() -> None:
    print('PROGRESS 1/5: fixed forms, recovery, and negative controls', flush=True)
    g = s.diag(2, 3)
    k2 = s.Matrix([[0, -1], [1, 0]])
    a = g.inv()*k2
    h = s.Rational(1, 5)
    u = cayley(a, h)
    check('weighted_generator_is_G_skew', zero(a.T*g + g*a))
    check('weighted_generator_need_not_be_Euclidean_skew', not zero(a.T+a))
    check('Cayley_preserves_weighted_form', zero(u.T*g*u-g))
    check('Cayley_is_invertible', u.det() != 0)
    check('Cayley_inverse_recovers_state', zero(cayley(a, -h)*u-s.eye(2)))
    ue = s.eye(2)+h*a
    check('Euler_weighted_residual_identity', zero(ue.T*g*ue-g-h*h*a.T*g*a))
    check('Euler_is_not_exactly_conservative', not zero(ue.T*g*ue-g))
    stretch = 2*s.eye(2)
    check('invertible_stretch_preserves_recoverability', stretch.det() != 0)
    check('invertible_stretch_fails_fixed_norm', not zero(stretch.T*stretch-s.eye(2)))
    e1 = s.Matrix([1, 0]); e2 = s.Matrix([0, 1])
    fold = lambda v: s.sqrt(v.dot(v))*e1
    check('norm_preserving_fold_has_collision', e1 != e2 and fold(e1) == fold(e2))
    check('fold_preserves_both_witness_norms', all(zero(fold(v).dot(fold(v))-v.dot(v)) for v in (e1,e2)))
    check('identity_fails_selected_effect_witness', zero(s.eye(2)*e1-e1))
    t = s.symbols('t', real=True)
    movingg = s.exp(-2*t)*s.eye(2)
    check('moving_metric_requires_dot_G', zero(2*movingg+movingg.diff(t)))
    check('moving_metric_not_fixed_metric_skew', not zero(2*movingg))
    gd = s.diag(1, 0)
    check('degenerate_form_misses_nonzero_direction', e2 != s.zeros(2,1) and (e2.T*gd*e2)[0] == 0)
    permutation = s.Matrix([[0,0,1],[1,0,0],[0,1,0]])
    change = s.diag(1,2,3)
    rep = change.inv()*permutation*change
    avg = sum(((rep**j).T*(rep**j) for j in range(3)), s.zeros(3))/3
    check('finite_group_averaging_constructs_invariant', zero(rep.T*avg*rep-avg))
    check('averaged_form_positive_definite_example', all(avg[:j,:j].det()>0 for j in range(1,4)))

    print('PROGRESS 2/5: orientation, fibers, and mechanical correspondence', flush=True)
    x,y,z,vx,vy,vz,alpha = s.symbols('x y z vx vy vz alpha', real=True)
    n0 = s.Matrix([x,y,z]); v0=s.Matrix([vx,vy,vz])
    check('cross_matrix_is_skew', zero(cross(n0).T+cross(n0)))
    check('triple_product_identity', zero(n0.cross(v0).cross(n0) - (n0.dot(n0)*v0-n0.dot(v0)*n0)))
    n=s.Matrix([s.Rational(3,5),0,s.Rational(4,5)])
    v=s.Matrix([-s.Rational(4,5),0,s.Rational(3,5)])
    gamma=-cross(n)
    check('unit_axis_and_tangent_witness', n.dot(n)==1 and n.dot(v)==0)
    check('axis_map_rank_two_kernel_one', gamma.rank()==2 and len(gamma.nullspace())==1)
    check('axis_kernel_is_span_n', zero(gamma*n))
    check('axis_map_image_projection', zero(gamma*gamma.T-(s.eye(3)-n*n.T)))
    check('axis_tangent_reconstruction', zero(n.cross(v).cross(n)-v))
    check('axial_gauge_leaves_axis_velocity', zero((n.cross(v)+alpha*n).cross(n)-v))
    axis=s.Matrix([0,0,1]); ex=s.Matrix([1,0,0]); ey=s.Matrix([0,1,0])
    f=lambda aa,nn: (1+aa.dot(nn))*aa.cross(nn)
    check('nonlinear_orientation_field_is_tangent', zero(n0.dot(f(axis,n0))))
    check('nonlinear_field_forces_z_generator_on_equator', f(axis,ex)==ey and f(axis,ey)==-ex)
    check('nonlinear_field_not_one_constant_generator', f(axis,n) != axis.cross(n))
    q90=ry(s.pi/2)
    check('nonlinear_example_still_jointly_rotation_covariant', zero(f(q90*axis,q90*n)-q90*f(axis,n)))
    rot=s.Matrix([[s.Rational(3,5),-s.Rational(4,5),0],[s.Rational(4,5),s.Rational(3,5),0],[0,0,1]])
    check('fixed_rotation_preserves_norm', zero((rot*n).dot(rot*n)-n.dot(n)))
    check('fixed_rotation_preserves_cone_angle', zero(axis.dot(rot*n)-axis.dot(n)))
    theta,varphi,phi=s.symbols('theta varphi phi', real=True)
    dt,dv,dp=s.symbols('theta_dot varphi_dot phi_dot', real=True)
    q=rz(varphi)*ry(theta)*rz(phi)
    qdot=q.diff(theta)*dt+q.diff(varphi)*dv+q.diff(phi)*dp
    # Use the product-rule spatial angular velocity; also verify the full matrix.
    nn=rz(varphi)*ry(theta)*axis
    omega=dv*axis+dt*rz(varphi)*ey+dp*nn
    check('Euler_frame_derivative_has_declared_angular_velocity', zero(qdot-cross(omega)*q))
    check('axial_phase_has_connection_term', zero(omega.dot(nn)-dp-dv*s.cos(theta)))
    check('right_axial_rotation_preserves_registered_axis', zero(q*rz(theta)*axis-q*axis))
    refl=s.diag(1,-1,-1)
    check('line_reversal_is_proper_rotation', refl.det()==1 and zero(refl.T*refl-s.eye(3)))
    check('line_reversal_changes_oriented_axis', refl*axis == -axis)
    check('line_reversal_conjugates_axial_phase', zero(refl*rz(theta)*refl-rz(-theta)))
    check('axis_stabilizer_is_not_normal', q90*rz(s.pi/2)*q90.T*axis != axis)
    for order in (3,4):
        r=rz(2*s.pi/order)
        check(f'dihedral_template_order_{order}', zero(r**order-s.eye(3)) and zero(refl*r*refl-r.T))
    ell=s.symbols('ell', positive=True)
    tau=s.Matrix(s.symbols('tau_x tau_y tau_z', real=True))
    L=ell*n; tparallel=(n.dot(tau))*n; tperp=tau-tparallel
    op=L.cross(tau)/ell**2
    check('torque_magnitude_orientation_decomposition', zero(n.dot(tau)*n+tperp-tau))
    check('torque_transverse_part_is_tangent', zero(n.dot(tperp)))
    check('perpendicular_precession_generator', zero(op.dot(L)))
    check('precession_cross_product_gives_transverse_torque', zero(op.cross(L)-tperp))
    check('parallel_torque_does_not_reorient_axis', zero(L.cross(alpha*L)))
    I1,Om,L3,mgr=s.symbols('I1 Omega L3 Mgr', real=True)
    aa=s.Matrix([s.sin(theta),0,s.cos(theta)])
    adot=Om*axis.cross(aa)
    Ldot=(L3-I1*Om*s.cos(theta))*adot
    torque=mgr*axis.cross(aa)
    residual=(Om*(L3-I1*Om*s.cos(theta))-mgr)*axis.cross(aa)
    check('regular_top_retains_transverse_inertia', zero(Ldot-torque-residual))
    pp,bb,cc=s.symbols('p b c', positive=True)
    slow=2*cc/(pp+s.sqrt(pp**2-4*bb*cc))
    check('slow_top_asymptotic_ratio_is_one', s.limit(slow/(cc/pp), pp, s.oo)==1)
    check('vertical_torque_is_degenerate', zero(axis.cross(axis)))

    print('PROGRESS 3/5: Maxwell Fourier symbol and signed duality', flush=True)
    k=s.Matrix(s.symbols('k_x k_y k_z', real=True))
    curl=s.I*cross(k); z3=s.zeros(3)
    AM=z3.row_join(curl).col_join((-curl).row_join(z3))
    J=z3.row_join(s.eye(3)).col_join((-s.eye(3)).row_join(z3))
    swap=z3.row_join(s.eye(3)).col_join(s.eye(3).row_join(z3))
    divergence=k.T.row_join(s.zeros(1,3)).col_join(s.zeros(1,3).row_join(k.T))
    check('Fourier_curl_is_Hermitian', zero(curl.conjugate().T-curl))
    check('Fourier_Maxwell_is_skew_Hermitian', zero(AM.conjugate().T+AM))
    check('Fourier_divergence_of_curl_zero', zero(k.T*curl))
    check('Fourier_constraints_preserved', zero(divergence*AM))
    square=k*k.T-k.dot(k)*s.eye(3)
    check('Fourier_wave_symbol_identity', zero(AM**2-s.diag(square,square)))
    check('signed_duality_squares_to_minus_identity', zero(J**2+s.eye(6)))
    check('signed_duality_is_skew', zero(J.T+J))
    check('duality_commutes_with_Maxwell', zero(J*AM-AM*J))
    check('unsigned_swap_is_involution', zero(swap**2-s.eye(6)))
    check('unsigned_swap_reverses_generator', zero(swap*AM*swap+AM))
    check('unsigned_swap_does_not_commute', not zero(swap*AM-AM*swap))
    wrong=z3.row_join(curl).col_join(curl.row_join(z3))
    check('wrong_reciprocal_sign_fails_skewness', not zero(wrong.conjugate().T+wrong))
    check('wrong_reciprocal_sign_is_Hermitian', zero(wrong.conjugate().T-wrong))
    subst=dict(zip(k,(1,2,2)))
    mode=AM.subs(subst); lam=s.symbols('lambda')
    check('nonzero_Fourier_mode_spectrum', s.factor(mode.charpoly(lam).as_expr())==lam**2*(lam**2+9)**2)
    check('Fourier_reality_condition_compatible', zero(AM.subs({ki:-ki for ki in k}, simultaneous=True)-s.conjugate(AM)))
    check('zero_Fourier_mode_static', zero(AM.subs(dict(zip(k,(0,0,0))))))
    um=cayley(mode,s.Rational(1,7))
    check('Fourier_Cayley_exact_unitarity', zero(um.conjugate().T*um-s.eye(6)))
    check('Fourier_Cayley_constraint_preservation', zero(divergence.subs(subst)*um-divergence.subs(subst)))
    # Constant duality symmetry and a concrete boundary-breaking witness.
    theta2=s.symbols('vartheta', real=True)
    du=s.cos(theta2)*s.eye(6)+s.sin(theta2)*J
    check('duality_rotation_exact_orthogonality', zero(du.T*du-s.eye(6)))
    check('duality_preserves_fixed_mode_equation', zero(du*AM-AM*du))
    # Boundary normal ez: E=0,B=ex obey tangential E=0 and normal B=0.
    boundary=s.Matrix([0,0,0,1,0,0]); transformed=J*boundary
    check('electric_conductor_boundary_not_duality_invariant', transformed[0] != 0 and boundary[:3]==[0,0,0])

    print('PROGRESS 4/5: non-native simplex constraint complex', flush=True)
    d0,d1,d2=(coboundary(i) for i in range(3))
    check('simplex_cell_dimensions', (d0.shape,d1.shape,d2.shape)==((6,4),(4,6),(1,4)))
    check('simplex_D1_D0_zero', zero(d1*d0))
    check('simplex_D2_D1_zero', zero(d2*d1))
    me=s.diag(1,2,3,4,5,6); mb=s.diag(2,3,4,5)
    gf=s.diag(me,mb)
    af=s.zeros(6).row_join(me.inv()*d1.T*mb).col_join((-d1).row_join(s.zeros(4)))
    bf=(d0.T*me).row_join(s.zeros(4,4)).col_join(s.zeros(1,6).row_join(d2))
    check('simplex_constitutive_forms_positive', all(v>0 for v in gf.diagonal()))
    check('simplex_weighted_generator_is_skew', zero(af.T*gf+gf*af))
    check('simplex_constraints_annihilate_generator', zero(bf*af))
    uf=cayley(af,s.Rational(1,11))
    check('simplex_Cayley_preserves_weighted_energy', zero(uf.T*gf*uf-gf))
    check('simplex_Cayley_preserves_constraints', zero(bf*uf-bf))
    check('simplex_Cayley_reversible', zero(cayley(af,-s.Rational(1,11))*uf-s.eye(10)))
    ev=s.Matrix(s.symbols('e0:6', real=True)); bv=s.Matrix(s.symbols('b0:4', real=True)); jv=s.Matrix(s.symbols('j0:6', real=True))
    state=ev.col_join(bv); force=(-me.inv()*jv).col_join(s.zeros(4,1))
    check('simplex_source_work_energy_balance', zero((state.T*gf*force)[0]+ev.dot(jv)))
    check('simplex_source_charge_constraint_balance', zero(bf*force-(-d0.T*jv).col_join(s.zeros(1,1))))
    badk=s.zeros(10);badk[0,1]=1;badk[1,0]=-1
    bad=gf.inv()*badk
    check('skew_does_not_imply_divergence_preservation', zero(bad.T*gf+gf*bad) and not zero(bf*bad))
    EVIDENCE['simplex']={'D0':d0.tolist(),'D1':d1.tolist(),'D2':d2.tolist(),
                         'electric_metric_diagonal':list(me.diagonal()),
                         'magnetic_metric_diagonal':list(mb.diagonal()),
                         'native_Thalean_input':False}
    EVIDENCE['Fourier_mode']={'wavevector':[1,2,2], 'c_for_test':1,
                              'characteristic_polynomial':'lambda^2*(lambda^2+9)^2',
                              'native_Thalean_input':False}
    EVIDENCE['nonlinear_tangency_counterexample']={
        'axis':[0,0,1], 'test_orientation':['3/5',0,'4/5'],
        'constant_z_generator_velocity':[0,'3/5',0],
        'actual_velocity':[0,'27/25',0]}
    print('PROGRESS 5/5: write bounded report and retain native boundaries', flush=True)
    report={'audit':'draft5_conservative_correspondence_checks',
            'all_checks_pass':all(CHECKS.values()),'check_count':len(CHECKS),
            'arithmetic':'exact SymPy symbolic and rational algebra',
            'checks':CHECKS,'evidence':EVIDENCE,
            'boundaries':{'native_Thalean_metric_selected':False,
                          'native_Thalean_generator_derived':False,
                          'native_phase_rotor_intertwiner':False,
                          'native_Maxwell_incidence_complex':False,
                          'continuum_limit_proved':False,
                          'physical_QR_correspondence_established':False},
            'scope':'Declared comparison identities and negative controls only; no physical validation or native derivation.'}
    path=ROOT/'data/generated/conservative_correspondence_report.json'
    path.write_text(json.dumps(report,indent=2,default=str)+'\n')
    print(json.dumps({'audit':report['audit'],'all_checks_pass':report['all_checks_pass'],
                      'check_count':report['check_count']},indent=2),flush=True)
    if not report['all_checks_pass']:
        raise SystemExit('FAIL: '+', '.join(k for k,v in CHECKS.items() if not v))

if __name__ == '__main__':
    main()
