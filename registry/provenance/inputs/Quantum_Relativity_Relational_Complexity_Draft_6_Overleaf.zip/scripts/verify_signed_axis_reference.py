#!/usr/bin/env python3
"""Exact signed-axis switching replay on the supplied six-line conference data.

Distinguishes a projective section, its central signed lift, and the sector
exchange group. This is not a native lift of a history actor to an instrument.
"""
from __future__ import annotations
from collections import Counter
from itertools import permutations
import sympy as sp
from draft6_common import ROOT, load, compose, inverse, parity, perm_order, emit, sha


def switchings(source, target):
    n=len(source); out={}
    for p in permutations(range(n)):
        d=(1,)+tuple(target[p[0]][p[j]]*source[0][j] for j in range(1,n))
        if all(target[p[i]][p[j]]==d[i]*d[j]*source[i][j] for i in range(n) for j in range(n)):
            out[p]=d
    return out


def solve_binary(equations, n):
    """Return an exact solution, rank, and consistency over F2."""
    piv={}
    for mask,rhs in equations:
        row=mask | ((rhs&1)<<n)
        while row & ((1<<n)-1):
            k=(row & ((1<<n)-1)).bit_length()-1
            if k in piv:row ^= piv[k]
            else:
                piv[k]=row
                break
        else:
            if (row>>n)&1:return None,len(piv),False
    solution=0
    for k,row in sorted(piv.items()):
        rhs=(row>>n)&1
        rhs ^= ((row & ((1<<k)-1) & solution).bit_count() & 1)
        if rhs:solution |= 1<<k
    return [(solution>>i)&1 for i in range(n)],len(piv),True


def main():
    seed=load('provenance/draft6/reported_audit_receipts.json')['analyzer_sign_matrix_seed']['S']
    S=tuple(tuple(x for x in row) for row in seed)
    C=sp.Matrix(S)-sp.eye(6)
    minus=tuple(tuple(1 if i==j else -S[i][j] for j in range(6)) for i in range(6))
    maps=switchings(S,S); cross=switchings(S,minus)
    base=sorted(maps); idx={p:i for i,p in enumerate(base)}; ds=[maps[p] for p in base]
    e=idx[tuple(range(6))];n=len(base)
    table=[[idx[compose(p,q)] for q in base] for p in base]
    omega=[]; nonglobal=0
    for i,p in enumerate(base):
        row=[]
        for j,q in enumerate(base):
            prod=tuple(ds[i][q[k]]*ds[j][k] for k in range(6))
            canon=ds[table[i][j]];w=prod[0]
            nonglobal += prod!=tuple(w*x for x in canon)
            row.append(w)
        omega.append(row)
    checks={'symmetric_zero_diagonal_conference':C==C.T and all(C[i,i]==0 for i in range(6)),
            'conference_square_5I':C*C==5*sp.eye(6),'within_count60':n==60,
            'cross_count60':len(cross)==60,'within_cross_disjoint':not(set(maps)&set(cross)),
            'within_even_cross_odd':all(parity(p)==1 for p in maps) and all(parity(p)==-1 for p in cross),
            'section_Gram_covariance':all(S[p[i]][p[j]]==d[i]*d[j]*S[i][j] for p,d in maps.items() for i in range(6) for j in range(6)),
            'section_defects_only_global_sign':nonglobal==0,
            'raw_section_is_not_multiplicative':any(w==-1 for row in omega for w in row),
            'exact_section_compositions_match_2600':sum(w==1 for row in omega for w in row)==2600,
            'global_minus_compositions_match_1000':sum(w==-1 for row in omega for w in row)==1000,
            'factor_set_normalized':all(omega[e][g]==omega[g][e]==1 for g in range(n)),
            'all_216000_factor_set_associativity_checks':all(omega[g][h]*omega[table[g][h]][k]==omega[h][k]*omega[g][table[h][k]] for g in range(n) for h in range(n) for k in range(n))}
    eq=[]
    for g in range(n):
        for h in range(n):
            mask=(1<<g)^(1<<h)^(1<<table[g][h])
            eq.append((mask,int(omega[g][h]<0)))
    solution,rank,ok=solve_binary(eq,n)
    checks['splitting_equations_consistent']=ok
    if not ok:raise SystemExit('The signed extension did not split')
    t=[(-1)**b for b in solution]
    linear=[tuple(t[i]*x for x in ds[i]) for i in range(n)]
    checks['splitting_rank60_unique_on_this_section']=rank==60
    checks['split_section_normalized']=t[e]==1
    checks['all_3600_rephased_products_exact']=all(
        tuple(linear[g][base[h][i]]*linear[h][i] for i in range(6))==linear[table[g][h]] for g in range(n) for h in range(n))
    signed=[(p,tuple(s*x for x in maps[p])) for p in base for s in (1,-1)]
    sidx={x:i for i,x in enumerate(signed)}
    def smul(x,y):
        p,d=x;q,c=y
        return compose(p,q),tuple(d[q[i]]*c[i] for i in range(6))
    stab=[[sidx[smul(x,y)] for y in signed] for x in signed]
    se=sidx[(tuple(range(6)),(1,)*6)]
    central_minus=sidx[(tuple(range(6)),(-1,)*6)]
    center=[i for i in range(120) if all(stab[i][j]==stab[j][i] for j in range(120))]
    checks['signed_group_has_120_distinct_elements']=len(sidx)==120
    checks['signed_group_center_is_exact_global_plus_minus']=set(center)=={se,central_minus}
    checks['global_minus_has_order2']=stab[central_minus][central_minus]==se
    def si(g,s):return sidx[(base[g],tuple(s*x for x in linear[g]))]
    checks['explicit_A5_times_C2_product_map_bijective']=len({si(g,s) for g in range(n) for s in (-1,1)})==120
    checks['explicit_direct_product_multiplication']=all(stab[si(g,s)][si(h,t0)]==si(table[g][h],s*t0) for g in range(n) for h in range(n) for s in (-1,1) for t0 in (-1,1))
    # Identify the sector group by an explicit faithful permutation action on
    # the five Klein-four subgroups of the order-60 group, not by a fingerprint.
    total=sorted(set(maps)|set(cross)); ti={p:i for i,p in enumerate(total)}
    tt=[[ti[compose(p,q)] for q in total] for p in total]
    inv=[ti[inverse(p)] for p in total]
    te=ti[tuple(range(6))]
    even={ti[p] for p in base}
    invol=[i for i in even if i!=te and tt[i][i]==te]
    fours={frozenset([te,x,y,tt[x][y]]) for x in invol for y in invol if x!=y and tt[x][y]==tt[y][x]}
    fours=sorted(fours,key=lambda x:tuple(sorted(x)))
    induced=[]
    for g in range(120):
        induced.append(tuple(fours.index(frozenset(tt[tt[g][h]][inv[g]] for h in H)) for H in fours))
    checks['exactly_five_Klein_four_subgroups']=len(fours)==5 and all(len(H)==4 for H in fours)
    checks['sector_group_action_on_five_subgroups_faithful']=len(set(induced))==120
    checks['sector_group_image_is_all_S5']=set(induced)==set(permutations(range(5)))
    checks['base_group_image_is_all_A5']={induced[g] for g in even}=={p for p in permutations(range(5)) if parity(p)==1}
    checks['five_point_action_is_a_homomorphism']=all(compose(induced[g],induced[h])==induced[tt[g][h]] for g in range(120) for h in range(120))
    tcenter=[g for g in range(120) if all(tt[g][h]==tt[h][g] for h in range(120))]
    checks['S5_sector_group_center_trivial']=tcenter==[te]
    checks['extensions_nonisomorphic_by_center']=len(center)!=len(tcenter)
    checks['even_sector_kernel_normal']=all({tt[tt[g][h]][inv[g]] for h in even}==even for g in range(120))
    native=load('data/generated/draft6_native_incidence_groupoid_report.json')
    fa={tuple(p) for p in native['face_action_by_index']}
    bridges=[]
    for p in permutations(range(6)):
        ip=inverse(p)
        if {compose(compose(p,g),ip) for g in total}==fa:bridges.append(p)
    checks['sector_group_conjugate_to_cached_native_face_image']=bool(bridges)
    # This comparison is of permutation groups, not a source-selected setting
    # map or a lift to the face adjoint.
    original=load('data/upstream/thalean_registered_history_conference_operator_audit.json')['conference_equivalence']['target_C']
    oldS=tuple(tuple(1 if i==j else original[i][j] for j in range(6)) for i in range(6))
    comparisons=switchings(S,oldS)
    checks['conference_seed_has_signed_permutation_crosswalk_to_manuscript_C']=bool(comparisons)
    gp=sp.eye(6)+C/sp.sqrt(5)
    checks['rank3_Gram_eigenvalues_2_and_0']=gp.eigenvals()=={sp.Integer(2):3,sp.Integer(0):3}
    checks['all_Gram_preserving_diagonal_gauges_are_global']=all(
        (all(ss[i]*ss[j]*S[i][j]==S[i][j] for i in range(6) for j in range(6))) == (len(set(ss))==1)
        for ss in __import__('itertools').product((-1,1),repeat=6))
    checks['common_switching_preserves_correlation_kernel']=all(
        -S[i][j]==-d[i]*d[j]*S[p[i]][p[j]] for p,d in maps.items() for i in range(6) for j in range(6))
    # Normalized quantum algebra on a literal two-qubit fiber, separate from
    # the unproved native analyzer-to-face binding.
    I=sp.eye(2)
    pauli=[sp.Matrix([[0,1],[1,0]]),sp.Matrix([[0,-sp.I],[sp.I,0]]),sp.diag(1,-1)]
    swap=sp.Matrix([[1,0,0,0],[0,0,1,0],[0,1,0,0],[0,0,0,1]])
    odd=(sp.eye(4)-swap)/2
    gamma=lambda A,B:sp.trace(odd*sp.kronecker_product(A,B))
    checks['Pauli_contraction_equals_minus_half_trace']=all(gamma(A,B)==-sp.trace(A*B)/2 for A in pauli for B in pauli)
    checks['one_leg_orientation_reversal_flips_Gamma']=all(gamma(-A,B)==-gamma(A,B) and gamma(A,-B)==-gamma(A,B) for A in pauli for B in pauli)
    checks['two_leg_orientation_reversal_preserves_Gamma']=all(gamma(-A,-B)==gamma(A,B) for A in pauli for B in pauli)
    checks['passive_outcome_relabeling_preserves_projector']=all((I+a*A)/2==(I+(-a)*(-A))/2 for A in pauli for a in (-1,1))
    checks['spinor_central_minus_has_trivial_adjoint_action']=all((-I)*A*(-I)==A for A in pauli)
    checks['axis_inversion_is_not_spinor_central_adjoint']=any((-I)*A*(-I)!=-A for A in pauli)
    x=sp.symbols('x',real=True)
    checks['binary_table_covariant_under_one_leg_relabeling']=all((1+a*b*x)/4==(1+(-a)*b*(-x))/4 for a in (-1,1) for b in (-1,1))
    bp=next(iter(comparisons))
    emit('draft6_signed_axis_report',checks,
         source_hashes={'transcribed_seed':sha(ROOT/'provenance/draft6/reported_audit_receipts.json'),
                        'native_incidence_report':sha(ROOT/'data/generated/draft6_native_incidence_groupoid_report.json')},
         counts={'within':60,'cross':60,'projective_sector_group':120,'signed_axis_group':120,
                 'exact_section_products':sum(w==1 for row in omega for w in row),
                 'minus_section_products':sum(w==-1 for row in omega for w in row),
                 'nonglobal_defects':nonglobal,'cocycle_triples':60**3,'splitting_rank':rank,
                 'signed_center_order':len(center),'sector_center_order':len(tcenter),
                 'native_face_group_conjugacy_maps':len(bridges)},
         conference_matrix=[[int(x) for x in C.row(i)] for i in range(6)],
         signed_section_rows=[{'permutation':p,'section_signs':ds[i],'rephasing':t[i],'linear_signs':linear[i]} for i,p in enumerate(base)],
         factor_set=omega,
         sector_group_five_point_representation=[{'six_permutation':p,'five_permutation':induced[i]} for i,p in enumerate(total)],
         manuscript_conference_comparison={'permutation':bp,'signs':comparisons[bp]},
         native_face_group_comparison={'chosen_conjugacy':bridges[0] if bridges else None,'source_selected_binding':False},
         classifications={'base':'A5','sector_group':'S5','signed_axis_group':'A5 x C2'},
         boundaries={'original_018G_018H_repository_scripts_rerun':False,'native_setting_face_crosswalk_selected':False,
                     'common_adjoint_face_binding_derived':False,'native_history_to_signed_axis_action_derived':False,
                     'native_Gamma_sign_actor_derived':False,'active_physical_axis_inversion_derived':False},
         scope='Independent exact replay from the transcribed signed Gram and comparison with the retained manuscript conference matrix. Abstract symmetry and quantum-representation identities only; no native history-to-instrument coupling or physical action is inferred.')

if __name__=='__main__':main()
