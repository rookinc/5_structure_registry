#!/usr/bin/env python3
"""Bounded examples for Draft 4's scalar-accounting contract.

These examples are NOT a derivation of the native Thalean complexity functional.
Run independently, or through verify_all.py. Only the Python standard library is
needed. All scalar calculations below use exact rational arithmetic.
"""
from __future__ import annotations

from collections import defaultdict
from fractions import Fraction
from itertools import product
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    checks: dict[str, bool] = {}
    states = list(product(range(2), repeat=2))
    # The bits indicate two distinguished optional relations. Counting present
    # relations is a declared illustrative C, not the general native QR rule.
    def complexity(z: tuple[int, int]) -> int:
        return sum(z)
    def transduce(z: tuple[int, int]) -> tuple[int, int]:
        u, v = z
        return (u ^ v, v)
    def scalar(z: tuple[int, int]) -> Fraction:
        return Fraction(2) ** complexity(z)
    def delta(z: tuple[int, int]) -> int:
        return complexity(transduce(z)) - complexity(z)
    def fibers(eta):
        result = defaultdict(list)
        for z in states:
            result[eta(z)].append(z)
        return result
    def determines(eta, target) -> bool:
        return all(len({target(z) for z in group}) == 1
                   for group in fibers(eta).values())

    checks['complete_two_bit_transducer_injective'] = len({transduce(z) for z in states}) == len(states)
    checks['complete_two_bit_reconstruction'] = all(transduce(transduce(z)) == z for z in states)
    checks['complexity_nonnegative_on_declared_domain'] = all(complexity(z) >= 0 for z in states)
    checks['example_invariant_under_slot_exchange'] = all(complexity(z[::-1]) == complexity(z) for z in states)
    checks['scalar_update_exact_all_four_inputs'] = all(scalar(transduce(z)) == scalar(z) * Fraction(2) ** delta(z) for z in states)
    checks['positive_zero_negative_increments_present'] = {delta(z) for z in states} == {-1, 0, 1}
    checks['complete_state_cycle_has_zero_increment'] = all(delta(z) + delta(transduce(z)) == 0 for z in states)
    telescope_ok = True
    product_ok = True
    for z in states:
        for n in range(17):
            current, change, value = z, 0, scalar(z)
            for _ in range(n):
                increment = delta(current)
                change += increment
                value *= Fraction(2) ** increment
                current = transduce(current)
            telescope_ok &= change == complexity(current) - complexity(z)
            product_ok &= value == scalar(current)
    checks['telescoping_all_inputs_depths_0_to_16'] = telescope_ok
    checks['scalar_product_all_inputs_depths_0_to_16'] = product_ok
    checks['full_output_determines_increment'] = determines(transduce, delta)
    checks['full_output_determines_target_scalar'] = determines(transduce, lambda z: scalar(transduce(z)))
    propagated = lambda z: transduce(z)[0]
    checks['negative_control_payload_only_not_increment_sufficient'] = not determines(propagated, delta)
    checks['negative_control_payload_only_not_target_sufficient'] = not determines(propagated, lambda z: scalar(transduce(z)))
    checks['negative_control_payload_plus_prior_scalar_still_insufficient'] = not determines(lambda z: (propagated(z), scalar(z)), delta)
    # Sufficiency need not require the full input: delta itself is the minimal
    # example of a factor, used ONLY to exercise the iff, not as a native encoder.
    decoder = {key: delta(group[0]) for key, group in fibers(transduce).items()}
    checks['decoder_constructed_from_constant_fibers'] = all(decoder[transduce(z)] == delta(z) for z in states)
    checks['increments_without_baseline_do_not_fix_absolute_scalar'] = Fraction(2) * Fraction(2)**1 != Fraction(4) * Fraction(2)**1
    lossy = lambda z: tuple(sorted(z))
    checks['negative_control_lossy_map_preserves_example_complexity'] = all(complexity(lossy(z)) == complexity(z) for z in states)
    checks['negative_control_lossy_map_is_not_injective'] = len({lossy(z) for z in states}) < len(states)
    # Positive history length: concatenation, not group reduction.
    checks['positive_history_repeat_law_under_declared_additivity'] = all(len(('return',) * n) == n for n in range(17))
    checks['positive_history_cost_differs_from_closed_state_change'] = len(('T', 'T')) == 2 and all(complexity(transduce(transduce(z))) - complexity(z) == 0 for z in states)
    # Conditional product chart from RC8. This tests algebra, not a native map.
    chart = list(product(range(3), range(3), range(2)))
    phase = lambda q: (q[0], (q[1] + 1) % 3, q[2])
    reflection = lambda q: (q[0], (-q[1]) % 3, 1 - q[2])
    phase_inverse = lambda q: (q[0], (q[1] - 1) % 3, q[2])
    checks['conditional_chart_phase_order_three'] = all(phase(phase(phase(q))) == q for q in chart)
    checks['conditional_chart_reflection_order_two'] = all(reflection(reflection(q)) == q for q in chart)
    checks['conditional_chart_modal_conjugacy'] = all(reflection(phase(reflection(q))) == phase_inverse(q) for q in chart)
    checks['conditional_chart_complexity_preserved'] = all(phase(q)[0] == reflection(q)[0] == q[0] for q in chart)
    checks['conditional_chart_has_two_orientation_triads_per_scalar'] = all(len({(p, m) for c0, p, m in chart if c0 == c}) == 6 for c in range(3))
    report = {
        'audit': 'draft4_scalar_accounting_examples',
        'all_checks_pass': all(checks.values()),
        'check_count': len(checks), 'checks': checks,
        'example_domain': 'Two distinguished optional relations, C(u,v)=u+v, T(u,v)=(u xor v,v), G=2.',
        'input_rows': [{'input': list(z), 'output': list(transduce(z)), 'C_in': complexity(z), 'C_out': complexity(transduce(z)), 'delta_C': delta(z)} for z in states],
        'local_failure_witness': {'inputs': [[1,0],[0,1]], 'common_payload': 1, 'common_prior_complexity': 1, 'required_increments': [0,1]},
        'native_complexity_derived': False,
        'native_local_scalar_relay_derived': False,
        'null_well_crosswalk_derived': False,
        'physical_correspondence_claimed': False,
        'scope': 'Exact bounded examples and negative controls for definitions and conditional criteria; no general native Thalean functional or execution law derived.'
    }
    path = ROOT / 'data/generated/scalar_accounting_report.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: report[k] for k in ['audit','all_checks_pass','check_count','scope']},indent=2))
    if not report['all_checks_pass']:
        raise SystemExit('FAIL: ' + ', '.join(k for k,v in checks.items() if not v))


if __name__ == '__main__':
    main()
