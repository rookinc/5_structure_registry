#!/usr/bin/env python3
"""Exact replay of the sourced six relative closure frames.

Uses only the Python standard library. Native G60 provenance remains an
imported theorem; this script verifies the explicitly stated frame algebra.
"""
from __future__ import annotations
import hashlib
import itertools
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
Permutation = tuple[int, int, int]
Frame = tuple[Permutation, Permutation]


def compose(a: Permutation, b: Permutation) -> Permutation:
    return tuple(a[b[i]] for i in range(3))


def inverse(a: Permutation) -> Permutation:
    return tuple(a.index(i) for i in range(3))


def parity(a: Permutation) -> int:
    return (-1) ** sum(a[i] > a[j] for i in range(3) for j in range(i + 1, 3))


def power(a: Permutation, n: int) -> Permutation:
    out = (0, 1, 2)
    for _ in range(n):
        out = compose(a, out)
    return out


def conjugate(g: Permutation, a: Permutation) -> Permutation:
    return compose(compose(g, a), inverse(g))


def act(g: Permutation, f: Frame) -> Frame:
    return conjugate(g, f[0]), conjugate(g, f[1])


def relative(f: Frame) -> Permutation:
    return compose(inverse(f[0]), f[1])


def main() -> None:
    source_path = ROOT / 'provenance/orientation_source_statement.json'
    data = json.loads(source_path.read_text())
    group = list(itertools.permutations(range(3)))
    identity = (0, 1, 2)
    C, M = tuple(data['C_one_line']), tuple(data['M_one_line'])
    reflections = [g for g in group if g != identity and power(g, 2) == identity]
    frames = [(r, rho) for r in reflections for rho in reflections if r != rho]
    reference = (M, compose(M, C))
    presentations = {act(g, reference): g for g in group}
    mode = {f: parity(g) for f, g in presentations.items()}
    coordinates = {(p, m): act(compose(power(C, p), power(M, m)), reference)
                   for p in range(3) for m in range(2)}
    checks = {
        'C_exact_order_three': power(C, 3) == identity and C != identity,
        'M_exact_order_two': power(M, 2) == identity and M != identity,
        'MCM_is_C_inverse': compose(compose(M, C), M) == inverse(C),
        'six_distinct_normal_forms': len({compose(power(C, p), power(M, m))
                                        for p in range(3) for m in range(2)}) == 6,
        'source_table_has_all_six_frames': {(tuple(row['r']), tuple(row['rho']))
                                          for row in data['source_table_7']} == set(frames),
        'all_source_relative_products_correct': all(
            relative((tuple(row['r']), tuple(row['rho']))) == tuple(row['relative'])
            for row in data['source_table_7']),
        'six_frame_action_transitive': set(presentations) == set(frames),
        'every_frame_stabilizer_trivial': all(
            [g for g in group if act(g, f) == f] == [identity] for f in frames),
        'reference_relative_product_C': relative(reference) == C,
        'all_36_decoder_equivariances': all(
            relative(act(g, f)) == conjugate(g, relative(f)) for g in group for f in frames),
        'all_36_mode_covariances': all(
            mode[act(g, f)] == parity(g) * mode[f] for g in group for f in frames),
        'two_mode_triads': sorted(list(mode.values()).count(k) for k in [-1, 1]) == [3, 3],
        'phase_preserves_mode': all(mode[act(C, f)] == mode[f] for f in frames),
        'reflection_reverses_mode': all(mode[act(M, f)] == -mode[f] for f in frames),
        'phase_coordinate_action': all(
            act(C, f) == coordinates[((p + 1) % 3, m)] for (p, m), f in coordinates.items()),
        'reflection_coordinate_action': all(
            act(M, f) == coordinates[((-p) % 3, 1 - m)] for (p, m), f in coordinates.items()),
        'orientation_decoder_matches_mode': all(
            relative(f) == (C if mode[f] == 1 else inverse(C)) for f in frames),
        'all_reflections_invert_C': all(compose(compose(r, C), r) == inverse(C) for r in reflections),
        'relative_mode_reference_independent': all(
            parity(compose(g, inverse(presentations[ref]))) *
            parity(compose(h, inverse(presentations[ref]))) == parity(g) * parity(h)
            for ref in frames for g in group for h in group),
        'source_excerpt_hash_matches': hashlib.sha256(
            (ROOT / data['excerpt_file']).read_bytes()).hexdigest() == data['excerpt_sha256'],
    }
    rows = []
    for g in group:
        for f in frames:
            image = act(g, f)
            rows.append({'g': g, 'g_parity': parity(g), 'frame': f, 'image': image,
                         'relative_before': relative(f), 'relative_after': relative(image),
                         'mode_before': mode[f], 'mode_after': mode[image]})
    report = {
        'audit': 'qr_draft2_modal_frame_replay', 'all_checks_pass': all(checks.values()),
        'check_count': len(checks), 'checks': checks, 'frame_count': len(frames),
        'group_order': len(group), 'action_frame_cases': len(rows),
        'source_statement_sha256': hashlib.sha256(source_path.read_bytes()).hexdigest(),
        'reference_frame': reference, 'source_status': data['status'], 'rows': rows,
        'scope': ['Exact relative-frame algebra and sign character.',
                  'No rerun of the native G60-to-five-block source constructor.',
                  'No identification with the r1 time winding, Born-space reversal, or transport sign is tested.',
                  'No closure advantage, unequal information content, or full G900 action is asserted.'],
    }
    out = ROOT / 'data/generated/mode_verification_report.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    if not report['all_checks_pass']:
        raise SystemExit('FAIL: ' + ', '.join(k for k, v in checks.items() if not v))
    print(json.dumps({k: report[k] for k in ['audit', 'all_checks_pass', 'check_count',
                                           'frame_count', 'action_frame_cases']}, indent=2))


if __name__ == '__main__':
    main()
