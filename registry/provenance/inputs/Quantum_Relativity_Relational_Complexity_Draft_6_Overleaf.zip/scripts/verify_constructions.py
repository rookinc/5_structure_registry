#!/usr/bin/env python3
"""Reconstruct the unlabelled carrier and check the supplied finite matrices.

This script does not recertify the upstream native-history extraction, the
external census isomorphism, or the chronological source law. Run from any cwd.
Dependencies: networkx and sympy. No network access is used.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import networkx as nx
import sympy as sp

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'data' / 'generated'
UP = ROOT / 'data' / 'upstream'


def write_json(name: str, obj: object) -> None:
    (OUT / name).write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def edge(u, v):
    return tuple(sorted((u, v)))


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    checks: dict[str, bool] = {}
    D = nx.dodecahedral_graph()
    dist = dict(nx.all_pairs_shortest_path_length(D))
    antipode = {}
    for u in D:
        farthest = [v for v in D if dist[u][v] == 5]
        if len(farthest) != 1:
            raise ValueError('Dodecahedral antipode is not unique in this presentation')
        antipode[u] = farthest[0]
    CDC = nx.Graph()
    for u, v in D.edges():
        for s in (0, 1):
            CDC.add_edge((u, s), (v, 1-s))
    chambers = sorted(edge(u, v) for u, v in CDC.edges())
    idx = {e: i for i, e in enumerate(chambers)}
    G = nx.Graph()
    G.add_nodes_from(range(60))
    for i, e in enumerate(chambers):
        for j, f in enumerate(chambers[:i]):
            if set(e).intersection(f):
                G.add_edge(i, j)
    a = [idx[edge((u, 1-s), (v, 1-t))] for (u,s),(v,t) in chambers]
    b = [idx[edge((antipode[u],s), (antipode[v],t))] for (u,s),(v,t) in chambers]
    ab = [a[b[i]] for i in G]
    def preserves(perm):
        return len(set(perm)) == 60 and all(G.has_edge(perm[u],perm[v]) for u,v in G.edges())
    def quotient(orbits):
        address = {v:i for i,o in enumerate(orbits) for v in o}
        Q = nx.Graph()
        Q.add_nodes_from(range(len(orbits)))
        for u,v in G.edges():
            if address[u] != address[v]:
                Q.add_edge(address[u],address[v])
        return Q,address
    orbits_a = sorted({tuple(sorted((i,a[i]))) for i in G})
    orbits_v4 = sorted({tuple(sorted((i,a[i],b[i],ab[i]))) for i in G})
    G30,q30 = quotient(orbits_a)
    G15,q15 = quotient(orbits_v4)
    checks.update({
        'G60_order_60': G.number_of_nodes() == 60,
        'G60_size_120': G.number_of_edges() == 120,
        'G60_four_regular': set(dict(G.degree()).values()) == {4},
        'G60_connected': nx.is_connected(G),
        'G60_triangles_40': sum(nx.triangles(G).values()) // 3 == 40,
        'deck_a_automorphism': preserves(a),
        'deck_b_automorphism': preserves(b),
        'deck_a_involution': all(a[a[i]] == i for i in G),
        'deck_b_involution': all(b[b[i]] == i for i in G),
        'deck_commutation': all(a[b[i]] == b[a[i]] for i in G),
        'V4_free_fibers_four': len(orbits_v4) == 15 and all(len(o)==4 for o in orbits_v4),
        'G30_line_dodecahedron_isomorphism': nx.is_isomorphic(G30,nx.line_graph(D)),
        'G15_line_Petersen_isomorphism': nx.is_isomorphic(G15,nx.line_graph(nx.petersen_graph())),
        'G30_cover_local_bijections': all(len({q30[v] for v in G[u]}) == G30.degree(q30[u]) == G.degree(u) for u in G),
        'G15_cover_local_bijections': all(len({q15[v] for v in G[u]}) == G15.degree(q15[u]) == G.degree(u) for u in G),
        'V4_fiber_has_no_carrier_edges': all(not G.has_edge(u,v) for o in orbits_v4 for u in o for v in o),
    })
    payload = {
        'construction':'L(CDC(dodecahedral_graph))',
        'label_scope':'Package-local coordinate convention; not an upstream station-label crosswalk.',
        'vertices':60, 'edges':[list(e) for e in sorted(edge(u,v) for u,v in G.edges())],
        'cover_edge_addresses': [[list(u),list(v)] for u,v in chambers],
        'deck_a_sheet_flip':a, 'deck_b_antipodal_lift':b, 'deck_ab':ab,
        'q30':[q30[i] for i in G], 'q15':[q15[i] for i in G],
        'fibers_v4':[list(o) for o in orbits_v4],
        'G30_edges':[list(e) for e in sorted(edge(u,v) for u,v in G30.edges())],
        'G15_edges':[list(e) for e in sorted(edge(u,v) for u,v in G15.edges())],
    }
    write_json('carrier_and_quotients.json',payload)
    data = json.loads((UP / 'thalean_registered_history_conference_operator_audit.json').read_text())
    objects = data['objects']
    K = sp.Matrix(objects['K_hist'])
    Gram = sp.Matrix(objects['history_Gram'])
    A = sp.Matrix(objects['conference_block_A'])
    cross = data['conference_equivalence']
    C = sp.Matrix(cross['target_C'])
    Z = sp.diag(*[1 if i in objects['b_indices'] else -1 for i in range(12)])
    transformed = sp.diag(*cross['row_signs']) * A.extract(cross['row_permutation'],cross['column_permutation']) * sp.diag(*cross['column_signs'])
    gram_eigenvalues = Gram.eigenvals()
    expected = {5-sp.sqrt(5):6,5+sp.sqrt(5):6}
    Gplus = sp.eye(6)+C/sp.sqrt(5)
    checks.update({
        'K_hist_symmetric':K == K.T,
        'K_hist_squared_5I':K*K == 5*sp.eye(12),
        'history_Gram_5I_plus_K':Gram == 5*sp.eye(12)+K,
        'history_Gram_spectrum':gram_eigenvalues == expected,
        'rho_hist_trace_one':sp.trace(Gram)/60 == 1,
        'Z_squared_I':Z*Z == sp.eye(12),
        'Z_anticommutes_K':Z*K == -K*Z,
        'ZK_squared_minus_5I':(Z*K)**2 == -5*sp.eye(12),
        'conference_block_is_ab_to_b':A == K.extract(objects['ab_indices'], objects['b_indices']),
        'conference_block_AAT':A*A.T == 5*sp.eye(6),
        'conference_crosswalk':transformed == C,
        'C_symmetric':C == C.T,
        'C_squared_5I':C*C == 5*sp.eye(6),
        'C_diagonal_zero':all(C[i,i] == 0 for i in range(6)),
        'Gplus_rank_three':Gplus.rank() == 3,
        'Gplus_diagonal_one':all(Gplus[i,i] == 1 for i in range(6)),
        'sector_masses_sum_one':sp.simplify((5+sp.sqrt(5))/10+(5-sp.sqrt(5))/10) == 1,
    })
    # Verify all six-axis two-outcome tables symbolically.
    table_ok = True
    for i in range(6):
        for j in range(6):
            W = {(s,t):sp.simplify((1-s*t*Gplus[i,j])/4) for s in (-1,1) for t in (-1,1)}
            table_ok &= sp.simplify(sum(W.values())) == 1
            table_ok &= all(w.is_nonnegative is True for w in W.values())
            table_ok &= all(sp.simplify(sum(W[s,t] for t in (-1,1))) == sp.Rational(1,2) for s in (-1,1))
            table_ok &= all(sp.simplify(sum(W[s,t] for s in (-1,1))) == sp.Rational(1,2) for t in (-1,1))
    checks['all_36_tables_normalized_nonnegative_balanced'] = bool(table_ok)
    report = {
        'name':'qr_transducer_inherited_checks_draft2',
        'checks':{k:bool(v) for k,v in checks.items()},
        'all_checks_pass':all(checks.values()),
        'check_count':len(checks),
        'carrier_summary':{
            'vertices':G.number_of_nodes(),'edges':G.number_of_edges(),
            'triangles':sum(nx.triangles(G).values())//3,
            'diameter':nx.diameter(G),
            'G30_vertices':G30.number_of_nodes(),'G30_edges':G30.number_of_edges(),
            'G15_vertices':G15.number_of_nodes(),'G15_edges':G15.number_of_edges(),
        },
        'boundary':[
            'External identification with AT4val[60,6] is imported, not rechecked against the census file.',
            'This inherited checker does not reconstruct the cycle incidence; the separate Draft 2 checker supplies package-local incidence, not native receipt-name provenance.',
            'The supplied 12-by-12 Gram and conference matrices are checked exactly.',
            'Project41 homology and Program03 chronology/registration certificates are not rerun.',
            'No empirical physics, native growing-history source law, or continuum reduction is certified.'
        ],
        'upstream_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(UP.glob('*.json'))},
    }
    write_json('verification_report.json',report)
    if not report['all_checks_pass']:
        raise SystemExit('FAILED: '+', '.join(k for k,v in checks.items() if not v))
    print(json.dumps({'all_checks_pass':True,'check_count':len(checks),'carrier_summary':report['carrier_summary']},indent=2))

if __name__ == '__main__':
    main()
