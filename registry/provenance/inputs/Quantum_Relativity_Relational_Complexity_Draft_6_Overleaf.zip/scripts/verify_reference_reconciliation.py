#!/usr/bin/env python3
"""Reference, signed-incidence, and common-domain reconciliation checks.

Finite examples exercise the proved hypotheses and failure controls. The
history-to-analyzer joint incidence and actual chronology remain unconstructed.
"""
from __future__ import annotations
from itertools import product
import networkx as nx
import numpy as np
from draft6_common import ROOT, load, compose, emit, sha


def canon_cycle(c):
    c=tuple(c);k=c.index(min(c));r=c[k:]+c[:k]
    rev=(r[0],)+tuple(reversed(r[1:]))
    return min(r,rev)


def reconcile(action, cH, cA):
    points=range(len(action[0]));groups=range(len(action))
    return [k for k in product((-1,1),repeat=len(action[0]))
            if all(k[action[g][x]]*cH[g][x]==cA[g][x]*k[x] for g in groups for x in points)]


def main():
    states=(2,3)
    flip={2:3,3:2}
    sigma=lambda ref,x:1 if ref==x else -1
    maps=[dict(zip(states,ss)) for ss in product((-1,1),repeat=2)
          if len(set(ss))==2 and all(ss[states.index(flip[x])]==-ss[states.index(x)] for x in states)]
    checks={
        'two_point_torsor_has_two_reference_signings':len(maps)==2,
        'reference_reversal_negates_coordinates':all(sigma(flip[r],x)==-sigma(r,x) for r in states for x in states),
        'simultaneous_reference_object_reversal_invariant':all(sigma(flip[r],flip[x])==sigma(r,x) for r in states for x in states),
        'relative_sign_comparison_reference_independent':all(sigma(2,x)*sigma(2,y)==sigma(3,x)*sigma(3,y) for x in states for y in states),
        'unmarked_torsor_has_no_exchange_fixed_member':all(flip[x]!=x for x in states),
        'reduced_state_swap_commutes_with_preserve_roles':all(flip[5-x]==5-flip[x] for x in states),
        'reduced_state_swap_commutes_with_identity_role_swap':compose(tuple(flip[x]-2 for x in states),(0,1))==compose((0,1),tuple(flip[x]-2 for x in states)),
    }
    r=load('data/generated/history_reconstruction_report.json')
    B=np.array(r['B_reconstructed'],dtype=np.int64)
    M=B.T@B
    edges=[tuple(x) for x in r['edge_order']]
    cycles=[tuple(x) for x in r['canonical_cycles']]
    G=nx.Graph(edges)
    EI={e:i for i,e in enumerate(edges)}
    CI={canon_cycle(c):i for i,c in enumerate(cycles)}
    autos=sorted(tuple(m[i] for i in range(15)) for m in nx.algorithms.isomorphism.GraphMatcher(G,G).isomorphisms_iter())
    lookup={p:i for i,p in enumerate(autos)}
    Eacts=[];Hacts=[];intertwining=True;gramcov=True;unsigned_failures=0
    for p in autos:
        ep=[];es=[]
        for u,v in edges:
            ep.append(EI[tuple(sorted((p[u],p[v])))])
            es.append(1 if p[u]<p[v] else -1)
        hp=[];hs=[]
        for c in cycles:
            image=tuple(p[v] for v in c)
            j=CI[canon_cycle(image)];d=cycles[j]
            hp.append(j)
            oriented=any(image==d[k:]+d[:k] for k in range(5))
            hs.append(1 if oriented else -1)
        UE=np.zeros((30,30),dtype=np.int64);UH=np.zeros((12,12),dtype=np.int64)
        UE[ep,range(30)]=es;UH[hp,range(12)]=hs
        intertwining &= np.array_equal(UE@B,B@UH)
        gramcov &= np.array_equal(UH.T@M@UH,M)
        unsigned=np.zeros((12,12),dtype=np.int64);unsigned[hp,range(12)]=1
        unsigned_failures += not np.array_equal(UE@B,B@unsigned)
        Eacts.append((tuple(ep),tuple(es)));Hacts.append((tuple(hp),tuple(hs)))
    def spcomp(x,y):
        p,d=x;q,c=y
        return compose(p,q),tuple(d[q[i]]*c[i] for i in range(len(q)))
    checks['local_G15_full_graph_automorphism_census_120']=len(autos)==120
    checks['signed_incidence_intertwines_all_120_graph_automorphisms']=intertwining
    checks['history_Gram_covariant_under_all_120_signed_cycle_actions']=gramcov
    checks['signed_edge_action_composition_all_14400_pairs']=all(spcomp(Eacts[i],Eacts[j])==Eacts[lookup[compose(p,q)]] for i,p in enumerate(autos) for j,q in enumerate(autos))
    checks['signed_history_action_composition_all_14400_pairs']=all(spcomp(Hacts[i],Hacts[j])==Hacts[lookup[compose(p,q)]] for i,p in enumerate(autos) for j,q in enumerate(autos))
    checks['negative_control_omitting_cycle_signs_breaks_incidence_action']=unsigned_failures>0
    checks['all_30_single_edge_reference_flips_cancel_in_Gram']=all(
        np.array_equal((np.where(np.arange(30)==e,-1,1)[:,None]*B).T@(np.where(np.arange(30)==e,-1,1)[:,None]*B),M) for e in range(30))
    checks['all_12_single_history_flips_conjugate_Gram']=all(
        np.array_equal((B*np.where(np.arange(12)==h,-1,1)).T@(B*np.where(np.arange(12)==h,-1,1)),
                       np.where(np.arange(12)==h,-1,1)[:,None]*M*np.where(np.arange(12)==h,-1,1)) for h in range(12))
    de=np.array([(-1)**(i%3==0) for i in range(30)],dtype=np.int64)
    dh=np.array([(-1)**(j%2) for j in range(12)],dtype=np.int64)
    Bp=de[:,None]*B*dh
    checks['combined_row_column_reorientation_law']=np.array_equal(Bp.T@Bp,dh[:,None]*M*dh)
    checks['closed_boundary_survives_edge_reorientation']=True
    boundary=np.zeros((15,30),dtype=np.int64)
    for j,(u,v) in enumerate(edges):boundary[u,j],boundary[v,j]=-1,1
    checks['closed_boundary_survives_edge_reorientation']=np.array_equal((boundary*de)@Bp,np.zeros((15,12),dtype=np.int64))
    # General theorem controls: action groupoid with common actor C2.
    action=((0,1),(1,0));cH=((1,1),(1,1));cA=((1,1),(-1,-1))
    solutions=reconcile(action,cH,cA)
    checks['transitive_free_base_has_two_relative_comparisons']=len(solutions)==2
    checks['incidence_dependent_comparisons_need_not_be_constant']=all(k[0]!=k[1] for k in solutions)
    a4=((0,1,2,3),(1,0,3,2));h4=((1,)*4,(1,)*4);a4sign=((1,)*4,(-1,)*4)
    checks['two_orbits_have_four_not_two_comparisons']=len(reconcile(a4,h4,a4sign))==4
    fixed=((0,),(0,));triv=((1,),(1,));odd=((1,),(-1,))
    checks['isotropy_mismatch_has_no_comparison']=reconcile(fixed,triv,odd)==[]
    checks['equal_fixed_point_isotropy_characters_have_two_comparisons']=len(reconcile(fixed,odd,odd))==2
    checks['selecting_a_reference_does_not_repair_isotropy_mismatch']=all(
        not all(k[fixed[g][0]]*triv[g][0]==odd[g][0]*k[0] for g in range(2)) for k in ((1,),(-1,)))
    gauge_tests=0;gauge_ok=True
    for eH in product((-1,1),repeat=2):
        for eA in product((-1,1),repeat=2):
            Hp=tuple(tuple(eH[action[g][x]]*cH[g][x]*eH[x] for x in range(2)) for g in range(2))
            Ap=tuple(tuple(eA[action[g][x]]*cA[g][x]*eA[x] for x in range(2)) for g in range(2))
            transformed={tuple(eA[x]*k[x]*eH[x] for x in range(2)) for k in solutions}
            gauge_ok &= transformed==set(reconcile(action,Hp,Ap));gauge_tests+=1
    checks['all_16_independent_endpoint_gauge_changes_preserve_comparison_existence']=gauge_ok
    # Exhaust all C2 sign cocycles on a fixed two-point transitive action and
    # compare the isotropy criterion to direct equation solving.
    cocycles=[]
    for bits in product((-1,1),repeat=4):
        c=(bits[:2],bits[2:])
        if all(c[g^h][x]==c[g][action[h][x]]*c[h][x] for g in range(2) for h in range(2) for x in range(2)) and c[0]==(1,1):
            cocycles.append(c)
    tests=0;criterion=True
    for H in cocycles:
        for A in cocycles:
            iso=all(H[g][x]==A[g][x] for g in range(2) for x in range(2) if action[g][x]==x)
            criterion &= (len(reconcile(action,H,A))==(2 if iso else 0));tests+=1
    checks['common_domain_isotropy_criterion_matches_all_small_cocycle_pairs']=criterion
    # Nontrivial loop sign obstructs a single-valued trivialization even after
    # selecting one vertex; no global flatness is inferred from local naming.
    transitions=(1,1,-1)
    global_labels=[s for s in product((-1,1),repeat=3) if all(s[(i+1)%3]==transitions[i]*s[i] for i in range(3))]
    checks['negative_control_odd_loop_obstructs_global_single_valued_labels']=not global_labels
    checks['negative_control_fixing_origin_cannot_remove_odd_loop']=not [s for s in global_labels if s[0]==1]
    emit('draft6_reference_reconciliation_report',checks,
         source_hashes={'retained_history_reconstruction':sha(ROOT/'data/generated/history_reconstruction_report.json')},
         counts={'local_G15_automorphisms':len(autos),'signed_history_action_pairs':len(autos)**2,
                 'unsigned_history_intertwining_failures':unsigned_failures,'independent_gauge_assignments_tested':gauge_tests,
                 'small_cocycle_pairs_tested':tests,'two_orbit_solution_count':4},
         history_incidence_actions=[{'vertex_permutation':p,'edge_permutation':Eacts[i][0],'edge_signs':Eacts[i][1],
                                    'history_permutation':Hacts[i][0],'history_signs':Hacts[i][1]} for i,p in enumerate(autos)],
         comparison_examples={'free_two_point_solutions':solutions,'isotropy_mismatch_solutions':[],
                              'two_orbit_solutions':reconcile(a4,h4,a4sign),'odd_loop_solutions':[]},
         boundaries={'package_history_basis_identified_with_Audit014_labels':False,
                     'native_history_analyzer_joint_incidence_constructed':False,
                     'native_correlation_sign_actor_derived':False,'native_nonperiodic_selector_derived':False,
                     'physical_reference_frame_transformation_derived':False},
         scope='Proved finite reference laws, exact signed-incidence action on the package-local pentagon basis, and small positive/negative controls for a conditional common-domain theorem. No native history-to-instrument identification.')

if __name__=='__main__':main()
