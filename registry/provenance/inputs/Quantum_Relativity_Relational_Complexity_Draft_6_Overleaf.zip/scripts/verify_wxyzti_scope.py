#!/usr/bin/env python3
"""Replay the supplied four WXYZTI circuits; do not select a native crosswalk."""
from pathlib import Path
from collections import Counter
import json,re,ast,itertools
ROOT=Path(__file__).resolve().parents[1]
def main():
 text=(ROOT/'provenance/draft3/wxyzti_chooser_exploration.md').read_text()
 circuits=[]
 for line in text.splitlines():
  triples=re.findall(r'\(\d+,\s*\d+,\s*\d+\)',line)
  if line.startswith('|') and len(triples)==6:circuits.append([ast.literal_eval(t) for t in triples])
 assert len(circuits)==4
 roles=['IW','WX','XY','YZ','ZT','TI']; channel={'IW':0,'YZ':0,'XY':1,'TI':1,'ZT':2,'WX':2}
 rows=[]
 for k,circ in enumerate(circuits):
  for j,start in enumerate(circ):
   rows.append({'row':6*k+j,'circuit':k,'step':j,'role':roles[j],'channel':channel[roles[j]],'role_type':'shared_B' if j%2==0 else 'reverse_partner','from':list(start),'to':list(circ[(j+1)%6])})
 sh=[r for r in rows if r['role_type']=='shared_B'];rev=[r for r in rows if r['role_type']=='reverse_partner']
 candidates=[(s,r) for s in sh for r in rev if s['channel']==r['channel']]
 selected=[(s,r) for s,r in candidates if s['to'][2]==r['from'][1] and r['to'][1]==s['from'][2]]
 expected={(6*k+j,6*k+(j+3)%6) for k in range(4) for j in (0,2,4)}
 obs={(s['row'],r['row']) for s,r in selected}
 checks={'rows24':len(rows)==24,'shared12_reverse12':len(sh)==len(rev)==12,
 'shared_preserve_B':all(r['from'][1]==r['to'][1] for r in sh),
 'reverse_exact_BC_swap':all(r['to']==[r['from'][0],r['from'][2],r['from'][1]] for r in rev),
 'candidate_pairs48':len(candidates)==48,'accepted_pairs12':len(obs)==12,
 'accepted_exact_opposite_edges':obs==expected,
 'all_rows_used_once':Counter(i for pair in obs for i in pair)==Counter(range(24)),
 'three_channels_each_four_pairs':Counter(s['channel'] for s,r in selected)=={0:4,1:4,2:4}}
 C=lambda n:6*(n//6)+(n%6+2)%6
 R=lambda n:6*(n//6)+(n%6+3)%6
 checks['channel_C_order3']=all(C(C(C(i)))==i and C(i)!=i for i in range(24))
 checks['reciprocal_R_order2']=all(R(R(i))==i and R(i)!=i for i in range(24))
 checks['C_R_commute']=all(C(R(i))==R(C(i)) for i in range(24))
 checks['R_preserves_channel_and_exchanges_role']=all(rows[R(i)]['channel']==rows[i]['channel'] and rows[R(i)]['role_type']!=rows[i]['role_type'] for i in range(24))
 checks['C_moves_channel_preserves_role']=all(rows[C(i)]['channel']==(rows[i]['channel']+1)%3 and rows[C(i)]['role_type']==rows[i]['role_type'] for i in range(24))
 checks['R_does_not_invert_C']=all(R(C(R(i)))==C(i) and R(C(R(i)))!=C(C(i)) for i in range(24))
 report={'audit':'draft3_wxyzti_scope','all_checks_pass':all(checks.values()),'check_count':len(checks),'checks':checks,'rows':rows,'candidate_count':len(candidates),'accepted_pairs':sorted(obs),'false_positives':sorted(obs-expected),'misses':sorted(expected-obs),'channel_order':['IW/YZ','TI/XY','WX/ZT'],'point_counts':{'rows':24,'circuits':4,'roles_per_circuit':6,'reciprocal_pairs':12,'channels':3,'pairs_per_channel':4},'source':'provenance/draft3/wxyzti_chooser_exploration.md','later_source_reconciliation':'provenance/draft3/wxyzti_contract_reconciliation.md','boundary':{'six_step_overlay_only':True,'original_ten_step_contract_replayed':False,'native_generation':False,'WXYZTI_to_rank8_binding':False,'Mode_binding':False,'twelve_Born_histories_binding':False}}
 (ROOT/'data/generated/wxyzti_scope_report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:report[k] for k in ('all_checks_pass','check_count','candidate_count','point_counts')},indent=2))
 if not report['all_checks_pass']:raise SystemExit(1)
if __name__=='__main__':main()
