#!/usr/bin/env python3
"""Replay native signed-face incidence and the literal history phase groupoid.

The 480-element table is supplied, not independently enumerated as the full
Aut(G60). Its permutation laws, graph preservation, signed-block action and the
specified history subgroup are checked here. The history {2,3} readout on a
fully decorated carrier and any history-to-analyzer coupling are NOT supplied.
"""
from __future__ import annotations
from collections import Counter
from itertools import permutations
from draft6_common import ROOT, NATIVE, load, compose, inverse, parity, perm_order, generated, emit, sha


def main():
    cache_path = NATIVE / 'project41/artifacts/json/native_g60_automorphism_deck_cache.v1.json'
    block_path = NATIVE / 'project41/artifacts/json/signed_24_face_block_closure_audit_025.json'
    cache = load(cache_path)
    rows = cache['measurements']['automorphism_rows']
    indices = [int(r['automorphism_index']) for r in rows]
    P = [tuple(map(int,r['permutation'])) for r in rows]
    if indices != list(range(480)) or len(set(P)) != 480 or any(sorted(p)!=list(range(60)) for p in P):
        raise SystemExit('Invalid native permutation table')
    lookup = {p:i for i,p in enumerate(P)}
    e = lookup[tuple(range(60))]
    mul = [[lookup.get(compose(p,q),-1) for q in P] for p in P]
    inv = [lookup[inverse(p)] for p in P]
    orders = [perm_order(p) for p in P]
    checks = {'cache_pass_imported':cache['cache_pass'] is True,
              'indices_are_0_to_479':indices==list(range(480)),
              '480_distinct_60_point_permutations':len(set(P))==480,
              'identity_is_index0':e==0,
              'all_230400_native_products_close':all(x>=0 for row in mul for x in row),
              'inverse_laws':all(mul[i][inv[i]]==e==mul[inv[i]][i] for i in indices),
              'cached_orders_recomputed':orders==[r['permutation_order'] for r in rows]}
    bundle = load(NATIVE/'project41/sources/upstream/g60_native_generator_input_bundle_001.v1.json')
    edges = {tuple(sorted(x)) for x in bundle['current_edges']}
    checks['all_480_preserve_current_label_G60_edges'] = all(
        {tuple(sorted((p[x],p[y]))) for x,y in edges}==edges for p in P)
    blocks = load(block_path)['measurements']['signed_blocks']
    sets = [frozenset(b['five_state_block']) for b in blocks]
    Bindex = {b:i for i,b in enumerate(sets)}
    face = [int(b['carrier_index']) for b in blocks]
    signs = [1 if b['sign']=='positive' else -1 for b in blocks]
    face_blocks = [tuple(i for i,f in enumerate(face) if f==j) for j in range(6)]
    BA = [tuple(Bindex[frozenset(p[v] for v in b)] for b in sets) for p in P]
    FA = [tuple(face[ba[bs[0]]] for bs in face_blocks) for ba in BA]
    checks['24_distinct_five_state_blocks'] = len(sets)==len(Bindex)==24 and all(len(b)==5 for b in sets)
    checks['six_disjoint_four_block_carriers'] = all(len(bs)==4 for bs in face_blocks)
    checks['two_positive_two_negative_per_face'] = all(Counter(signs[b] for b in bs)=={1:2,-1:2} for bs in face_blocks)
    checks['signed_sections_each_partition_60_states'] = all(
        Counter(v for i,b in enumerate(sets) if signs[i]==s for v in b)=={v:1 for v in range(60)} for s in (-1,1))
    checks['face_action_well_defined'] = all(all(face[ba[b]]==fa[f] for f,bs in enumerate(face_blocks) for b in bs) for ba,fa in zip(BA,FA))
    chi_face = [signs[ba[0]]*signs[0] for ba in BA]
    checks['face_sign_is_uniform_on_all_24_blocks'] = all(all(signs[ba[i]]==chi_face[g]*signs[i] for i in range(24)) for g,ba in enumerate(BA))
    checks['face_sign_character_homomorphism'] = all(chi_face[mul[g][h]]==chi_face[g]*chi_face[h] for g in indices for h in indices)
    checks['face_sign_profile_240_240'] = Counter(chi_face)=={-1:240,1:240}
    incidence = [(v,b) for b,ss in enumerate(sets) for v in sorted(ss)]
    Iindex = {x:i for i,x in enumerate(incidence)}
    IA = [tuple(Iindex[(p[v],ba[b])] for v,b in incidence) for p,ba in zip(P,BA)]
    checks['bare_incidence_count_120'] = len(incidence)==120
    checks['each_vertex_has_two_opposite_incidence_presentations'] = all(
        sorted(signs[b] for v,b in incidence if v==u)==[-1,1] for u in range(60))
    checks['incidence_action_is_bijective'] = all(sorted(a)==list(range(120)) for a in IA)
    # The two phase partitions are the two perfect matchings between the
    # two positive and the two negative blocks of a face.
    partitions=[]
    for bs in face_blocks:
        pos=sorted(b for b in bs if signs[b]>0)
        neg=sorted(b for b in bs if signs[b]<0)
        ps=sorted({tuple(sorted(tuple(sorted((pos[i],n[i]))) for i in range(2))) for n in permutations(neg)})
        partitions.append(ps)
    phase_states=[(f,p) for f,ps in enumerate(partitions) for p in ps]
    phase_index={x:i for i,x in enumerate(phase_states)}
    PA=[tuple(phase_index[(fa[f],tuple(sorted(tuple(sorted(ba[b] for b in pair)) for pair in part)))] for f,part in phase_states) for ba,fa in zip(BA,FA)]
    decorated=[(v,b,s) for s,(f,part) in enumerate(phase_states) for b in face_blocks[f] for v in sorted(sets[b])]
    Dindex={x:i for i,x in enumerate(decorated)}
    DA=[tuple(Dindex[(p[v],ba[b],pa[s])] for v,b,s in decorated) for p,ba,pa in zip(P,BA,PA)]
    checks['two_native_opposite_sign_partitions_per_face'] = all(len(ps)==2 for ps in partitions)
    checks['phase_state_count_12'] = len(phase_states)==12
    checks['decorated_incidence_count_240'] = len(decorated)==240
    checks['each_bare_incidence_has_both_phase_presentations'] = Counter((v,b) for v,b,s in decorated)=={x:2 for x in incidence}
    checks['decorated_action_is_bijective'] = all(sorted(a)==list(range(240)) for a in DA)
    checks['forget_phase_is_equivariant'] = all(
        decorated[DA[g][i]][:2]==(P[g][v],BA[g][b]) for g in indices for i,(v,b,s) in enumerate(decorated))
    # Source Audit018 uses a different selected phase section. Compare complete
    # unordered partitions, not epsilon labels or record order.
    source018=load(NATIVE/'program02/artifacts/json/epr_reference_gauge_projective_line_map_018.v1.json')
    sr=source018['ell']['rows']
    source_parts={}
    for row in sr:
        key=(row['carrier_index'],row['phase_state_id'])
        source_parts.setdefault(key,set()).add(tuple(sorted((row['signed_block_index'],row['phase_line_partner_block']))))
    checks['all_12_phase_partitions_match_source_Audit018'] = {
        (f,tuple(sorted(ps))) for (f,_),ps in source_parts.items()}==set(phase_states)
    # Sufficient generator-action checks plus the already verified group law.
    gens=[]; closure={e}
    while len(closure)<480:
        gens.append(next(i for i in indices if i not in closure))
        closure=generated(gens,mul,e)
    checks['action_test_generators_generate_all_480'] = len(closure)==480
    checks['decorated_action_composition_exact_on_generators_times_group'] = all(
        compose(DA[g],DA[h])==DA[mul[g][h]] for g in gens for h in indices)
    # Intrinsic D5 kernels fix each of the four blocks setwise; they do not
    # need to fix the five vertices inside each block pointwise.
    stabilizers=[{g for g in indices if FA[g][f]==f} for f in range(6)]
    kernels=[{g for g in stabilizers[f] if all(BA[g][b]==b for b in face_blocks[f])} for f in range(6)]
    checks['all_face_stabilizers_have_order80'] = all(len(h)==80 for h in stabilizers)
    checks['all_block_action_kernels_have_order10'] = all(len(k)==10 for k in kernels)
    checks['all_local_block_images_have_order8'] = all(len({tuple(BA[g][b] for b in face_blocks[f]) for g in stabilizers[f]})==8 for f in range(6))
    checks['all_D5_kernels_are_subgroups'] = all(all(mul[g][h] in k for g in k for h in k) for k in kernels)
    d5_witness=[]
    for k in kernels:
        hits=[(s,t) for s in sorted(k) if orders[s]==5 for t in sorted(k) if orders[t]==2
              if mul[mul[t][s]][t]==inv[s] and generated([s,t],mul)==k]
        if hits:d5_witness.append(hits[0])
    checks['six_explicit_D5_rotation_reflection_witnesses'] = len(d5_witness)==6
    checks['all_2880_stabilizer_conjugations_exact'] = all(
        {mul[mul[g][h]][inv[g]] for h in stabilizers[f]}==stabilizers[FA[g][f]] for g in indices for f in range(6))
    checks['all_2880_D5_kernel_conjugations_exact'] = all(
        {mul[mul[g][h]][inv[g]] for h in kernels[f]}==kernels[FA[g][f]] for g in indices for f in range(6))
    p1005=load(NATIVE/'program01/artifacts/json/005_common_g_projective_face_axis_transport.json')
    checks['common_g_face_map_matches_Program1_005'] = list(FA[3])==[p1005['common_native_exchange']['face_carrier_map'][str(i)] for i in range(6)]
    chi_deck=[1 if row['deck_action']['b']=='b' else -1 for row in rows]
    checks['face_permutation_parity_matches_native_deck_character'] = [parity(fa) for fa in FA]==chi_deck
    checks['face_and_deck_characters_are_distinct'] = chi_face!=chi_deck
    # Reconstruct the 018K finite phase theorem from the actual cached permutations.
    seed=load('provenance/draft6/reported_audit_receipts.json')['history_groupoid_seed']
    G=set(seed['Gamma_indices']);r,s,z=[seed[k+'_index'] for k in ('r','s','z')]
    H=[set(h) for h in seed['phase_isotropy']]
    cosets=[set(h) for h in seed['phase_cosets']]
    K=set(seed['kernel']);words=seed['word_generators']
    rp=[e]
    for _ in range(3):rp.append(mul[r][rp[-1]])
    alpha={g:mul[mul[r][g]][inv[r]] for g in G}
    checks['Gamma_closes'] = all(mul[g][h] in G for g in G for h in G)
    checks['Gamma_generated_by_r_and_H0'] = generated([r]+sorted(H[0]),mul)==G
    checks['r_inverse5_powers_0_3_2_5'] = inv[r]==5 and rp==[0,3,2,5] and orders[r]==4
    checks['literal_D8_times_C2_presentation'] = orders[s]==orders[z]==2 and mul[mul[s][r]][s]==inv[r] and all(mul[z][g]==mul[g][z] for g in G)
    D=generated([r,s],mul)
    checks['literal_internal_direct_product'] = len(D)==8 and z not in D and generated([r,s,z],mul)==G and len({mul[d][zz] for d in D for zz in (e,z)})==16
    checks['diagonal_history_isotropy_embedding'] = generated([mul[rp[2]][z],mul[s][z]],mul)==H[0]
    checks['literal_cosets_are_r_power_H0'] = all({mul[q][h] for h in H[0]}==cosets[k] for k,q in enumerate(rp))
    checks['literal_isotropy_are_r_power_conjugates'] = all({mul[mul[q][h]][inv[q]] for h in H[0]}==H[k] for k,q in enumerate(rp))
    checks['alpha_bijective_homomorphism'] = set(alpha.values())==G and all(alpha[mul[g][h]]==mul[alpha[g]][alpha[h]] for g in G for h in G)
    obj={g:tuple(next(j for j,c in enumerate(cosets) if {mul[g][x] for x in source}==c) for source in cosets) for g in G}
    checks['literal_object_action_r_is_four_cycle'] = list(obj[r])==[1,2,3,0]
    checks['full_object_action_composition'] = all(compose(obj[g],obj[h])==obj[mul[g][h]] for g in G for h in G)
    checks['isotropy_transport_under_r'] = all({alpha[x] for x in H[k]}==H[(k+1)%4] for k in range(4))
    checks['word_generator_transport_under_r'] = all(alpha[words[k]]==words[(k+1)%4] for k in range(4))
    checks['constant_kernel_fixed'] = {alpha[x] for x in K}==K
    checks['action_groupoid_equivariance'] = all(obj[r][obj[g][k]]==obj[alpha[g]][obj[r][k]] for g in G for k in range(4))
    checks['arrow_composition_preserved'] = all(alpha[mul[h][g]]==mul[alpha[h]][alpha[g]] for g in G for h in G for k in range(4))
    checks['reference_S0_is_not_fixed_by_phase_translation'] = obj[r][0]!=0
    # Conjugation sends identity quotient class to identity and nonidentity to
    # nonidentity. It does NOT, just by this fact, swap members of a torsor.
    checks['quotient_identity_and_nonidentity_classes_preserved_in_transport'] = all(
        {alpha[x] for x in H[k]-K}==H[(k+1)%4]-K for k in range(4))
    emit('draft6_native_incidence_groupoid_report',checks,
         counts={'automorphisms':480,'group_products':480**2,'bare_incidences':120,'decorated_incidences':240,
                 'phase_partitions':12,'D5_conjugations':480*6,'decorated_action_compositions':len(gens)*480,
                 'decorated_point_composition_tests':len(gens)*480*240,'Gamma_order':16,'action_groupoid_arrows':16*4},
         native_action_generators=gens, face_action_by_index=FA, block_action_by_index=BA,
         phase_partitions=[{'face':f,'partition':p} for f,p in phase_states],
         D5_kernels=[sorted(k) for k in kernels],D5_generator_witnesses=d5_witness,
         face_stabilizer_orders=[len(h) for h in stabilizers],
         history_group={'indices':sorted(G),'r':r,'r_inverse':inv[r],'r_powers':rp,'alpha':alpha,
                        'cosets':[sorted(c) for c in cosets],'isotropy':[sorted(h) for h in H],
                        'kernel':sorted(K),'word_generators':words,'object_actions':obj},
         source_hashes={str(p.relative_to(ROOT)):sha(p) for p in [cache_path,block_path,ROOT/'provenance/draft6/reported_audit_receipts.json']},
         boundaries={'full_AutG60_completeness_reenumerated':False,'decorated_history_2_3_readout_constructed':False,
                     '018K_literal_history_state_swap_extension_derived':False,'history_analyzer_joint_incidence_constructed':False,
                     'native_history_correlation_coupling_derived':False,'physical_orientation_claim':False},
         scope='Exact cached native permutations and supplied signed blocks, plus explicitly transcribed history-groupoid seeds. Phase-decorated face incidence is reconstructed; it is not yet the history-analyzer joint incidence bridge.')

if __name__=='__main__':main()
