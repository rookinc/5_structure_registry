"""Small exact helpers for the Draft-6 bounded replays (no repository writes)."""
from __future__ import annotations
from pathlib import Path
from collections import Counter
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
NATIVE = ROOT / 'provenance/draft6/native_snapshot'

def load(path: str | Path):
    p = Path(path)
    if not p.is_absolute():
        p = ROOT / p
    return json.loads(p.read_text())

def compose(p, q):
    """Left composition: compose(p,q)(i)=p(q(i))."""
    return tuple(p[q[i]] for i in range(len(q)))

def inverse(p):
    q = [0] * len(p)
    for i, j in enumerate(p):
        q[j] = i
    return tuple(q)

def parity(p):
    return (-1) ** sum(p[i] > p[j] for i in range(len(p)) for j in range(i+1, len(p)))

def perm_order(p):
    e = tuple(range(len(p)))
    q = e
    for k in range(1, 10001):
        q = compose(p, q)
        if q == e:
            return k
    raise ValueError('permutation order exceeds bound')

def generated(generators, mul, identity=0):
    seen = {identity}
    todo = [identity]
    while todo:
        x = todo.pop()
        for g in generators:
            y = mul[g][x]
            if y not in seen:
                seen.add(y)
                todo.append(y)
    return seen

def emit(name, checks, **details):
    checks = {k: bool(v) for k, v in checks.items()}
    report = {'audit':name, 'all_checks_pass':all(checks.values()),
              'check_count':len(checks), 'checks':checks,
              'failed_checks':[k for k,v in checks.items() if not v], **details}
    p = ROOT / 'data/generated' / (name + '.json')
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k:report[k] for k in ('audit','all_checks_pass','check_count','failed_checks')},indent=2))
    if report['failed_checks']:
        raise SystemExit(1)
    return report

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
