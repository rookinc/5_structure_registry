$pdf_mode = 1;
if (-x '/usr/bin/bibtex.original' && ! -x '/usr/bin/bibtex') {
  $bibtex = 'bibtex.original %O %B';
}
